package com.tiviacz.travelersbackpack.client.renderer;

import com.tiviacz.travelersbackpack.client.model.StackModelPart;
import com.tiviacz.travelersbackpack.item.TravelersBackpackItem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10034;
import net.minecraft.class_10444;
import net.minecraft.class_11659;
import net.minecraft.class_1799;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_572;

@Environment(EnvType.CLIENT)
public class BackpackEntityLayer extends class_3887<class_10034, class_572<class_10034>> {
    //RenderStates
    private final StackModelPart tools;
    private final class_10444 backpackRenderState;

    public BackpackEntityLayer(class_3883<class_10034, class_572<class_10034>> renderer) {
        super(renderer);
        this.tools = new StackModelPart();
        this.backpackRenderState = new class_10444();
    }

    @Override
    public void submit(class_4587 pPoseStack, class_11659 sumbitNodeCollector, int pPackedLight, class_10034 pLivingEntity, float p_117353_, float p_117354_) {
        class_1799 backpack = pLivingEntity.field_53418;
        if(backpack.method_7909() instanceof TravelersBackpackItem) {
            BackpackLayer.renderBackpackLayer(method_17165(), pPoseStack, sumbitNodeCollector, pPackedLight, pLivingEntity, this.backpackRenderState, this.tools, backpack);
        }
    }
}