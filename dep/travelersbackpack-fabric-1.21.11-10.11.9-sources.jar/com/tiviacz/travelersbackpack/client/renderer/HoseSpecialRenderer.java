package com.tiviacz.travelersbackpack.client.renderer;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.tiviacz.travelersbackpack.init.ModDataComponents;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10493;
import net.minecraft.class_10494;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_638;
import net.minecraft.class_811;
import org.jetbrains.annotations.Nullable;

@Environment(EnvType.CLIENT)
public record HoseSpecialRenderer() implements class_10494<Integer> {

    public static void register() {
        class_10493.field_55421.method_65325(class_2960.method_60655(TravelersBackpack.MODID, "hose_modes"), HoseSpecialRenderer.TYPE);
    }

    public static final class_10494.class_10495<HoseSpecialRenderer, Integer> TYPE = class_10494.class_10495.method_65686(
            // The map codec for this property
            MapCodec.unit(new HoseSpecialRenderer()),
            // The codec for the object being selected
            Codec.INT
    );

    @Override
    public @Nullable Integer method_65676(class_1799 stack, @Nullable class_638 level, @Nullable class_1309 entity, int seed, class_811 displayContext) {
        return stack.method_58694(ModDataComponents.HOSE_MODES).get(0);
    }

    @Override
    public Codec<Integer> method_67287() {
        return Codec.INT;
    }

    @Override
    public class_10495<? extends class_10494<Integer>, Integer> method_65674() {
        return TYPE;
    }
}
