package com.tiviacz.travelersbackpack.client.renderer;

import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.tiviacz.travelersbackpack.client.model.BackpackModel;
import com.tiviacz.travelersbackpack.client.model.StackModelPart;
import com.tiviacz.travelersbackpack.init.ModDataComponents;
import com.tiviacz.travelersbackpack.item.TravelersBackpackItem;
import com.tiviacz.travelersbackpack.util.HumanoidRenderStateBackpackInject;
import com.tiviacz.travelersbackpack.util.Supporters;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10034;
import net.minecraft.class_10055;
import net.minecraft.class_10444;
import net.minecraft.class_11659;
import net.minecraft.class_1799;
import net.minecraft.class_3883;
import net.minecraft.class_3887;
import net.minecraft.class_4587;
import net.minecraft.class_572;
import net.minecraft.class_591;

@Environment(EnvType.CLIENT)
public class BackpackLayer extends class_3887<class_10055, class_591> {
    private static final BackpackModel BACKPACK_MODEL = new BackpackModel();

    //RenderStates
    private final StackModelPart tools;
    private final class_10444 backpackRenderState;

    public BackpackLayer(class_3883<class_10055, class_591> renderer) {
        super(renderer);
        this.tools = new StackModelPart();
        this.backpackRenderState = new class_10444();
    }

    @Override
    public void submit(class_4587 poseStack, class_11659 sumbitNodeCollector, int packedLightIn, class_10055 state, float limbSwing, float limbSwingAmount) {
        if(TravelersBackpack.enableIntegration()) return;

        class_1799 backpack = ((HumanoidRenderStateBackpackInject)state).getBackpackStack();

        if(backpack != null && backpack.method_7909() instanceof TravelersBackpackItem) {
            renderBackpackLayer(method_17165(), poseStack, sumbitNodeCollector, packedLightIn, state, this.backpackRenderState, this.tools, backpack);
        }
    }

    public static void renderBackpackLayer(class_572 humanoidModel, class_4587 poseStack, class_11659 collector, int packedLightIn, class_10034 state, class_10444 backpackRenderState, StackModelPart tools, class_1799 stack) {
        if(!stack.method_58695(ModDataComponents.IS_VISIBLE, true))
            return;

        if(!(stack.method_7909() instanceof TravelersBackpackItem)) return;

        poseStack.method_22903();
        alignModel(poseStack, humanoidModel, BACKPACK_MODEL, state);
        BACKPACK_MODEL.render(poseStack, packedLightIn, collector, backpackRenderState, tools, stack);

        String name = ((HumanoidRenderStateBackpackInject)state).getName();
        if(name != null && Supporters.SUPPORTERS.contains(name)) {
            BACKPACK_MODEL.supporterBadgeModel.render(poseStack, collector, packedLightIn);
        }
        poseStack.method_22909();
    }

    public static void alignModel(class_4587 poseStack, class_572 parent, BackpackModel backpackModel, class_10034 state) {
        backpackModel.copyFrom(parent.field_3391);
        backpackModel.supporterBadgeModel.copyFrom(parent.field_3391);

        if(state.field_53457) {
            poseStack.method_46416(0F, 0.8F, -0.165F);
            float scaleFactor = state.field_53453;
            poseStack.method_22905(scaleFactor + 0.1F, scaleFactor + 0.1F, scaleFactor + 0.1F);
        }
    }
}