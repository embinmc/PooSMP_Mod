package com.tiviacz.travelersbackpack.client.model;

import net.fabricmc.fabric.api.renderer.v1.render.RenderLayerHelper;
import net.minecraft.class_1087;
import net.minecraft.class_11659;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_630;
import net.minecraft.class_7833;
import net.minecraft.class_9891;
import org.joml.Quaternionf;

public class SupporterBadgeModel {
    public float x = 0;
    public float y = 0;
    public float z = 0;
    public float xRot = 0;
    public float yRot = 0;
    public float zRot = 0;
    public float xScale = 1.0f;
    public float yScale = 1.0f;
    public float zScale = 1.0f;

    public SupporterBadgeModel() {
    }

    public void copyFrom(class_630 parentModelPart) {
        this.xScale = parentModelPart.field_37938;
        this.yScale = parentModelPart.field_37939;
        this.zScale = parentModelPart.field_37940;
        this.xRot = parentModelPart.field_3654;
        this.yRot = parentModelPart.field_3675;
        this.zRot = parentModelPart.field_3674;
        this.x = parentModelPart.field_3657;
        this.y = parentModelPart.field_3656;
        this.z = parentModelPart.field_3655;
    }

    private void translateAndRotate(class_4587 poseStack) {
        poseStack.method_46416(this.x / 16.0f, this.y / 16.0f, this.z / 16.0f);
        if(this.xRot != 0.0f || this.yRot != 0.0f || this.zRot != 0.0f) {
            poseStack.method_22907(new Quaternionf().rotationZYX(this.zRot, this.yRot, this.xRot));
        }
        if(this.xScale != 1.0f || this.yScale != 1.0f || this.zScale != 1.0f) {
            poseStack.method_22905(this.xScale, this.yScale, this.zScale);
        }
    }

    public void render(class_4587 poseStack, class_11659 collector, int packedLightIn) {
        poseStack.method_22903();
        translateAndRotate(poseStack);
        class_1087 starModel = StarModelReloadListener.INSTANCE.getStarModel();

        //Y - Front/Back
        //X - Left/Right
        //Z - Up/Down
        poseStack.method_22904(0.05, 0.23, 0.405);
        poseStack.method_22907(class_7833.field_40714.rotationDegrees(90.0F));
        poseStack.method_22905(0.3F, 0.3F, 0.3F);

        renderModel(poseStack, collector, starModel, packedLightIn);
        poseStack.method_22909();
    }

    //Fabric

    private void renderModel(class_4587 matrixStack, class_11659 collector, class_1087 model, int packedLightIn) {
        collector.method_73529(0).submitBlockStateModel(matrixStack, RenderLayerHelper::getEntityBlockLayer, model, 1, 1, 1, packedLightIn, class_4608.field_21444, 0, class_9891.field_52611, class_2338.field_10980, class_2246.field_10124.method_9564());
    }
}