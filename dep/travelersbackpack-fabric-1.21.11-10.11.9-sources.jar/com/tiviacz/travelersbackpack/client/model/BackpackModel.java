package com.tiviacz.travelersbackpack.client.model;

import net.minecraft.class_10442;
import net.minecraft.class_10444;
import net.minecraft.class_11659;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4608;
import net.minecraft.class_7833;
import net.minecraft.class_811;

public class BackpackModel extends BackpackModelPart {
    public final SupporterBadgeModel supporterBadgeModel;
    private final class_10442 resolver;

    public BackpackModel() {
        this.supporterBadgeModel = new SupporterBadgeModel();
        this.resolver = class_310.method_1551().method_65386();
    }

    public void render(class_4587 poseStack, int packedLightIn, class_11659 collector, class_10444 backpackRenderState, StackModelPart tools, class_1799 stack) {
        poseStack.method_22903();
        translateAndRotate(poseStack);

        //Y - Front/Back
        //X - Left/Right
        //Z - Up/Down
        poseStack.method_22907(class_7833.field_40718.rotationDegrees(180.0F));
        poseStack.method_22904(0, -0.145, 0.35);
        poseStack.method_22905(1.03F, 1.03F, 1.03F);

        if(!stack.method_7960()) {
            resolver.method_65598(backpackRenderState, stack, class_811.field_4315, null, null, 0);
            backpackRenderState.method_65604(poseStack, collector, packedLightIn, class_4608.field_21444, 0);
        }

        //Render Tools
        tools.render(stack, collector, poseStack, packedLightIn, class_4608.field_21444);

        poseStack.method_22909();
    }
}