package com.tiviacz.travelersbackpack.client.model;

import com.tiviacz.travelersbackpack.config.TravelersBackpackConfig;
import com.tiviacz.travelersbackpack.init.ModDataComponents;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_10442;
import net.minecraft.class_10444;
import net.minecraft.class_11659;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import net.minecraft.class_811;

public class StackModelPart extends BackpackModelPart {
    private final class_10442 resolver;
    private final class_10444 upper;
    private final class_10444 lower;

    public StackModelPart() {
        this.resolver = class_310.method_1551().method_65386();
        this.upper = new class_10444();
        this.lower = new class_10444();
    }

    public List<class_1799> prepare(class_1799 stack) {
        if(stack.method_57826(ModDataComponents.TOOLS_CONTAINER)) {
            return new ArrayList<>(stack.method_58694(ModDataComponents.TOOLS_CONTAINER).getItems()).stream().filter(itemStack -> !itemStack.method_7960()).toList();
        } else {
            return new ArrayList<>();
        }
    }

    public void render(class_1799 backpack, class_11659 collector, class_4587 poseStack, int light, int overlay) {
        if(collector == null || !TravelersBackpackConfig.CLIENT.renderTools.get()) {
            return;
        }
        render(prepare(backpack), poseStack, collector, light, overlay);
    }

    public void render(List<class_1799> tools, class_4587 poseStack, class_11659 collector, int pPackedLight, int pPackedOverlay) {
        if(tools.isEmpty()) return;

        class_1799 toolUpper = tools.get(0);
        class_1799 toolLower = class_1799.field_8037;

        if(!toolUpper.method_7960() && tools.size() > 1) {
            toolLower = tools.get(tools.size() - 1);
        }

        poseStack.method_22903();

        if(!toolUpper.method_7960()) {
            poseStack.method_22903();

            poseStack.method_22907(class_7833.field_40718.rotationDegrees(180.0F));

            poseStack.method_22904(0.04D, 0.075D, 0.17D);
            poseStack.method_22907(class_7833.field_40718.rotationDegrees(45F));
            poseStack.method_22907(class_7833.field_40714.rotationDegrees(180F));
            poseStack.method_22905(0.50F, 0.50F, 0.50F);

            resolver.method_65598(upper, toolUpper, getDisplayContext(toolUpper), null, null, 0);
            upper.method_65604(poseStack, collector, pPackedLight, pPackedOverlay, 0);
           // Minecraft.getInstance().getItemRenderer().renderStatic(toolUpper, ItemDisplayContext.NONE, pPackedLight, pPackedOverlay, poseStack, buffer, null, 0);

            poseStack.method_22909();
        }

        if(!toolLower.method_7960()) {
            poseStack.method_22903();

            poseStack.method_22907(class_7833.field_40718.rotationDegrees(180.0F));

            poseStack.method_22904(-0.25, 0.75, -0.025);
            poseStack.method_22907(class_7833.field_40716.rotationDegrees(90F));
            poseStack.method_22907(class_7833.field_40718.rotationDegrees(45F));
            poseStack.method_22905(0.50F, 0.50F, 0.50F);

            resolver.method_65598(lower, toolLower, getDisplayContext(toolLower), null, null, 0);
            lower.method_65604(poseStack, collector, pPackedLight, pPackedOverlay, 0);
            //Minecraft.getInstance().getItemRenderer().renderStatic(toolLower, ItemDisplayContext.NONE, pPackedLight, pPackedOverlay, poseStack, buffer, null, 0);

            poseStack.method_22909();
        }

        poseStack.method_22909();
    }

    public class_811 getDisplayContext(class_1799 stack) {
        if(stack.method_31574(class_1802.field_8547) || stack.method_31574(class_1802.field_27070)) {
            return class_811.field_4317;
        }
        return class_811.field_4315;
    }
}