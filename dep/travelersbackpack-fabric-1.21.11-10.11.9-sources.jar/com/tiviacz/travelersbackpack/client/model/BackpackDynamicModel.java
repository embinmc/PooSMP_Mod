package com.tiviacz.travelersbackpack.client.model;

import com.google.common.collect.ImmutableMap;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonObject;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.tiviacz.travelersbackpack.blockentity.BackpackBlockEntity;
import com.tiviacz.travelersbackpack.components.RenderInfo;
import com.tiviacz.travelersbackpack.init.ModBlocks;
import com.tiviacz.travelersbackpack.inventory.FluidVariantWrapper;
import net.fabricmc.fabric.api.client.model.loading.v1.CustomUnbakedBlockStateModel;
import net.fabricmc.fabric.api.client.model.loading.v1.UnbakedModelDeserializer;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadEmitter;
import net.fabricmc.fabric.api.transfer.v1.client.fluid.FluidVariantRendering;
import net.fabricmc.fabric.impl.renderer.QuadSpriteBaker;
import net.minecraft.class_10419;
import net.minecraft.class_1047;
import net.minecraft.class_10526;
import net.minecraft.class_1058;
import net.minecraft.class_1059;
import net.minecraft.class_10725;
import net.minecraft.class_10801;
import net.minecraft.class_10813;
import net.minecraft.class_10817;
import net.minecraft.class_10819;
import net.minecraft.class_1087;
import net.minecraft.class_10889;
import net.minecraft.class_1100;
import net.minecraft.class_11515;
import net.minecraft.class_1767;
import net.minecraft.class_1920;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3518;
import net.minecraft.class_3665;
import net.minecraft.class_4730;
import net.minecraft.class_5611;
import net.minecraft.class_5819;
import net.minecraft.class_777;
import net.minecraft.class_7775;
import net.minecraft.class_793;
import net.minecraft.class_809;
import net.minecraft.class_813;
import net.minecraft.client.renderer.block.model.*;
import net.minecraft.client.resources.model.*;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix4fc;
import org.joml.Vector3f;
import org.joml.Vector3fc;
import org.joml.Vector4f;

import java.util.*;
import java.util.function.Predicate;

public class BackpackDynamicModel implements class_1100, class_10526 {
    private final Map<ModelParts, class_793> modelParts;
    private final class_11515 renderType;

    private BackpackDynamicModel(Map<ModelParts, class_793> modelParts, class_11515 renderType) {
        this.modelParts = modelParts;
        this.renderType = renderType;
    }

    public DynamicBlockStateModel bakeBlockStateModel(class_7775 baker, class_10819 resolvedModel, class_3665 modelState) {
        ImmutableMap.Builder<ModelParts, class_10817> builder = ImmutableMap.builder();
        modelParts.forEach((part, model) -> {
            builder.put(part, baker.method_45872(model.comp_3744()).method_68044().bake(getTextureSlots(baker, model, resolvedModel), baker, modelState, resolvedModel));
        });
        return new DynamicBlockStateModel(builder.build(), modelState, resolvedModel.method_68033(getTextureSlots(baker, modelParts.get(ModelParts.BASE), resolvedModel), baker), this.renderType);
    }

    private class_10419 getTextureSlots(class_7775 baker, class_1100 partModel, class_10813 debugName) {
        class_10419.class_10423 resolver = new class_10419.class_10423();
        resolver.method_65550(partModel.comp_3743());
        class_2960 parent = partModel.comp_3744();
        if(parent != null) {
            class_10819 resolvedParent = baker.method_45872(parent);
            while(resolvedParent != null) {
                resolver.method_65550(resolvedParent.method_68031().comp_3743());
                resolvedParent = resolvedParent.method_68038();
            }
        }
        return resolver.method_65551(debugName);
    }

    @Override
    public void method_62326(class_10526.class_10103 resolver) {
        modelParts.values().forEach(model -> {
            class_2960 parent = model.comp_3744();
            if(parent != null) {
                resolver.markDependency(parent);
            }
            //model.resolveDependencies(resolver);
        });
    }

    public static final class DynamicBlockStateModel implements class_1087 {
        private final Map<ModelParts, class_10817> models;
        private final class_3665 modelTransform;
        private final class_1058 particleIcon;
        private final class_11515 renderType;

        public boolean isDyed;
        public boolean isSleepingBagDeployed;
        public int sleepingBagColor;

        public RenderInfo renderInfo;
        public class_2248 block;

        public DynamicBlockStateModel(Map<ModelParts, class_10817> models, class_3665 modelTransform, class_1058 particleIcon, class_11515 renderType) {
            this.models = models;
            this.modelTransform = modelTransform;
            this.particleIcon = particleIcon;
            this.renderType = renderType;
        }

        @Override
        public Object createGeometryKey(class_1920 blockView, class_2338 pos, class_2680 state, class_5819 random) {
            return null;
        }

        @Override
        public void emitQuads(QuadEmitter emitter, class_1920 blockView, class_2338 pos, class_2680 state, class_5819 random, Predicate<@Nullable class_2350> cullTest) {
            BackpackBlockEntity.BackpackRenderData renderData = blockView.getBlockEntityRenderData(pos) instanceof BackpackBlockEntity.BackpackRenderData backpackRenderData
                    ? backpackRenderData
                    : new BackpackBlockEntity.BackpackRenderData(RenderInfo.EMPTY, -1, false, class_1767.field_7964.method_7789());

            block = state.method_26204();
            isDyed = renderData.dyeColor() != -1;
            renderInfo = renderData.info() == null ? RenderInfo.EMPTY : renderData.info();
            sleepingBagColor = renderData.sleepingBagColor();
            isSleepingBagDeployed = renderData.isSleepingBagDeployed();

            getQuads().forEach(quad -> emitter.fromBakedQuad(quad).renderLayer(this.renderType).emit());
        }

        private void rebakeSleepingBag(class_10817.class_10818 builder, class_1058 sprite) {
            models.get(ModelParts.SLEEPING_BAG).method_68048().forEach(quad -> {
                class_1058 oldSprite = quad.comp_3724();

                long[] oldUVs = {quad.comp_5242(), quad.comp_5243(), quad.comp_5244(), quad.comp_5245()};
                long[] newUVs = new long[4];

                for(int i = 0; i < 4; i++) {
                    // Unpack using UVPair format: U in upper 32 bits, V in lower 32 bits
                    float oldU = class_5611.method_76641(oldUVs[i]);
                    float oldV = class_5611.method_76642(oldUVs[i]);

                    // Convert from old sprite's atlas space to normalized 0-1 range
                    float uNormalized = (oldU - oldSprite.method_4594()) / (oldSprite.method_4577() - oldSprite.method_4594());
                    float vNormalized = (oldV - oldSprite.method_4593()) / (oldSprite.method_4575() - oldSprite.method_4593());

                    // Convert to new sprite's atlas space
                    float newU = sprite.method_4580(uNormalized);
                    float newV = sprite.method_4570(vNormalized);

                    // Pack using UVPair format
                    newUVs[i] = class_5611.method_76640(newU, newV);
                }

                class_777 newQuad = new class_777(
                        quad.comp_5238(),
                        quad.comp_5239(),
                        quad.comp_5240(),
                        quad.comp_5241(),
                        newUVs[0],
                        newUVs[1],
                        newUVs[2],
                        newUVs[3],
                        quad.comp_3722(),
                        quad.comp_3723(),
                        sprite,
                        quad.comp_3725(),
                        quad.comp_3726()
                );
                builder.method_68051(newQuad);
            });
        }

        private void addExtras(class_10817.class_10818 builder) {
            if(block == ModBlocks.FOX_TRAVELERS_BACKPACK) {
                addAll(builder, models.get(ModelParts.FOX_NOSE));
            }
            if(block == ModBlocks.WARDEN_TRAVELERS_BACKPACK) {
                addAll(builder, models.get(ModelParts.WARDEN_HORNS));
            }
            if(block == ModBlocks.WOLF_TRAVELERS_BACKPACK) {
                addAll(builder, models.get(ModelParts.WOLF_NOSE));
            }
            if(block == ModBlocks.OCELOT_TRAVELERS_BACKPACK) {
                addAll(builder, models.get(ModelParts.OCELOT_NOSE));
            }
            if(block == ModBlocks.PIG_TRAVELERS_BACKPACK || block == ModBlocks.HORSE_TRAVELERS_BACKPACK) {
                addAll(builder, models.get(ModelParts.PIG_NOSE));
            }
            if(block == ModBlocks.VILLAGER_TRAVELERS_BACKPACK || block == ModBlocks.IRON_GOLEM_TRAVELERS_BACKPACK) {
                addAll(builder, models.get(ModelParts.VILLAGER_NOSE));
            }
        }

        private Vector3f getVector(double x, double y, double z) {
            Vector3f ret = new Vector3f((float)x, (float)y, (float)z);
            rotate(ret, modelTransform.method_3509().method_22936());
            return ret;
        }

        private void rotate(Vector3f posIn, Matrix4fc transform) {
            Vector3f originIn = new Vector3f(0.5f, 0.5f, 0.5f);
            Vector4f vector4f = transform.transform(new Vector4f(posIn.x() - originIn.x(), posIn.y() - originIn.y(), posIn.z() - originIn.z(), 1.0F));
            posIn.set(vector4f.x() + originIn.x(), vector4f.y() + originIn.y(), vector4f.z() + originIn.z());
        }

        private class_777 createQuad(List<Vector3f> vectors, class_1058 sprite, class_2350 face,
                                     boolean hasAmbientOcclusion, int color, float u1x, float u2x,
                                     float v1x, float v2x, int tintIndex) {
            u1x = u1x / 16F;
            u2x = u2x / 16F;
            v1x = v1x / 16F;
            v2x = v2x / 16F;

            float u0 = sprite.method_4580(u1x);
            float u1 = sprite.method_4580(u2x);
            float v0 = sprite.method_4570(v1x);
            float v1 = sprite.method_4570(v2x);

            // Vector3f from your list IS Vector3fc (JOML implements the interface)
            Vector3fc pos0 = vectors.get(0);
            Vector3fc pos1 = vectors.get(1);
            Vector3fc pos2 = vectors.get(2);
            Vector3fc pos3 = vectors.get(3);

            // Pack UVs: lower 32 bits = U float bits, upper 32 bits = V float bits
            long packedUV0 = class_5611.method_76640(u0, v0);
            long packedUV1 = class_5611.method_76640(u0, v1);
            long packedUV2 = class_5611.method_76640(u1, v1);
            long packedUV3 = class_5611.method_76640(u1, v0);

            return new class_777(
                    pos0, pos1, pos2, pos3,
                    packedUV0, packedUV1, packedUV2, packedUV3,
                    tintIndex,
                    face,
                    sprite,
                    hasAmbientOcclusion,
                    0  // lightEmission
            );
        }

        @Override
        public void method_68513(class_5819 randomSource, List<class_10889> list) {
        }

        private void collectParts(List<class_10889> parts) {
            class_10817.class_10818 builder = new class_10817.class_10818();
            addBaseBackpack(builder);
            addTanks(builder);
            addSleepingBag(builder);
            addExtras(builder);
            parts.add(new class_10801(builder.method_68050(), true, this.particleIcon));
        }

        public void addBaseBackpack(class_10817.class_10818 builder) {
            if(isDyed && block == ModBlocks.STANDARD_TRAVELERS_BACKPACK) {
                addAll(builder, models.get(ModelParts.BASE_DYED));
                addAll(builder, models.get(ModelParts.EXTRAS));
            } else {
                addAll(builder, models.get(ModelParts.BASE));
            }
        }

        private void addTanks(class_10817.class_10818 builder) {
            if(renderInfo == null || !renderInfo.isEmpty()) {
                addAll(builder, models.get(ModelParts.TANKS));
                addFluids(builder, renderInfo);
            }
        }

        private void addFluids(class_10817.class_10818 builder, RenderInfo renderInfo) {
            if(renderInfo != null && !renderInfo.isEmpty()) {
                if(!renderInfo.getLeftFluidStack().isEmpty()) {
                    addFluid(builder, renderInfo.getLeftFluidStack(), (float)renderInfo.getLeftFluidStack().getAmount() / renderInfo.getCapacity(), 1.8F / 16D, 0);
                }
                if(!renderInfo.getRightFluidStack().isEmpty()) {
                    addFluid(builder, renderInfo.getRightFluidStack(), (float)renderInfo.getRightFluidStack().getAmount() / renderInfo.getCapacity(), 12.7F / 16D, 1);
                }
            }
        }

        private void addFluid(class_10817.class_10818 builder, FluidVariantWrapper fluidStack, float ratio, double xMin, int tintIndex) {
            if(fluidStack.isEmpty()) {
                return;
            }

            double yMin = 0.8D / 16D;
            double yMax = yMin + (ratio * 6.2D) / 16D;
            class_238 bounds = new class_238(xMin, yMin, 6.3D / 16D, xMin + 1.5D / 16D, yMax, 7.8D / 16D);

            int color = FluidVariantRendering.getColor(fluidStack.fluidVariant()) | -16777216;
            class_1058 still = FluidVariantRendering.getSprite(fluidStack.fluidVariant());
            float x1 = 0F;
            float x2 = 3F;
            float y1 = 0F;
            float y2 = ratio * 12F;
            float z1 = 0F;
            float z2 = 3F;

            builder.method_68051(createQuad(List.of(getVector(bounds.field_1323, bounds.field_1325, bounds.field_1321), getVector(bounds.field_1323, bounds.field_1325, bounds.field_1324), getVector(bounds.field_1320, bounds.field_1325, bounds.field_1324), getVector(bounds.field_1320, bounds.field_1325, bounds.field_1321)), still, class_2350.field_11036, false, color, x1, x2, z1, z2, tintIndex));
            builder.method_68051(createQuad(List.of(getVector(bounds.field_1320, bounds.field_1325, bounds.field_1321), getVector(bounds.field_1320, bounds.field_1322, bounds.field_1321), getVector(bounds.field_1323, bounds.field_1322, bounds.field_1321), getVector(bounds.field_1323, bounds.field_1325, bounds.field_1321)), still, class_2350.field_11043, false, color, x1, x2, y1, y2, tintIndex));
            builder.method_68051(createQuad(List.of(getVector(bounds.field_1323, bounds.field_1325, bounds.field_1324), getVector(bounds.field_1323, bounds.field_1322, bounds.field_1324), getVector(bounds.field_1320, bounds.field_1322, bounds.field_1324), getVector(bounds.field_1320, bounds.field_1325, bounds.field_1324)), still, class_2350.field_11035, false, color, x1, x2, y1, y2, tintIndex));
            builder.method_68051(createQuad(List.of(getVector(bounds.field_1323, bounds.field_1325, bounds.field_1321), getVector(bounds.field_1323, bounds.field_1322, bounds.field_1321), getVector(bounds.field_1323, bounds.field_1322, bounds.field_1324), getVector(bounds.field_1323, bounds.field_1325, bounds.field_1324)), still, class_2350.field_11039, false, color, z1, z2, y1, y2, tintIndex));
            builder.method_68051(createQuad(List.of(getVector(bounds.field_1320, bounds.field_1325, bounds.field_1324), getVector(bounds.field_1320, bounds.field_1322, bounds.field_1324), getVector(bounds.field_1320, bounds.field_1322, bounds.field_1321), getVector(bounds.field_1320, bounds.field_1325, bounds.field_1321)), still, class_2350.field_11034, false, color, z1, z2, y1, y2, tintIndex));
        }

        //Rebake sleeping bag to change sprite dynamically
        private void addSleepingBag(class_10817.class_10818 builder) {
            if(isSleepingBagDeployed) {
                return;
            }
            addAll(builder, models.get(ModelParts.SLEEPING_BAG_EXTRAS));
            class_1058 sprite = class_310.method_1551().method_72703().method_73025(class_10725.field_56382).method_4608(class_2960.method_60655(TravelersBackpack.MODID, "block/bag/" + class_1767.method_7791(sleepingBagColor).method_7792().toLowerCase(Locale.ENGLISH) + "_sleeping_bag"));
            rebakeSleepingBag(builder, sprite);
        }

        private static class_10817.class_10818 addAll(class_10817.class_10818 base, class_10817 collection) {
            for(class_2350 direction : class_2350.values()) {
                var quads = collection.method_68049(direction);
                for(var quad : quads) {
                    base.method_68053(direction, quad);
                }
            }
            var unculledQuads = collection.method_68049(null);
            for(var quad : unculledQuads) {
                base.method_68051(quad);
            }
            return base;
        }

        public List<class_777> getQuads() {
            List<class_10889> parts = new ArrayList<>();
            collectParts(parts);

            List<class_777> bakedQuads = new ArrayList<>();

            for(class_10889 part : parts) {
                for(class_2350 dir : class_2350.values()) {
                    bakedQuads.addAll(part.method_68509(dir));
                }
                bakedQuads.addAll(part.method_68509(null));
            }

            return bakedQuads;
        }

        @Override
        public class_1058 method_68511() {
            return this.particleIcon;
        }
    }

    public record UnbakedBlockStateModel(class_813 variant) implements CustomUnbakedBlockStateModel {
        public static final MapCodec<UnbakedBlockStateModel> CODEC = RecordCodecBuilder.mapCodec(instance ->
                instance.group(class_813.field_57947.forGetter(UnbakedBlockStateModel::variant)).apply(instance, UnbakedBlockStateModel::new));
        public static final class_2960 ID = class_2960.method_60655(TravelersBackpack.MODID, "backpack_loader");

        @Override
        public class_1087 method_68521(class_7775 modelBaker) {
            class_10819 resolvedModel = modelBaker.method_45872(variant.comp_3379());
            if(resolvedModel.method_68031() instanceof BackpackDynamicModel model) {
                return model.bakeBlockStateModel(modelBaker, resolvedModel, variant.comp_3754().method_67943());
            }
            throw new IllegalStateException("Expected BackpackDynamicModel, instead received " + resolvedModel.method_68031().getClass().getName());
        }

        @Override
        public void method_62326(class_10103 resolver) {
            resolver.markDependency(variant.comp_3379());
        }

        @Override
        public MapCodec<? extends CustomUnbakedBlockStateModel> codec() {
            return CODEC;
        }
    }

    public static final class Loader implements UnbakedModelDeserializer {
        public static final Loader INSTANCE = new Loader();

        @Override
        public class_1100 deserialize(JsonObject modelContents, JsonDeserializationContext context) {
            ImmutableMap.Builder<ModelParts, class_793> builder = ImmutableMap.builder();
            class_10419.class_10420.class_10421 texturesBuilder = new class_10419.class_10420.class_10421();
            if(modelContents.has("backpackTexture")) {
                class_2960 backpackTexture = class_2960.method_12829(modelContents.get("backpackTexture").getAsString());
                if(backpackTexture != null) {
                    texturesBuilder.method_65548("0", new class_4730(class_1059.field_5275, backpackTexture));
                }
            }
            if(modelContents.has("particle")) {
                class_2960 particleTexture = class_2960.method_12829(modelContents.get("particle").getAsString());
                if(particleTexture != null) {
                    texturesBuilder.method_65548("particle", new class_4730(class_1059.field_5275, particleTexture));
                }
            }
            //?
            texturesBuilder.method_65548("missing", new class_4730(class_1059.field_5275, class_1047.method_4539()));
            class_11515 renderTypeGroup = deserializeRenderType(modelContents);
            for(ModelParts part : ModelParts.values()) {
                addPartModel(builder, part, texturesBuilder.method_65547());
            }
            return new BackpackDynamicModel(builder.build(), renderTypeGroup);
        }

        private void addPartModel(ImmutableMap.Builder<ModelParts, class_793> builder, ModelParts modelPart, class_10419.class_10420 textures) {
            builder.put(modelPart, new class_793(null, null, true, class_809.field_4301, textures, class_2960.method_60655(TravelersBackpack.MODID, "block/backpack_" + modelPart.name().toLowerCase(Locale.ENGLISH))));
        }

        private static Map<class_2960, class_11515> RENDER_TYPES;

        public static class_11515 deserializeRenderType(JsonObject jsonObject) {
            if(jsonObject.has("render_type")) {
                String renderTypeHintName = class_3518.method_15265(jsonObject, "render_type");
                return RENDER_TYPES.get(class_2960.method_60654(renderTypeHintName));
            }
            return class_11515.field_60923;
        }

        public static void loadVanillaRenderTypes() {
            RENDER_TYPES = new HashMap<>();
            RENDER_TYPES.put(class_2960.method_60656("solid"), class_11515.field_60923);
            RENDER_TYPES.put(class_2960.method_60656("cutout"), class_11515.field_60925);
            // Generally entity/item rendering shouldn't use mipmaps, so cutout_mipped has them off by default. To enforce them, use cutout_mipped_all.
            RENDER_TYPES.put(class_2960.method_60656("cutout_mipped"), class_11515.field_60925);
            RENDER_TYPES.put(class_2960.method_60656("cutout_mipped_all"), class_11515.field_60925);
            RENDER_TYPES.put(class_2960.method_60656("translucent"), class_11515.field_60926);
            RENDER_TYPES.put(class_2960.method_60656("tripwire"), class_11515.field_60927);
        }
    }

    private enum ModelParts {
        BASE,
        BASE_DYED,
        EXTRAS,
        TANKS,
        SLEEPING_BAG,
        SLEEPING_BAG_EXTRAS,
        //Noses, Extras
        FOX_NOSE,
        OCELOT_NOSE,
        WOLF_NOSE,
        VILLAGER_NOSE,
        PIG_NOSE,
        WARDEN_HORNS
    }
}