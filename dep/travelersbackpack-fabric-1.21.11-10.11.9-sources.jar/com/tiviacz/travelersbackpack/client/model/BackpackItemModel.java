package com.tiviacz.travelersbackpack.client.model;

import com.google.common.base.Supplier;
import com.google.common.base.Suppliers;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.tiviacz.travelersbackpack.init.ModDataComponents;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;
import org.joml.Vector3fc;

import java.util.List;
import java.util.Set;
import java.util.function.Consumer;
import net.minecraft.class_10401;
import net.minecraft.class_10402;
import net.minecraft.class_10430;
import net.minecraft.class_10439;
import net.minecraft.class_10442;
import net.minecraft.class_10444;
import net.minecraft.class_10508;
import net.minecraft.class_10819;
import net.minecraft.class_1086;
import net.minecraft.class_11566;
import net.minecraft.class_11659;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_4587;
import net.minecraft.class_4722;
import net.minecraft.class_638;
import net.minecraft.class_777;
import net.minecraft.class_804;
import net.minecraft.class_809;
import net.minecraft.class_811;
import net.minecraft.class_9334;

public class BackpackItemModel implements class_10439 {
    private static final class_809 ITEM_TRANSFORMS = createItemTransforms();

    private static class_809 createItemTransforms() {
        return new class_809(
                new class_804(
                        new Vector3f(60, -180, 0),
                        new Vector3f(0, 1.5f / 16f, 0.5f / 16f),
                        new Vector3f(0.7f, 0.7f, 0.7f)
                ),
                new class_804(
                        new Vector3f(60, -180, 0),
                        new Vector3f(0, 1.5f / 16f, 0.5f / 16f),
                        new Vector3f(0.7f, 0.7f, 0.7f)
                ),
                new class_804(
                        new Vector3f(0, -90, 12.5f),
                        new Vector3f(1.13f / 16f, 6f / 16f, 2f / 16f),
                        new Vector3f(0.68f, 0.68f, 0.68f)
                ),
                new class_804(
                        new Vector3f(0, -90, 12.5f),
                        new Vector3f(1.13f / 16f, 6f / 16f, 2f / 16f),
                        new Vector3f(0.68f, 0.68f, 0.68f)
                ),
                new class_804(
                        new Vector3f(0, 180, 0),
                        new Vector3f(0, 14.5f / 16f, 0),
                        new Vector3f(1, 1, 1)
                ),
                new class_804(
                        new Vector3f(30, -38, 0),
                        new Vector3f(-0.25f / 16f, 2.25f / 16f, 0),
                        new Vector3f(1, 1, 1)
                ),
                new class_804(
                        new Vector3f(0, 0, 0),
                        new Vector3f(0, 2f / 16f, 0),
                        new Vector3f(0.5f, 0.5f, 0.5f)
                ),
                new class_804(
                        new Vector3f(0, 180, 0),
                        new Vector3f(0, 2.25f / 16f, 0),
                        new Vector3f(1, 1, 1)
                ),
                new class_804(
                        new Vector3f(0, 180, 0),
                        new Vector3f(0, 2.25f / 16f, 0),
                        new Vector3f(1, 1, 1)
                )
        );
    }

    private final BackpackDynamicModel.DynamicBlockStateModel baseModel;
    private final List<class_10401> tintSources;
    private final Supplier<Vector3fc[]> extents;

    public BackpackItemModel(BackpackDynamicModel.DynamicBlockStateModel baseModel, List<class_10401> tintSources) {
        this.baseModel = baseModel;
        this.tintSources = tintSources;
        this.extents = Suppliers.memoize(() -> class_10430.method_67990(baseModel.getQuads()));
    }

    @Override
    public void method_65584(class_10444 stackRenderState, class_1799 stack, class_10442 itemModelResolver, class_811 displayContext, @Nullable class_638 clientLevel, @Nullable class_11566 itemOwner, int seed) {
        stackRenderState.method_70946(this);

        class_10444.class_10446 renderLayer = stackRenderState.method_65601();
        if(stack.method_7958()) {
            renderLayer.method_65615(class_10444.class_10445.field_55342);
            stackRenderState.method_70946(class_10444.class_10445.field_55342);
        }

        int k = this.tintSources.size();
        int[] aint = renderLayer.method_65613(k);

        for(int i = 0; i < k; i++) {
            int j = this.tintSources.get(i).method_65389(stack, clientLevel, itemOwner != null ? itemOwner.method_72393() : null);
            aint[i] = j;
            stackRenderState.method_70946(j);
        }

        setProperties(stack, stackRenderState);

        renderLayer.method_67995(extents);
        renderLayer.method_67996(true);
        renderLayer.method_67994(baseModel.method_68511());
        renderLayer.method_67993(ITEM_TRANSFORMS.method_3503(displayContext));
        //baseModel.getQuads().forEach(quad -> renderLayer.emitter().fromBakedQuad(quad).emit());
        renderLayer.method_67997().addAll(baseModel.getQuads());
        SpecialRenderer specialRenderer = new SpecialRenderer();
        specialRenderer.setModelRenderParameters(aint, baseModel.getQuads());

        renderLayer.method_65617(specialRenderer, specialRenderer.method_65704(stack));
    }

    private void setProperties(class_1799 stack, class_10444 stackRenderState) {
        if(baseModel instanceof BackpackDynamicModel.DynamicBlockStateModel backpackModel) {
            backpackModel.isDyed = stack.method_57826(class_9334.field_49644);
            backpackModel.renderInfo = stack.method_58694(ModDataComponents.RENDER_INFO);
            backpackModel.sleepingBagColor = stack.method_58695(ModDataComponents.SLEEPING_BAG_COLOR, class_1767.field_7964.method_7789());
            backpackModel.isSleepingBagDeployed = false;
            backpackModel.block = class_2248.method_9503(stack.method_7909());

            if(backpackModel.renderInfo != null) {
                stackRenderState.method_70946("RenderInfo");
                stackRenderState.method_70946(backpackModel.renderInfo.hasTanks());

                stackRenderState.method_70946("LeftTank");
                stackRenderState.method_70946(backpackModel.renderInfo.getLeftFluidStack().fluidVariant().getFluid());
                stackRenderState.method_70946(backpackModel.renderInfo.getLeftFluidStack().fluidVariant().getComponents());
                stackRenderState.method_70946(backpackModel.renderInfo.getLeftFluidStack().getAmount());

                stackRenderState.method_70946("RightTank");
                stackRenderState.method_70946(backpackModel.renderInfo.getRightFluidStack().fluidVariant().getFluid());
                stackRenderState.method_70946(backpackModel.renderInfo.getRightFluidStack().fluidVariant().getComponents());
                stackRenderState.method_70946(backpackModel.renderInfo.getRightFluidStack().getAmount());
            }

            if(backpackModel.sleepingBagColor != class_1767.field_7964.method_7789()) {
                stackRenderState.method_70946("SleepingBagColor");
                stackRenderState.method_70946(backpackModel.sleepingBagColor);
            }
        }
    }

    public record Unbaked(class_2960 base, List<class_10401> tintSources) implements class_10439.class_10441 {
        public static final MapCodec<Unbaked> MAP_CODEC = RecordCodecBuilder.mapCodec(builder -> builder.group(
                class_2960.field_25139.fieldOf("base").forGetter(Unbaked::base),
                class_10402.field_55234.listOf().optionalFieldOf("tintSources", List.of()).forGetter(Unbaked::tintSources)
        ).apply(builder, Unbaked::new));

        @Override
        public MapCodec<? extends class_10439.class_10441> method_65585() {
            return MAP_CODEC;
        }

        @Override
        public class_10439 method_65587(class_10440 context) {
            class_10819 resolved = context.comp_3390().method_45872(base);
            if(resolved.method_68031() instanceof BackpackDynamicModel baseModel) {
                return new BackpackItemModel(baseModel.bakeBlockStateModel(context.comp_3390(), resolved, class_1086.field_63619), tintSources);
            }
            throw new IllegalStateException("Expected BackpackDynamicModel, instead received " + resolved.getClass().getName());
        }

        @Override
        public void method_62326(class_10103 resolver) {
            resolver.markDependency(base);
        }
    }

    public static class SpecialRenderer implements class_10508 {
        private int[] tintLayers;
        private List<class_777> baseModel;

      /*  @Override
        public void render(ItemDisplayContext displayContext, PoseStack poseStack, MultiBufferSource buffer, int combinedLight, int packedOverlay, boolean hasFoil) {
            ItemRenderer.renderItem(displayContext, poseStack, buffer, combinedLight, packedOverlay, tintLayers, baseModel, Sheets.translucentItemSheet(), hasFoil ? ItemStackRenderState.FoilType.STANDARD : ItemStackRenderState.FoilType.NONE);
        }*/

        @Override
        public void method_65699(class_811 displayContext, class_4587 poseStack, class_11659 collector, int combinedLight, int packedOverlay, boolean hasFoil, int outlineColor) {
            collector.method_73480(poseStack, displayContext, combinedLight, packedOverlay, outlineColor, tintLayers, baseModel, class_4722.method_76545(), hasFoil ? class_10444.class_10445.field_55342 : class_10444.class_10445.field_55341);
        }

        public void setModelRenderParameters(int[] tintLayers, List<class_777> baseModel) {
            this.tintLayers = tintLayers;
            this.baseModel = baseModel;
        }

        @Override
        public void method_72175(Consumer<Vector3fc> consumer) {

        }
    }
}