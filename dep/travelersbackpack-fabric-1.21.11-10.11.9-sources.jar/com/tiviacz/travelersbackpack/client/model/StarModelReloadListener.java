package com.tiviacz.travelersbackpack.client.model;

import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.tiviacz.travelersbackpack.TravelersBackpackClient;
import net.fabricmc.fabric.api.resource.ResourceReloadListenerKeys;
import net.fabricmc.fabric.api.resource.SimpleSynchronousResourceReloadListener;
import net.minecraft.class_1087;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3300;
import java.util.Collection;
import java.util.List;

public class StarModelReloadListener implements SimpleSynchronousResourceReloadListener {
    public static final StarModelReloadListener INSTANCE = new StarModelReloadListener();
    public static final class_2960 ID = class_2960.method_60655(TravelersBackpack.MODID, "star_model");

    private class_1087 starModel;

    public class_1087 getStarModel() {
        return starModel;
    }

    @Override
    public void method_14491(class_3300 manager) {
        starModel = class_310.method_1551().method_1554().getModel(TravelersBackpackClient.STAR_MODEL_KEY);
    }

    @Override
    public class_2960 getFabricId() {
        return ID;
    }

    @Override
    public Collection<class_2960> getFabricDependencies() {
        return List.of(ResourceReloadListenerKeys.MODELS);
    }
}