package com.tiviacz.travelersbackpack.client.model;

import net.minecraft.class_4587;
import net.minecraft.class_630;
import org.joml.Quaternionf;

public class BackpackModelPart {
    public float x = 0;
    public float y = 0;
    public float z = 0;
    public float xRot = 0;
    public float yRot = 0;
    public float zRot = 0;
    public float xScale = 1.0f;
    public float yScale = 1.0f;
    public float zScale = 1.0f;

    public BackpackModelPart() {
    }

    public void copyFrom(class_630 parentModelPart) {
        this.xScale = parentModelPart.field_37938;
        this.yScale = parentModelPart.field_37939;
        this.zScale = parentModelPart.field_37940;
        this.xRot = parentModelPart.field_3654;
        this.yRot = parentModelPart.field_3675;
        this.zRot = parentModelPart.field_3674;
        this.x = parentModelPart.field_3657;
        this.y = parentModelPart.field_3656;
        this.z = parentModelPart.field_3655;
    }

    protected void translateAndRotate(class_4587 poseStack) {
        poseStack.method_46416(this.x / 16.0f, this.y / 16.0f, this.z / 16.0f);
        if(this.xRot != 0.0f || this.yRot != 0.0f || this.zRot != 0.0f) {
            poseStack.method_22907(new Quaternionf().rotationZYX(this.zRot, this.yRot, this.xRot));
        }
        if(this.xScale != 1.0f || this.yScale != 1.0f || this.zScale != 1.0f) {
            poseStack.method_22905(this.xScale, this.yScale, this.zScale);
        }
    }
}