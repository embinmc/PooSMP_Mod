package com.tiviacz.travelersbackpack.client.screens;

import com.mojang.datafixers.util.Pair;
import com.tiviacz.travelersbackpack.attachment.AttachmentUtils;
import com.tiviacz.travelersbackpack.components.BackpackContainerContents;
import com.tiviacz.travelersbackpack.config.TravelersBackpackConfig;
import com.tiviacz.travelersbackpack.handlers.KeybindHandler;
import com.tiviacz.travelersbackpack.init.ModDataComponents;
import com.tiviacz.travelersbackpack.init.ModItems;
import com.tiviacz.travelersbackpack.inventory.Tiers;
import com.tiviacz.travelersbackpack.inventory.menu.slot.ToolSlotItemHandler;
import com.tiviacz.travelersbackpack.item.HoseItem;
import com.tiviacz.travelersbackpack.network.ServerboundActionTagPacket;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import net.minecraft.class_1041;
import net.minecraft.class_11909;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_437;

public class ToolsScreen extends class_437 {
    private static final double REF_W = 1920.0;
    private static final double REF_H = 1080.0;
    private long openStartMs = -1;

    protected int hoveredResult = -1;
    private boolean swapWithRelease = true;

    public ToolsScreen() {
        super(class_2561.method_43471("screen.travelersbackpack.tools_overlay"));
    }

    private float getOpenProgress() {
        long now = System.currentTimeMillis();
        if(openStartMs < 0) openStartMs = now;

        float durMs = 180.0F;
        return class_3532.method_15363((now - openStartMs) / durMs, 0.0f, 1.0f);
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        Pair<Integer, Integer> scaled = getScaledWindow(false);
        GLFW.glfwSetCursorPos(class_310.method_1551().method_22683().method_4490(), scaled.getFirst(), scaled.getSecond());
    }

    @Override
    public void method_25420(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        //Skip
    }

    @Override
    public void method_25394(class_332 graphics, int mouseX, int mouseY, float partialTick) {
        class_310 mc = class_310.method_1551();
        class_1657 player = mc.field_1724;

        Pair<Integer, Integer> scaled = getScaledWindow(true);
        float progress = getOpenProgress();

        class_1799 backpack = AttachmentUtils.getWearingBackpack(player);
        class_1799 heldItem = !player.method_6047().method_7960() ? player.method_6047() : player.method_6079();

        //Hose Menu
        if(heldItem.method_7909() instanceof HoseItem) {
            int hoveredResult = RadialToolsOverlay.renderRadial(graphics, backpack, heldItem, hoseMenu, false, scaled.getFirst(), scaled.getSecond(), mouseX, mouseY, partialTick, progress);

            if(!KeybindHandler.isKeyDown(KeybindHandler.SWAP_TOOL)) {
                selectHoseAction(mc.field_1724, hoveredResult);
                method_25419();
            }
            return;
        }

        class_2371<class_1799> tools = backpack.method_58695(ModDataComponents.TOOLS_CONTAINER, new BackpackContainerContents(backpack.method_58695(ModDataComponents.TOOL_SLOTS, Tiers.LEATHER.getToolSlots()))).getItems();
        int nonEmptyCount = getNonEmptyTools(tools).size();

        boolean canAdd = ToolSlotItemHandler.isValid(heldItem) && nonEmptyCount < tools.size();
        int hoveredResult = RadialToolsOverlay.renderRadial(graphics, backpack, heldItem, tools, canAdd, scaled.getFirst(), scaled.getSecond(), mouseX, mouseY, partialTick, progress);
        this.hoveredResult = hoveredResult;

        if(!KeybindHandler.isKeyDown(KeybindHandler.SWAP_TOOL)) {
            if(hoveredResult != -1) {
                if(swapWithRelease && TravelersBackpackConfig.CLIENT.toolsOverlay.swapOnClose.get()) {
                    ServerboundActionTagPacket.create(ServerboundActionTagPacket.SWAP_TOOL, hoveredResult, 0);
                }
            }
            method_25419();
        }
    }

    public Pair<Integer, Integer> getScaledWindow(boolean scaled) {
        class_1041 mainWindow = class_310.method_1551().method_22683();

        int sw = scaled ? mainWindow.method_4486() : mainWindow.method_4480();
        int sh = scaled ? mainWindow.method_4502() : mainWindow.method_4507();

        int cx = sw / 2;
        int cy = sh / 2;

        int offXpx = TravelersBackpackConfig.CLIENT.toolsOverlay.offsetX.get(); // px@1920
        int offYpx = TravelersBackpackConfig.CLIENT.toolsOverlay.offsetY.get(); // px@1080

        double px = offXpx / REF_W;
        double py = offYpx / REF_H;

        int scaledWidth = (int)Math.round(cx + px * sw);
        int scaledHeight = (int)Math.round(cy + py * sh);
        return Pair.of(scaledWidth, scaledHeight);
    }

    public void selectHoseAction(class_1657 player, int hoveredResult) {
        if(hoveredResult == 0 || hoveredResult == 1 || hoveredResult == 4) {
            int mode = 1;
            if(hoveredResult == 0) mode = 1;
            if(hoveredResult == 1) mode = 3;
            if(hoveredResult == 4) mode = 2;
            ServerboundActionTagPacket.create(ServerboundActionTagPacket.SWITCH_HOSE_MODE, mode);
            player.method_7353(getNextModeMessage(0, mode), true);
        }
        if(hoveredResult == 2 || hoveredResult == 3) {
            int tank = hoveredResult == 2 ? 2 : 1;
            ServerboundActionTagPacket.create(ServerboundActionTagPacket.SWITCH_HOSE_TANK, tank);
            player.method_7353(getNextModeMessage(1, tank), true);
        }
    }

    public static class_2561 getNextModeMessage(int changedMode, int data) {
        if(changedMode == 0) {
            if(data == HoseItem.SPILL_MODE) {
                return class_2561.method_43471("item.travelersbackpack.hose.spill");
            } else if(data == HoseItem.DRINK_MODE) {
                return class_2561.method_43471("item.travelersbackpack.hose.drink");
            }
            return class_2561.method_43471("item.travelersbackpack.hose.suck");
        } else {
            if(data == 1) {
                return class_2561.method_43471("item.travelersbackpack.hose.tank_left");
            } else {
                return class_2561.method_43471("item.travelersbackpack.hose.tank_right");
            }
        }
    }

    public static class_2371<class_1799> getNonEmptyTools(class_2371<class_1799> inventory) {
        class_2371<class_1799> tools = class_2371.method_10211();
        for(class_1799 itemStack : inventory) {
            if(!itemStack.method_7960()) {
                tools.add(itemStack);
            }
        }
        return tools;
    }

    public static final class_2371<class_1799> hoseMenu = createHoseMenu();

    public static class_2371<class_1799> createHoseMenu() {
        class_2371<class_1799> stacks = class_2371.method_37434(5);
        class_1799 suckHose = new class_1799(ModItems.HOSE);
        suckHose.method_57379(ModDataComponents.HOSE_MODES, List.of(1, 0));
        class_1799 spitHose = new class_1799(ModItems.HOSE);
        spitHose.method_57379(ModDataComponents.HOSE_MODES, List.of(2, 0));
        class_1799 drinkHose = new class_1799(ModItems.HOSE);
        drinkHose.method_57379(ModDataComponents.HOSE_MODES, List.of(3, 0));
        stacks.add(suckHose);
        stacks.add(drinkHose);
        stacks.add(new class_1799(ModItems.BACKPACK_TANK));
        stacks.add(new class_1799(ModItems.BACKPACK_TANK));
        stacks.add(spitHose);
        return stacks;
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public boolean method_25402(class_11909 event, boolean doubleClick) {
        if(this.hoveredResult != -1) {
            swapWithRelease = false;
            ServerboundActionTagPacket.create(ServerboundActionTagPacket.SWAP_TOOL, hoveredResult, event.method_74245());
            return true;
        }
        return super.method_25402(event, doubleClick);
    }
}