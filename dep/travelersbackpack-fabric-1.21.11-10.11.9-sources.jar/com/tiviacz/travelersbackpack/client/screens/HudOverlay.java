package com.tiviacz.travelersbackpack.client.screens;

import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.tiviacz.travelersbackpack.attachment.AttachmentUtils;
import com.tiviacz.travelersbackpack.components.RenderInfo;
import com.tiviacz.travelersbackpack.config.TravelersBackpackConfig;
import com.tiviacz.travelersbackpack.init.ModDataComponents;
import com.tiviacz.travelersbackpack.inventory.FluidTank;
import com.tiviacz.travelersbackpack.item.HoseItem;
import com.tiviacz.travelersbackpack.util.RenderHelper;
import net.minecraft.class_1041;
import net.minecraft.class_10799;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1934;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_9779;

public class HudOverlay {
    public static final class_2960 OVERLAY = class_2960.method_60655(TravelersBackpack.MODID, "textures/gui/overlay.png");

    public static void renderOverlay(class_332 guiGraphics, class_9779 deltaTracker) {
        if(!TravelersBackpackConfig.CLIENT.overlay.enableOverlay.get()) return;

        class_310 mc = class_310.method_1551();
        class_1657 player = mc.field_1724;
        class_1041 window = mc.method_22683();

        if(!AttachmentUtils.isWearingBackpack(player) || mc.field_1690.field_1842 || (mc.field_1761 != null && mc.field_1761.method_2920() == class_1934.field_9219))
            return;

        class_1799 stack = AttachmentUtils.getWearingBackpack(player);

        int x = window.method_4486() - TravelersBackpackConfig.CLIENT.overlay.offsetX.get();
        int y = window.method_4502() - TravelersBackpackConfig.CLIENT.overlay.offsetY.get();

        RenderInfo info = stack.method_58695(ModDataComponents.RENDER_INFO, RenderInfo.EMPTY);
        if(info.isEmpty()) return;

        if(!info.getRightFluidStack().isEmpty()) {
            FluidTank right = new FluidTank(info.getCapacity());
            right.setFluid(info.getRightFluidStack());
            drawGuiTank(guiGraphics, right, x + 1, y, 21, 8);
        }

        if(!info.getLeftFluidStack().isEmpty()) {
            FluidTank left = new FluidTank(info.getCapacity());
            left.setFluid(info.getLeftFluidStack());
            drawGuiTank(guiGraphics, left, x - 11, y, 21, 8);
        }

        int tankSel = 0;
        if(player != null && player.method_6047().method_7909() instanceof HoseItem) {
            tankSel = HoseItem.getHoseTank(player.method_6047());
        }

        guiGraphics.method_25290(class_10799.field_56883, OVERLAY, x, y, (tankSel == 2) ? 0 : 10, 0, 10, 23, 256, 256);
        guiGraphics.method_25290(class_10799.field_56883, OVERLAY, x - 12, y, (tankSel == 1) ? 0 : 10, 0, 10, 23, 256, 256);
    }

    public static void drawGuiTank(class_332 guiGraphics, FluidTank tank, int startX, int startY, int height, int width) {
        RenderHelper.renderScreenTank(guiGraphics, tank, startX, startY, 0, height, width);
    }
}