package com.tiviacz.travelersbackpack.client.screens;

import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.tiviacz.travelersbackpack.components.RenderInfo;
import com.tiviacz.travelersbackpack.config.TravelersBackpackConfig;
import com.tiviacz.travelersbackpack.init.ModDataComponents;
import com.tiviacz.travelersbackpack.inventory.FluidTank;
import com.tiviacz.travelersbackpack.inventory.upgrades.tanks.TankWidget;
import com.tiviacz.travelersbackpack.item.BackpackTankItem;
import com.tiviacz.travelersbackpack.item.HoseItem;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_10799;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2371;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_9848;

public final class RadialToolsOverlay {
    public static final class_2960 TOOLS_OVERLAY = class_2960.method_60655(TravelersBackpack.MODID, "textures/gui/tools_overlay.png");
    private static final int ICON_SIZE = 16;
    private static final int ITEM_RING_RADIUS = 42;
    private static final int DEADZONE_RADIUS = 30;

    public static final int ADD_NEW = -999;

    //Client only indicator to draw or nah
    public static boolean drawCrosshair = true;

    public static int renderRadial(class_332 guiGraphics, class_1799 backpack, class_1799 heldItem, class_2371<class_1799> tools, boolean canAdd, int centerX, int centerY, int mouseX, int mouseY, float partialTick, float openProgress) {
        drawCrosshair = true;
        if(tools == null) return -1;

        openProgress = class_3532.method_15363(openProgress, 0.0F, 1.0F);
        float t = openProgress;
        t = t * t * (3.0F - 2.0F * t);
        float scale = t;

        guiGraphics.method_51448().pushMatrix();
        guiGraphics.method_51448().translate(centerX, centerY);
        guiGraphics.method_51448().scale(scale, scale);
        guiGraphics.method_51448().translate(-centerX, -centerY);

        int[] plusSlotRef = new int[1];
        ArrayList<Integer> segToSlot = buildSegToSlot(tools, canAdd, plusSlotRef);
        int plusSlot = plusSlotRef[0];

        int x = centerX - 256 / 2;
        int y = centerY - 256 / 2;
        double opacity = Math.min(t, TravelersBackpackConfig.CLIENT.toolsOverlay.opacity.get());

        int i = class_9848.method_61317((float)opacity);
        guiGraphics.method_25293(class_10799.field_56883, TOOLS_OVERLAY, x, y, 0, 0, 256, 256, 256, 256, 256, 256, i);

        int result;

        if(heldItem.method_7909() instanceof HoseItem) {
            result = renderRadialItems(guiGraphics, backpack, tools, false, false, segToSlot, plusSlot, centerX, centerY, mouseX, mouseY);
        } else {
            result = renderRadialItems(guiGraphics, backpack, tools, canAdd, heldItem.method_7960(), segToSlot, plusSlot, centerX, centerY, mouseX, mouseY);
        }

        guiGraphics.method_51448().popMatrix();
        return result;
    }

    public static int renderRadialItems(class_332 guiGraphics, class_1799 backpack, class_2371<class_1799> tools, boolean canAdd, boolean handEmpty, ArrayList<Integer> segToSlot, int plusSlot, int centerX, int centerY, int mouseX, int mouseY) {
        class_310 mc = class_310.method_1551();
        class_327 font = mc.field_1772;

        int segments = segToSlot.size();
        int hoveredSeg = getHoveredIndex(centerX, centerY, mouseX, mouseY, segments);

        int hoveredResult = -1;
        boolean hoveredIsPlus = false;

        if(hoveredSeg >= 0 && hoveredSeg < segToSlot.size()) {
            int slot = segToSlot.get(hoveredSeg);
            hoveredIsPlus = (canAdd && plusSlot != -1 && slot == plusSlot && tools.get(slot).method_7960());
            hoveredResult = hoveredIsPlus ? ADD_NEW : slot;
        }

        if(segments == 0 && hoveredSeg == -1) {
            return -1;
        }

        float step = (float)(2.0 * Math.PI / segments);
        float start = (float)(-Math.PI / 2.0);

        for(int seg = 0; seg < segments; seg++) {
            float ang = start + seg * step;

            int x = centerX + class_3532.method_15375(class_3532.method_15362(ang) * ITEM_RING_RADIUS) - ICON_SIZE / 2;
            int y = centerY + class_3532.method_15375(class_3532.method_15374(ang) * ITEM_RING_RADIUS) - ICON_SIZE / 2;

            boolean isHovered = (seg == hoveredSeg);
            if(isHovered) {
                guiGraphics.method_25294(x - 2, y - 2, x + ICON_SIZE + 2, y + ICON_SIZE + 2, 0x80FFFFFF);
            }

            int slot = segToSlot.get(seg);
            boolean isPlusHere = (canAdd && plusSlot != -1 && slot == plusSlot && tools.get(slot).method_7960());

            if(isPlusHere) {
                renderPlusButton(guiGraphics, font, x, y);
            } else {
                class_1799 stack = tools.get(slot);
                guiGraphics.method_51427(stack, x, y);
                guiGraphics.method_51431(font, stack, x, y);
            }
        }

        boolean renderCenteredItem = true;

        if(hoveredIsPlus) {
            guiGraphics.method_51438(font, class_2561.method_43471("screen.travelersbackpack.add"), mouseX, mouseY);
        } else if(hoveredResult >= 0) {
            class_1799 hoveredStack = tools.get(hoveredResult);
            if(!hoveredStack.method_7960()) {
                List<class_2561> tooltip = (TravelersBackpackConfig.CLIENT.toolsOverlay.showTooltip.get() || hoveredStack.method_7909() instanceof HoseItem) ? getTooltipFromItem(mc, hoveredStack) : new ArrayList<>(List.of(hoveredStack.method_7964()));
                //Fluid contents for backpack tanks
                if(hoveredStack.method_7909() instanceof BackpackTankItem) {
                    if(!backpack.method_58695(ModDataComponents.RENDER_INFO, RenderInfo.EMPTY).isEmpty()) {
                        RenderInfo renderInfo = backpack.method_58694(ModDataComponents.RENDER_INFO);
                        if(hoveredResult == 2) {
                            FluidTank rightTank = new FluidTank(renderInfo.getCapacity());
                            rightTank.setFluid(renderInfo.getRightFluidStack());
                            tooltip.addAll(TankWidget.getTankTooltip(rightTank));
                        }
                        if(hoveredResult == 3) {
                            FluidTank leftTank = new FluidTank(renderInfo.getCapacity());
                            leftTank.setFluid(renderInfo.getLeftFluidStack());
                            tooltip.addAll(TankWidget.getTankTooltip(leftTank));
                        }
                    }
                } else {
                    renderCenteredItem = false;
                    renderCenteredText(guiGraphics, handEmpty ? class_2561.method_43471("screen.travelersbackpack.take") : class_2561.method_43471("screen.travelersbackpack.swap"), centerX, centerY);
                }
                guiGraphics.method_64038(font, tooltip, hoveredStack.method_32347(), mouseX, mouseY);
            }
        }

        if(renderCenteredItem) {
            if(TravelersBackpackConfig.CLIENT.toolsOverlay.renderBackpackIconInCenter.get()) {
                drawCrosshair = false;
                renderCenteredItem(guiGraphics, font, backpack, centerX, centerY, 1.25F);
            }
        }

        return hoveredResult;
    }

    private static ArrayList<Integer> buildSegToSlot(class_2371<class_1799> tools, boolean canAdd, int[] outPlusSlot) {
        ArrayList<Integer> segToSlot = new ArrayList<>();

        for(int i = 0; i < tools.size(); i++) {
            if(!tools.get(i).method_7960()) segToSlot.add(i);
        }

        int plusSlot = -1;
        if(canAdd) {
            for(int i = 0; i < tools.size(); i++) {
                if(tools.get(i).method_7960()) {
                    plusSlot = i;
                    break;
                }
            }

            if(plusSlot != -1) {
                int insertPos = 0;
                while(insertPos < segToSlot.size() && segToSlot.get(insertPos) < plusSlot) insertPos++;
                segToSlot.add(insertPos, plusSlot);
            }
        }

        outPlusSlot[0] = plusSlot;
        return segToSlot;
    }

    public static List<class_2561> getTooltipFromItem(class_310 minecraft, class_1799 item) {
        return item.method_7950(class_1792.class_9635.method_59528(minecraft.field_1687), minecraft.field_1724, class_1836.class_1837.field_41070);
    }

    public static int getHoveredIndex(int cx, int cy, int mx, int my, int segments) {
        if(segments == 0) {
            return -1;
        }

        int dx = mx - cx;
        int dy = my - cy;

        if(dx * dx + dy * dy < DEADZONE_RADIUS * DEADZONE_RADIUS) return -1;

        double ang = Math.atan2(dy, dx);
        ang = normalize0To2Pi(ang);

        double start = Math.PI * 1.5;
        double rel = normalize0To2Pi(ang - start);

        double step = (Math.PI * 2.0) / segments;

        int idx = (int)Math.floor((rel + step / 2.0) / step);

        idx = ((idx % segments) + segments) % segments;
        return idx;
    }

    private static void renderCenteredText(class_332 guiGraphics, class_2561 text, int centerX, int centerY) {
        drawCrosshair = false;
        class_327 textRenderer = class_310.method_1551().field_1772;
        int textWidth = textRenderer.method_27525(text);
        int textHeight = textRenderer.field_2000;

        int textX = centerX - textWidth / 2;
        int textY = centerY - textHeight / 2;

        guiGraphics.method_44379(textX, textY, textX + 40, textY + 40);
        guiGraphics.method_51439(class_310.method_1551().field_1772, text, textX, textY, 0xFFFFFFFF, true);
        guiGraphics.method_44380();
    }

    private static void renderPlusButton(class_332 guiGraphics, class_327 font, int x, int y) {
        String plus = "+";
        float s = 1.25F;

        int px = (int)(x + ICON_SIZE / 2f - font.method_1727(plus) / 2f);
        int py = (int)(y + ICON_SIZE / 2f - font.field_2000 / 2f);

        float cx = x + ICON_SIZE / 2f;
        float cy = y + ICON_SIZE / 2f;

        guiGraphics.method_51448().pushMatrix();

        guiGraphics.method_51448().translate(cx, cy);
        guiGraphics.method_51448().scale(s, s);
        guiGraphics.method_51448().translate(-cx, -cy);

        guiGraphics.method_51448().pushMatrix();
        guiGraphics.method_51448().translate(0.5F, 1.5F);
        guiGraphics.method_44379(px, py, px + 8, py + 8);
        guiGraphics.method_51433(font, plus, px, py, 0xFFFFFFFF, false);
        guiGraphics.method_44380();
        guiGraphics.method_51448().popMatrix();

        guiGraphics.method_51448().popMatrix();
    }

    private static void renderCenteredItem(class_332 guiGraphics, class_327 font, class_1799 stack, int centerX, int centerY, float scale) {
        guiGraphics.method_51448().pushMatrix();
        guiGraphics.method_51448().translate(centerX, centerY);
        guiGraphics.method_51448().scale(scale, scale);
        guiGraphics.method_51427(stack, -8, -8);
        guiGraphics.method_51431(font, stack, -8, -8);
        guiGraphics.method_51448().popMatrix();
    }

    private static double normalize0To2Pi(double a) {
        double twoPi = Math.PI * 2.0;
        a %= twoPi;
        if(a < 0) a += twoPi;
        return a;
    }
}