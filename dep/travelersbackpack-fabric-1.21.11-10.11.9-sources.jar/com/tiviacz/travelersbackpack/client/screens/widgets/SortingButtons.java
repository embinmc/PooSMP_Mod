package com.tiviacz.travelersbackpack.client.screens.widgets;

import com.tiviacz.travelersbackpack.client.screens.BackpackScreen;
import com.tiviacz.travelersbackpack.inventory.sorter.ContainerSorter;
import com.tiviacz.travelersbackpack.inventory.upgrades.Point;
import com.tiviacz.travelersbackpack.network.ServerboundActionTagPacket;
import com.tiviacz.travelersbackpack.util.KeyHelper;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_10799;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;

public class SortingButtons extends WidgetBase<BackpackScreen> {
    public SortingButtons(BackpackScreen screen, Point pos, int width, int height) {
        super(screen, pos, width, height);
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTicks) {
        guiGraphics.method_25290(class_10799.field_56883, BackpackScreen.ICONS, pos.x(), pos.y(), 77, 54, width, height, 256, 256);
        if(isButtonHovered(pos, mouseX, mouseY, Buttons.SORT)) {
            guiGraphics.method_25290(class_10799.field_56883, BackpackScreen.ICONS, pos.x() + 1, pos.y() + 2, 78, 69, 12, 12, 256, 256);
        }
        if(isButtonHovered(pos, mouseX, mouseY, Buttons.QUICK_STACK)) {
            guiGraphics.method_25290(class_10799.field_56883, BackpackScreen.ICONS, pos.x() + 13, pos.y() + 2, 90, 69, 12, 12, 256, 256);
        }
        if(isButtonHovered(pos, mouseX, mouseY, Buttons.TRANSFER_TO_BACKPACK)) {
            guiGraphics.method_25290(class_10799.field_56883, BackpackScreen.ICONS, pos.x() + 25, pos.y() + 2, 102, 69, 12, 12, 256, 256);
        }
        if(isButtonHovered(pos, mouseX, mouseY, Buttons.TRANSFER_TO_PLAYER)) {
            guiGraphics.method_25290(class_10799.field_56883, BackpackScreen.ICONS, pos.x() + 37, pos.y() + 2, 114, 69, 12, 12, 256, 256);
        }
    }

    @Override
    public void renderTooltip(class_332 guiGraphics, int mouseX, int mouseY) {
        if(isButtonHovered(pos, mouseX, mouseY, Buttons.SORT)) {
            List<class_2561> list = new ArrayList<>();
            list.add(class_2561.method_43471("screen.travelersbackpack.sort"));
            list.add(class_2561.method_43471("screen.travelersbackpack.sort_shift"));
            list.add(class_2561.method_43471("screen.travelersbackpack.sort_" + screen.getWrapper().getSortType().name().toLowerCase()));
            guiGraphics.method_64038(screen.method_64506(), list, Optional.empty(), mouseX, mouseY);
        }
        if(isButtonHovered(pos, mouseX, mouseY, Buttons.QUICK_STACK)) {
            List<class_2561> list = new ArrayList<>();
            list.add(class_2561.method_43471("screen.travelersbackpack.quick_stack"));
            list.add(class_2561.method_43471("screen.travelersbackpack.quick_stack_shift"));
            guiGraphics.method_64038(screen.method_64506(), list, Optional.empty(), mouseX, mouseY);
        }
        if(isButtonHovered(pos, mouseX, mouseY, Buttons.TRANSFER_TO_BACKPACK)) {
            List<class_2561> list = new ArrayList<>();
            list.add(class_2561.method_43471("screen.travelersbackpack.transfer_to_backpack"));
            list.add(class_2561.method_43471("screen.travelersbackpack.transfer_to_backpack_shift"));
            guiGraphics.method_64038(screen.method_64506(), list, Optional.empty(), mouseX, mouseY);
        }
        if(isButtonHovered(pos, mouseX, mouseY, Buttons.TRANSFER_TO_PLAYER)) {
            guiGraphics.method_51438(screen.method_64506(), class_2561.method_43471("screen.travelersbackpack.transfer_to_player"), mouseX, mouseY);
        }
    }

    @Override
    public boolean method_25402(class_11909 event, boolean button) {
        if(isButtonHovered(pos, event, Buttons.SORT)) {
            ServerboundActionTagPacket.create(ServerboundActionTagPacket.SORTER, ContainerSorter.SORT_BACKPACK, KeyHelper.isShiftPressed());
            screen.playUIClickSound();
            return true;
        }
        if(isButtonHovered(pos, event, Buttons.QUICK_STACK)) {
            ServerboundActionTagPacket.create(ServerboundActionTagPacket.SORTER, ContainerSorter.QUICK_STACK, KeyHelper.isShiftPressed());
            screen.playUIClickSound();
            return true;
        }
        if(isButtonHovered(pos, event, Buttons.TRANSFER_TO_BACKPACK)) {
            ServerboundActionTagPacket.create(ServerboundActionTagPacket.SORTER, ContainerSorter.TRANSFER_TO_BACKPACK, KeyHelper.isShiftPressed());
            screen.playUIClickSound();
            return true;
        }
        if(isButtonHovered(pos, event, Buttons.TRANSFER_TO_PLAYER)) {
            ServerboundActionTagPacket.create(ServerboundActionTagPacket.SORTER, ContainerSorter.TRANSFER_TO_PLAYER, KeyHelper.isShiftPressed());
            screen.playUIClickSound();
            return true;
        }
        return false;
    }

    public boolean isButtonHovered(Point pos, class_11909 event, Buttons button) {
        return isButtonHovered(pos, (int)event.comp_4798(), (int)event.comp_4799(), button);
    }

    public boolean isButtonHovered(int mouseX, int mouseY, Buttons button) {
        return (65 + button.ordinal() * 11) + screen.getGuiLeft() <= mouseX && mouseX <= (65 + button.ordinal() * 11) + 8 + screen.getGuiLeft() && -6 + screen.getGuiTop() <= mouseY && mouseY <= -6 + 8 + screen.getGuiTop();
    }

    public boolean isButtonHovered(Point pos, int mouseX, int mouseY, Buttons button) {
        int buttonX = pos.x() + 2 + button.ordinal() * 12;
        int buttonY = pos.y() + 3;
        return buttonX <= mouseX && mouseX < buttonX + 10 && buttonY <= mouseY && mouseY < buttonY + 10;
    }

    public enum Buttons {
        SORT,
        QUICK_STACK,
        TRANSFER_TO_BACKPACK,
        TRANSFER_TO_PLAYER
    }
}