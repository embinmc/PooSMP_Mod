package com.tiviacz.travelersbackpack.client.screens.widgets;

import com.tiviacz.travelersbackpack.client.screens.AbstractBackpackScreen;
import com.tiviacz.travelersbackpack.inventory.upgrades.Point;
import net.minecraft.class_11909;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_6379;
import net.minecraft.class_6382;

public class WidgetBase<T extends AbstractBackpackScreen<?>> implements class_4068, class_364, class_6379 {
    protected final Point emptyTabUv = new Point(0, 0);
    protected final Point iconSize = new Point(18, 18);
    public final T screen;
    protected Point pos;
    protected int width;
    protected int height;

    public WidgetBase(T screen, Point pos, int width, int height) {
        this.screen = screen;
        this.pos = pos;
        this.width = width;
        this.height = height;
    }

    public Point getPos() {
        return this.pos;
    }

    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTicks) {

    }

    public void renderBg(class_332 guiGraphics, int x, int y, int mouseX, int mouseY) {

    }

    public void renderUnderTooltip(class_332 guiGraphics, int mouseX, int mouseY, float partialTicks) {

    }

    public void renderTooltip(class_332 guiGraphics, int mouseX, int mouseY) {

    }

    public void renderAboveBg(class_332 guiGraphics, int xPos, int yPos, int mouseX, int mouseY, float partialTicks) {

    }

    public void renderOnTop(class_332 guiGraphics, int mouseX, int mouseY, float partialTicks) {

    }

    @Override
    public boolean method_25405(double pMouseX, double pMouseY) {
        return pMouseX >= pos.x() && pMouseY >= pos.y() && pMouseX < pos.x() + width && pMouseY < pos.y() + height;
    }

    @Override
    public void method_25365(boolean focused) {

    }

    @Override
    public boolean method_25370() {
        return false;
    }

    public boolean isMouseOverIcon(class_11909 event) {
        return isMouseOverIcon(event.comp_4798(), event.comp_4799());
    }

    public boolean isMouseOverIcon(double mouseX, double mouseY) {
        return mouseX >= pos.x() + 3 && mouseX < pos.x() + 3 + 18 && mouseY >= pos.y() + 3 && mouseY < pos.y() + 3 + 18;
    }

    public boolean in(int mouseX, int mouseY, int x, int y, int width, int height) {
        return x <= mouseX && mouseX <= x + width && y <= mouseY && mouseY <= y + height;
    }

    public boolean isWithinBounds(double mouseX, double mouseY, Point startPos, Point size) {
        return mouseX >= pos.x() + startPos.x() && mouseX < pos.x() + startPos.x() + size.x() && mouseY >= pos.y() + startPos.y() && mouseY < pos.y() + startPos.y() + size.y();
    }

    public boolean isWithinBounds(double mouseX, double mouseY, WidgetElement element) {
        return isWithinBounds(mouseX, mouseY, element.pos(), element.size());
    }

    @Override
    public class_6380 method_37018() {
        return class_6380.field_33784;
    }

    @Override
    public void method_37020(class_6382 pNarrationElementOutput) {

    }

    public int[] getWidgetSizeAndPos() {
        int[] size = new int[4];
        size[0] = pos.x();
        size[1] = pos.y();
        size[2] = width;
        size[3] = height;
        return size;
    }
}
