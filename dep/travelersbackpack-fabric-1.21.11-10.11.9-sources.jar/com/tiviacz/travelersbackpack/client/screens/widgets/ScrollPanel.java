package com.tiviacz.travelersbackpack.client.screens.widgets;

import java.util.Collections;
import java.util.List;
import net.minecraft.class_11909;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_362;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_6379;

public abstract class ScrollPanel extends class_362 implements class_4068, class_6379 {
    private final class_310 client;
    protected final int width;
    protected final int height;
    protected final int top;
    protected final int bottom;
    protected final int right;
    protected final int left;
    private boolean scrolling;
    protected float scrollDistance;
    protected boolean captureMouse = true;
    protected final int border;

    private final int barWidth;
    private final int barLeft;
    private final int barBgColor;
    private final int barColor;
    private final int barBorderColor;

    public ScrollPanel(class_310 client, int width, int height, int top, int left, int border) {
        this(client, width, height, top, left, border, 6);
    }

    public ScrollPanel(class_310 client, int width, int height, int top, int left, int border, int barWidth) {
        this(client, width, height, top, left, border, barWidth, 0xFF000000, 0xFF808080, 0xFFC0C0C0);
    }

    public ScrollPanel(class_310 client, int width, int height, int top, int left, int border, int barWidth, int barBgColor, int barColor, int barBorderColor) {
        this.client = client;
        this.width = width;
        this.height = height;
        this.top = top;
        this.left = left;
        this.bottom = height + this.top;
        this.right = width + this.left;
        this.barLeft = this.left + this.width - barWidth;
        this.border = border;
        this.barWidth = barWidth;
        this.barBgColor = barBgColor;
        this.barColor = barColor;
        this.barBorderColor = barBorderColor;
    }

    protected abstract int getContentHeight();

    //protected abstract void drawPanel(GuiGraphics guiGraphics, int entryRight, int relativeY, Tesselator tess, int mouseX, int mouseY);

    protected boolean clickPanel(double mouseX, double mouseY, class_11909 event) {
        return false;
    }

    private int getMaxScroll() {
        return this.getContentHeight() - (this.height - this.border);
    }

    private void applyScrollLimits() {
        int max = getMaxScroll();

        if(max < 0) {
            max /= 2;
        }

        if(this.scrollDistance < 0.0F) {
            this.scrollDistance = 0.0F;
        }

        if(this.scrollDistance > max) {
            this.scrollDistance = max;
        }
    }

    @Override
    public boolean method_25401(double p_94686_, double p_94687_, double p_94688_, double p_294830_) {
        if(p_294830_ != 0) {
            this.scrollDistance += (float)(-p_294830_ * getScrollAmount());
            applyScrollLimits();
            return true;
        }
        return false;
    }

    protected int getScrollAmount() {
        return 20;
    }

    @Override
    public boolean method_25405(double mouseX, double mouseY) {
        return mouseX >= this.left && mouseX < this.right &&
                mouseY >= this.top && mouseY < this.bottom;
    }

    @Override
    public boolean method_25402(class_11909 event, boolean doubleClick) {
        if (super.method_25402(event, doubleClick))
            return true;

        this.scrolling = event.method_74245() == 0 && event.comp_4798() >= barLeft && event.comp_4798() < right && event.comp_4799() >= top && event.comp_4799() < bottom;
        if (this.scrolling) {
            return true;
        }
        int mouseListY = ((int) event.comp_4799()) - this.top - this.getContentHeight() + (int) this.scrollDistance - border;
        if (event.comp_4798() >= left && event.comp_4798() < right && mouseListY < 0) {
            return this.clickPanel(event.comp_4798() - left, event.comp_4799() - this.top + (int) this.scrollDistance - border, event);
        }
        return false;
    }

    @Override
    public boolean method_25406(class_11909 event) {
        if (super.method_25406(event))
            return true;
        boolean ret = this.scrolling;
        this.scrolling = false;
        return ret;
    }

    private int getBarHeight() {
        int barHeight = (height * height) / this.getContentHeight();

        if(barHeight < 32) barHeight = 32;

        if(barHeight > height - border * 2)
            barHeight = height - border * 2;

        return barHeight;
    }

    @Override
    public boolean method_25403(class_11909 event, double deltaX, double deltaY) {
        if (this.scrolling) {
            int maxScroll = height - getBarHeight();
            double moved = deltaY / maxScroll;
            this.scrollDistance += getMaxScroll() * moved;
            applyScrollLimits();
            return true;
        }
        return false;
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTick) {
        guiGraphics.method_44379(this.left, this.top, this.right, this.bottom);

        int extraHeight = (this.getContentHeight() + border) - height;
        if(extraHeight > 0) {
            int barHeight = getBarHeight();

            int barTop = (int)this.scrollDistance * (height - barHeight) / extraHeight + this.top;
            if(barTop < this.top) {
                barTop = this.top;
            }

            guiGraphics.method_25294(this.barLeft, this.top, this.barLeft + this.barWidth, this.bottom, this.barBgColor);

            guiGraphics.method_25294(this.barLeft, barTop, this.barLeft + this.barWidth, barTop + barHeight, this.barColor);

            guiGraphics.method_25294(this.barLeft, barTop, this.barLeft + this.barWidth - 1, barTop + barHeight - 1, this.barBorderColor);
        }

        guiGraphics.method_44380();
    }

    @Override
    public List<? extends class_364> method_25396() {
        return Collections.emptyList();
    }
}