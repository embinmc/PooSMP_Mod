package com.tiviacz.travelersbackpack.client.screens.tooltip;

import com.tiviacz.travelersbackpack.inventory.CommonFluid;
import com.tiviacz.travelersbackpack.inventory.FluidVariantWrapper;
import com.tiviacz.travelersbackpack.util.KeyHelper;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5250;
import net.minecraft.class_5684;

@Environment(EnvType.CLIENT)
public class ClientBackpackTooltipComponent implements class_5684 {
    private final BackpackTooltipComponent component;

    public ClientBackpackTooltipComponent(BackpackTooltipComponent component) {
        this.component = component;
    }

    public boolean show() {
        return KeyHelper.isCtrlPressed() || component.isHoveredWithItem();
    }

    @Override
    public int method_32661(class_327 p_365134_) {
        int height = 0;

        if(show()) {
            if(!component.leftFluidStack.isEmpty()) {
                height += 10;
            }

            if(!component.rightFluidStack.isEmpty()) {
                height += 10;
            }

            if(!component.upgrades.isEmpty()) {
                height += 10; //Text
                height += 18;
            }

            if(!component.storage.isEmpty()) {
                height += 10; //Text
                height += (int)(Math.ceil((float)component.storage.size() / 9) * 18);
            }

            if(!component.tools.isEmpty()) {
                height += 10; //Text
                height += 18;
            }
        }
        return height;
    }

    @Override
    public int method_32664(class_327 font) {
        int width = 0;
        int textWidth = 0;

        if(show()) {
            if(!component.storage.isEmpty()) {
                width += Math.min(component.storage.size(), 9) * 18 + Math.min(component.storage.size(), 9) * 2;
            }
            if(!component.leftFluidStack.isEmpty()) {
                textWidth = font.method_27525(getFluidTankTooltip(component.leftFluidStack));
            }
            if(!component.rightFluidStack.isEmpty()) {
                textWidth = Math.max(font.method_27525(getFluidTankTooltip(component.rightFluidStack)), textWidth);
            }
            if(textWidth > width) {
                width = textWidth;
            }
        }
        return width;
    }

    @Override
    public void method_32665(class_332 guiGraphics, class_327 pFont, int pMouseX, int pMouseY) {
        if(show()) {
            int yOffset = 0;

            if(!component.leftFluidStack.isEmpty()) {
                renderFluidTankTooltip(component.leftFluidStack, guiGraphics, pFont, pMouseX, pMouseY);
                yOffset += 10;
            }

            if(!component.rightFluidStack.isEmpty()) {
                renderFluidTankTooltip(component.rightFluidStack, guiGraphics, pFont, pMouseX, pMouseY + yOffset);
                yOffset += 10;
            }

            if(!component.upgrades.isEmpty()) {
                guiGraphics.method_27535(pFont, class_2561.method_43471("screen.travelersbackpack.upgrades").method_27692(class_124.field_1054), pMouseX, pMouseY + yOffset, -1);
                yOffset += 10;
                yOffset += 18;
            }

            if(!component.storage.isEmpty()) {
                guiGraphics.method_27535(pFont, class_2561.method_43471("screen.travelersbackpack.inventory").method_27692(class_124.field_1054), pMouseX, pMouseY + yOffset, -1);
                yOffset += 10;
                yOffset += (int)(Math.ceil((float)component.storage.size() / 9) * 18);
            }

            if(!component.tools.isEmpty()) {
                guiGraphics.method_27535(pFont, class_2561.method_43471("screen.travelersbackpack.tools").method_27692(class_124.field_1054), pMouseX, pMouseY + yOffset, -1);
                yOffset += 10;
                yOffset += 18;
            }
        }
    }

    @Override
    public void method_32666(class_327 pFont, int pX, int pY, int k, int k1, class_332 pGuiGraphics) {
        int yOffset = 0;

        if(show()) {
            if(!component.leftFluidStack.isEmpty()) {
                yOffset += 10;
            }

            if(!component.rightFluidStack.isEmpty()) {
                yOffset += 10;
            }

            boolean flag = false;

            if(!component.upgrades.isEmpty()) {
                yOffset += 10; //text
                flag = true;

                for(int i = 0; i < component.upgrades.size(); i++) {
                    renderItem(component.upgrades.get(i), pX + (i * 18), pY + yOffset, pFont, pGuiGraphics);
                }
            }

            if(!component.storage.isEmpty()) {
                yOffset += 10; //Text
                int j = 0;
                if(flag) yOffset += 18;
                flag = true;
                boolean nextRow = false;

                for(int i = 0; i < component.storage.size(); i++) {
                    if(nextRow) {
                        yOffset += 18;
                        nextRow = false;
                    }
                    renderItem(component.storage.get(i), pX + j * 2 + j * 18, pY + yOffset, pFont, pGuiGraphics);

                    if(j < 8) {
                        j++;
                    } else {
                        j = 0;
                        nextRow = true;
                    }
                }
            }

            if(!component.tools.isEmpty()) {
                yOffset += 10; //Text
                if(flag) yOffset += 18;

                for(int i = 0; i < component.tools.size(); i++) {
                    renderItem(component.tools.get(i), pX + (i * 18), pY + yOffset, pFont, pGuiGraphics);
                }
            }
        }
    }

    private void renderItem(class_1799 stack, int pX, int pY, class_327 pFont, class_332 guiGraphics) {
        guiGraphics.method_51445(stack, pX, pY);
        guiGraphics.method_51431(pFont, stack, pX, pY);
    }

    //Fabric

    public class_2561 getFluidTankTooltip(FluidVariantWrapper fluidStack) {
        class_2561 c = CommonFluid.getFluidName(fluidStack);
        class_2561 c1 = class_2561.method_43470(": ");
        class_2561 c2 = class_2561.method_43470(fluidStack.getViewAmount() + "mB").method_27692(class_124.field_1078);
        return class_5250.method_43477(c.method_10851()).method_10852(c1).method_10852(c2);
    }

    public void renderFluidTankTooltip(FluidVariantWrapper fluidStack, class_332 guiGraphics, class_327 font, int mouseX, int mouseY) {
        guiGraphics.method_27535(font, getFluidTankTooltip(fluidStack), mouseX, mouseY, -1);
    }

    /*public void renderFluidTankTooltip(FluidVariantWrapper fluidStack, Font font, int mouseX, int mouseY, Matrix4f matrix, MultiBufferSource bufferSource) {
        Component c = CommonFluid.getFluidName(fluidStack);
        Component c1 = Component.literal(": ");
        Component c2 = Component.literal(fluidStack.getAmount() + "mB");

        font.drawInBatch(c, (float)mouseX, (float)mouseY, -1, true, matrix, bufferSource, Font.DisplayMode.NORMAL, 0, 15728880);
        font.drawInBatch(c1, (float)mouseX + font.width(c), (float)mouseY, -1, true, matrix, bufferSource, Font.DisplayMode.NORMAL, 0, 15728880);
        font.drawInBatch(c2, (float)mouseX + font.width(c) + font.width(c1), (float)mouseY, 5592575, true, matrix, bufferSource, Font.DisplayMode.NORMAL, 0, 15728880);
    }*/
}