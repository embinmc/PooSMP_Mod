package com.tiviacz.travelersbackpack.client.screens.buttons;

import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.tiviacz.travelersbackpack.client.screens.BackpackScreen;
import com.tiviacz.travelersbackpack.network.ServerboundActionTagPacket;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;

public class EquipButton extends Button {
    private final boolean mainHand;
    public EquipButton(BackpackScreen screen, boolean mainHand) {
        super(screen, screen.getWidthAdditions() + 157, screen.getMiddleBar(), 12, 12);
        this.mainHand = mainHand;
    }

    @Override
    public void render(class_332 guiGraphics, int mouseX, int mouseY, float partialTicks) {
        this.drawButton(guiGraphics, mouseX, mouseY, BackpackScreen.ICONS, 63, 56, 78, 82);
    }

    @Override
    public void renderTooltip(class_332 guiGraphics, int mouseX, int mouseY) {
        if(this.inButton(mouseX, mouseY)) {
            if(this.mainHand) {
                guiGraphics.method_51438(screen.method_64506(), class_2561.method_43471("screen.travelersbackpack.equip"), mouseX, mouseY);
            } else {
                guiGraphics.method_51438(screen.method_64506(), class_2561.method_43471("screen.travelersbackpack.open_in_hand"), mouseX, mouseY);
            }
        }
    }

    @Override
    public boolean mouseClicked(class_11909 event, boolean doubleClick) {
        if(!TravelersBackpack.enableIntegration() && this.mainHand) {
            if(this.inButton(event)) {
                ServerboundActionTagPacket.create(ServerboundActionTagPacket.EQUIP_BACKPACK, true);
                return true;
            }
        }
        return false;
    }
}