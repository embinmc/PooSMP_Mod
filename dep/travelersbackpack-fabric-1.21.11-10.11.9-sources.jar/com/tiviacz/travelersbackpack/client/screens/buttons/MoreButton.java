package com.tiviacz.travelersbackpack.client.screens.buttons;

import com.tiviacz.travelersbackpack.client.screens.BackpackScreen;
import com.tiviacz.travelersbackpack.network.ServerboundActionTagPacket;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;

public class MoreButton extends Button {
    public MoreButton(BackpackScreen screen) {
        super(screen, screen.getWidthAdditions() + 157, screen.getMiddleBar(), 12, 12);
    }

    @Override
    public void render(class_332 guiGraphics, int mouseX, int mouseY, float partialTicks) {
        this.drawButton(guiGraphics, mouseX, mouseY, BackpackScreen.ICONS, 4, 44, 78, 82);
    }

    @Override
    public void renderTooltip(class_332 guiGraphics, int mouseX, int mouseY) {
        if(inButton(mouseX, mouseY)) {
            guiGraphics.method_51438(screen.method_64506(), class_2561.method_43471("screen.travelersbackpack.show_more_buttons"), mouseX, mouseY);
        }
    }

    @Override
    public boolean mouseClicked(class_11909 event, boolean doubleClick) {
        if(inButton(event)) {
            ServerboundActionTagPacket.create(ServerboundActionTagPacket.TOGGLE_BUTTONS_VISIBILITY);
            screen.playUIClickSound();
            return true;
        }
        return false;
    }
}