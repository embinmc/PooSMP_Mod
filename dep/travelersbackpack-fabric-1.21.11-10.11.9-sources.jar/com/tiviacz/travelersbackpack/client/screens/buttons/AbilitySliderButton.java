package com.tiviacz.travelersbackpack.client.screens.buttons;

import com.tiviacz.travelersbackpack.client.screens.BackpackScreen;
import com.tiviacz.travelersbackpack.common.BackpackAbilities;
import com.tiviacz.travelersbackpack.attachment.AttachmentUtils;
import com.tiviacz.travelersbackpack.config.TravelersBackpackConfig;
import com.tiviacz.travelersbackpack.network.ServerboundActionTagPacket;
import com.tiviacz.travelersbackpack.util.TextUtils;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;

public class AbilitySliderButton extends Button {
    private final boolean isBlock;

    public AbilitySliderButton(BackpackScreen screen, boolean isBlock, int xOffset) {
        super(screen, screen.getWidthAdditions() + 145 - xOffset, screen.getMiddleBar(), 12, 12);
        this.isBlock = isBlock;
    }

    @Override
    public void render(class_332 guiGraphics, int mouseX, int mouseY, float partialTicks) {
        if(isBlock) {
            drawButton(guiGraphics, mouseX, mouseY, BackpackScreen.ICONS);
        } else {
            if(AttachmentUtils.isWearingBackpack(screen.method_17577().getPlayerInventory().field_7546)) {
                drawButton(guiGraphics, mouseX, mouseY, BackpackScreen.ICONS);
            }
        }
    }

    public void drawButton(class_332 guiGraphics, int mouseX, int mouseY, class_2960 texture) {
        if(screen.getWrapper().isAbilityEnabled()) {
            this.drawButton(guiGraphics, mouseX, mouseY, texture, 44, 56, 78, 82);
        } else {
            this.drawButton(guiGraphics, mouseX, mouseY, texture, 44, 67, 78, 82);
        }
    }

    @Override
    public void renderTooltip(class_332 guiGraphics, int mouseX, int mouseY) {
        if(inButton(mouseX, mouseY)) {
            //If disabled in config
            if(!BackpackAbilities.isAbilityEnabledInConfig(screen.getWrapper().getBackpackStack())) {
                guiGraphics.method_51438(screen.method_64506(), class_2561.method_43471("screen.travelersbackpack.ability_disabled_config"), mouseX, mouseY);
                return;
            }
            List<class_2561> components = new ArrayList<>();

            //Ability on/off
            if(screen.getWrapper().isAbilityEnabled()) {
                components.add(class_2561.method_43471("screen.travelersbackpack.ability_enabled"));
            } else {
                components.add(class_2561.method_43471("screen.travelersbackpack.ability_disabled"));
            }

            //Show cooldown
            if(BackpackAbilities.hasCooldown(screen.getWrapper().getBackpackStack())) {
                components.add(class_2561.method_43469("screen.travelersbackpack.ability_cooldown", TextUtils.getConvertedTime(screen.getWrapper().getCooldown())));
            } else {
                components.add(class_2561.method_43471("screen.travelersbackpack.ability_ready"));
            }

            guiGraphics.method_64038(screen.method_64506(), components, Optional.empty(), mouseX, mouseY);
        }
    }

    @Override
    public boolean mouseClicked(class_11909 event, boolean doubleClick) {
        if(!TravelersBackpackConfig.SERVER.backpackAbilities.enableBackpackAbilities.get() || !BackpackAbilities.isAbilityEnabledInConfig(screen.getWrapper().getBackpackStack())) {
            return false;
        }

        if(isBlock) {
            if(BackpackAbilities.isOnList(BackpackAbilities.BLOCK_ABILITIES_LIST, screen.getWrapper().getBackpackStack()) && this.inButton(event)) {
                ServerboundActionTagPacket.create(ServerboundActionTagPacket.ABILITY_SLIDER, !screen.getWrapper().isAbilityEnabled());
                screen.playUIClickSound();
                return true;
            }
        } else {
            if(BackpackAbilities.isOnList(BackpackAbilities.ITEM_ABILITIES_LIST, screen.getWrapper().getBackpackStack()) && this.inButton(event)) {
                ServerboundActionTagPacket.create(ServerboundActionTagPacket.ABILITY_SLIDER, !screen.getWrapper().isAbilityEnabled());
                screen.playUIClickSound();
                return true;
            }
        }
        return false;
    }
}