package com.tiviacz.travelersbackpack.client.screens.buttons;

import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.tiviacz.travelersbackpack.client.screens.BackpackScreen;
import com.tiviacz.travelersbackpack.attachment.AttachmentUtils;
import com.tiviacz.travelersbackpack.network.ServerboundActionTagPacket;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;

public class UnequipButton extends Button {
    public UnequipButton(BackpackScreen screen) {
        super(screen, screen.getWidthAdditions() + 145, screen.getMiddleBar(), 12, 12);
    }

    @Override
    public void render(class_332 guiGraphics, int mouseX, int mouseY, float partialTicks) {
        if(AttachmentUtils.isWearingBackpack(screen.method_17577().getPlayerInventory().field_7546)) {
            this.drawButton(guiGraphics, mouseX, mouseY, BackpackScreen.ICONS, 63, 67, 78, 82);
        }
    }

    @Override
    public void renderTooltip(class_332 guiGraphics, int mouseX, int mouseY) {
        if(AttachmentUtils.isWearingBackpack(screen.method_17577().getPlayerInventory().field_7546)) {
            if(this.inButton(mouseX, mouseY)) {
                guiGraphics.method_51438(screen.method_64506(), class_2561.method_43471("screen.travelersbackpack.unequip"), mouseX, mouseY);
            }
        }
    }

    @Override
    public boolean mouseClicked(class_11909 event, boolean doubleClick) {
        if(!TravelersBackpack.enableIntegration()) {
            if(AttachmentUtils.isWearingBackpack(screen.method_17577().getPlayerInventory().field_7546)) {
                if(this.inButton(event)) {
                    ServerboundActionTagPacket.create(ServerboundActionTagPacket.EQUIP_BACKPACK, false);
                    return true;
                }
            }
        }
        return false;
    }
}