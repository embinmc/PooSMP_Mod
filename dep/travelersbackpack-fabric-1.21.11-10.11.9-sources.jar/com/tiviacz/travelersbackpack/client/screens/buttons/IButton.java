package com.tiviacz.travelersbackpack.client.screens.buttons;

import net.minecraft.class_11909;
import net.minecraft.class_332;

public interface IButton {
    void render(class_332 guiGraphics, int mouseX, int mouseY, float partialTicks);

    void renderTooltip(class_332 guiGraphics, int mouseX, int mouseY);

    boolean mouseClicked(class_11909 event, boolean bl);
}