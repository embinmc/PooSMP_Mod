package com.tiviacz.travelersbackpack.util;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1299;

public class Reference {
    //Screen IDs
    public static final byte ITEM_SCREEN_ID = 1;
    public static final byte WEARABLE_SCREEN_ID = 2;
    public static final byte BLOCK_ENTITY_SCREEN_ID = 3;

    //Translation Keys
    public static final String NO_SPACE = "action.travelersbackpack.unequip_nospace";
    public static final String OTHER_BACKPACK = "action.travelersbackpack.equip_otherbackpack";
    public static final String DEPLOY = "action.travelersbackpack.deploy_sleeping_bag";

    public static final List<class_1299> ALLOWED_TYPE_ENTRIES = new ArrayList<>();
}