package com.tiviacz.travelersbackpack.util;

import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import net.minecraft.class_1074;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

public class TextUtils {
    public static List<class_2561> getTranslatedSplittedText(String translationId, @Nullable class_124 style) {
        class_5250 text = class_2561.method_43471(translationId);

        if(text.getString().contains("\n")) {
            String[] translatedSplitted = class_1074.method_4662(translationId).split("\n");
            List<class_2561> list = new ArrayList<>();
            Arrays.stream(translatedSplitted).forEach(s -> list.add(style == null ? class_2561.method_43470(s) : class_2561.method_43470(s).method_27692(style)));
            return list;
        }
        return List.of(style == null ? text : text.method_27692(style));
    }

    public static String getConvertedTime(int ticks) {
        int i = ticks / 20;
        int minutes = i / 60;
        int seconds = i % 60;
        if(seconds < 10) {
            return minutes + ":" + "0" + seconds;
        }
        return minutes + ":" + seconds;
    }
}