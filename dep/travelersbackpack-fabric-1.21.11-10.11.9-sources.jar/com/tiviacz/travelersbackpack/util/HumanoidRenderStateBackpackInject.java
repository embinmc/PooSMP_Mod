package com.tiviacz.travelersbackpack.util;

import net.minecraft.class_1799;

public interface HumanoidRenderStateBackpackInject {
    void setBackpackStack(class_1799 stack);

    class_1799 getBackpackStack();

    void setChestItem(class_1799 stack);

    void setName(String name);

    String getName();
}

