package com.tiviacz.travelersbackpack.util;

import net.minecraft.class_310;
import org.lwjgl.glfw.GLFW;

public class KeyHelper {
    public static boolean isShiftPressed() {
        return GLFW.glfwGetKey(class_310.method_1551().method_22683().method_4490(), GLFW.GLFW_KEY_LEFT_SHIFT) == GLFW.GLFW_PRESS || GLFW.glfwGetKey(class_310.method_1551().method_22683().method_4490(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
    }

    public static boolean isCtrlPressed() {
        return GLFW.glfwGetKey(class_310.method_1551().method_22683().method_4490(), GLFW.GLFW_KEY_LEFT_CONTROL) == GLFW.GLFW_PRESS || GLFW.glfwGetKey(class_310.method_1551().method_22683().method_4490(), GLFW.GLFW_KEY_RIGHT_CONTROL) == GLFW.GLFW_PRESS;
    }
}