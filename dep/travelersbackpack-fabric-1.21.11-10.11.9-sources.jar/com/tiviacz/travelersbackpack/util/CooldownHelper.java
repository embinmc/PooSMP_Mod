package com.tiviacz.travelersbackpack.util;

import net.minecraft.class_5819;

public class CooldownHelper {
    public static int createCooldown(int minSeconds, int maxSeconds) {
        class_5819 random = class_5819.method_43049(1337L);
        return random.method_39332(seconds(minSeconds), seconds(maxSeconds));
    }

    public static int seconds(int seconds) {
        return seconds * 20;
    }
}