package com.tiviacz.travelersbackpack.util;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PlayerLookup;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1657;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.server.MinecraftServer;

public class PacketDistributor {
    public static void sendToServer(class_8710 payload) {
        ClientPlayNetworking.send(payload);
    }

    public static void sendToPlayer(class_3222 serverPlayer, class_8710 payload) {
        ServerPlayNetworking.send(serverPlayer, payload);
    }

    public static void sendToPlayersTrackingEntityAndSelf(class_1657 player, class_8710 payload) {
        ServerPlayNetworking.send((class_3222)player, payload);
        for(class_3222 sp : PlayerLookup.tracking(player)) {
            ServerPlayNetworking.send(sp, payload);
        }
    }

    public static void sendToAllPlayers(class_8710 packet, MinecraftServer server) {
        for(class_3222 player : PlayerLookup.all(server)) {
            ServerPlayNetworking.send(player, packet);
        }
    }
}
