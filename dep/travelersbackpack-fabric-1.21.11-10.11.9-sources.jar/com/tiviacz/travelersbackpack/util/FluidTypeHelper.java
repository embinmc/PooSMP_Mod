package com.tiviacz.travelersbackpack.util;

import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariantAttributes;
import net.minecraft.class_2561;
import net.minecraft.class_3414;

public class FluidTypeHelper {

    public static class_2561 getFluidVariantName(FluidVariant variant) {
        return FluidVariantAttributes.getName(variant);
    }

    public static class_3414 getSound(FluidVariant fluid, boolean isFill) {
        return isFill ? FluidVariantAttributes.getFillSound(fluid) : FluidVariantAttributes.getEmptySound(fluid);
    }

    public static final boolean BUCKET_EMPTY = false;
    public static final boolean BUCKET_FILL = true;
}
