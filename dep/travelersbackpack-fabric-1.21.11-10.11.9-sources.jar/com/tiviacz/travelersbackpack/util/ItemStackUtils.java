package com.tiviacz.travelersbackpack.util;

import com.mojang.datafixers.util.Pair;
import com.tiviacz.travelersbackpack.components.Slots;
import com.tiviacz.travelersbackpack.init.ModDataComponents;
import com.tiviacz.travelersbackpack.item.HoseItem;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_1799;
import net.minecraft.class_9323;
import net.minecraft.class_9331;
import net.minecraft.class_9334;

public class ItemStackUtils {
    public static boolean isSameItemSameTags(class_1799 stack1, class_1799 stack2) {
        //Hose patch
        if(stack1.method_7909() instanceof HoseItem && stack1.method_31574(stack2.method_7909())) return true;

        return isSameItemSameComponents(stack1, stack2);
    }

    public static boolean isSameItemSameComponents(class_1799 pStack, class_1799 pOther) {
        if(!pStack.method_31574(pOther.method_7909())) {
            return false;
        } else {
            return pStack.method_7960() && pOther.method_7960() || checkComponentsIgnoreDamage(pStack.method_58658(), pOther.method_58658());
        }
    }

    public static boolean checkComponentsIgnoreDamage(class_9323 map, class_9323 other) {
        map.method_57831().removeIf(type -> type == class_9334.field_49629);
        other.method_57831().removeIf(type -> type == class_9334.field_49629);
        return Objects.equals(map, other);
    }

    public static class_9323 createDataComponentMap(class_1799 serverDataHolder, class_9331... dataComponentTypes) {
        class_1799 serverDataHolderCopy = serverDataHolder.method_7972();
        serverDataHolderCopy = reduceSize(serverDataHolderCopy);
        class_9323.class_9324 mapBuilder = class_9323.method_57827();
        for(class_9331 type : dataComponentTypes) {
            if(!serverDataHolderCopy.method_57826(type)) continue;
            mapBuilder.method_57840(type, serverDataHolderCopy.method_58694(type));
        }
        return mapBuilder.method_57838();
    }

    public static class_1799 reduceSize(class_1799 backpack) {
        class_1799 backpackCopy = backpack.method_7972();
        if(backpackCopy.method_57826(ModDataComponents.BACKPACK_CONTAINER)) {
            backpackCopy.method_57381(ModDataComponents.BACKPACK_CONTAINER);
        }
        //Client needs only visual representation, no need to send the whole data
        if(backpackCopy.method_57826(ModDataComponents.SLOTS)) {
            Slots slots = backpackCopy.method_58694(ModDataComponents.SLOTS);
            List<Pair<Integer, Pair<class_1799, Boolean>>> memorizedStacksHeavy = slots.memory();
            List<Pair<Integer, Pair<class_1799, Boolean>>> reduced = new ArrayList<>();

            for(Pair<Integer, Pair<class_1799, Boolean>> outerPair : memorizedStacksHeavy) {
                int index = outerPair.getFirst();
                class_1799 innerStack = outerPair.getSecond().getFirst().method_7972();
                boolean matchComponents = outerPair.getSecond().getSecond();
                if(matchComponents) {
                    innerStack = new class_1799(innerStack.method_7909(), innerStack.method_7947());
                }
                if(innerStack.method_7960()) {
                    continue;
                }
                reduced.add(Pair.of(index, Pair.of(innerStack, matchComponents)));
            }
            backpackCopy.method_57379(ModDataComponents.SLOTS, new Slots(slots.unsortables(), reduced));
        }
        return backpackCopy;
    }
}