package com.tiviacz.travelersbackpack.item;

import net.minecraft.class_1748;
import net.minecraft.class_2248;

public class SleepingBagItem extends class_1748 {
    public SleepingBagItem(class_2248 block, class_1793 properties) {
        super(block, properties.method_63685());
    }
}