package com.tiviacz.travelersbackpack.item;

import com.tiviacz.travelersbackpack.config.TravelersBackpackConfig;
import net.minecraft.class_1792;
import net.minecraft.class_7699;

public class BackpackTankItem extends class_1792 {
    public BackpackTankItem(class_1793 properties) {
        super(properties);
    }

    @Override
    public boolean method_45382(class_7699 enabledFeatures) {
        if(TravelersBackpackConfig.serverSpec.isLoaded()) {
            return TravelersBackpackConfig.SERVER.backpackUpgrades.enableTanksUpgrade.get() && super.method_45382(enabledFeatures);
        }
        return super.method_45382(enabledFeatures);
    }
}