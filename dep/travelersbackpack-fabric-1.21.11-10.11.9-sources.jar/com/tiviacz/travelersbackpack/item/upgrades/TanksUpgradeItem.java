package com.tiviacz.travelersbackpack.item.upgrades;

import com.tiviacz.travelersbackpack.components.Fluids;
import com.tiviacz.travelersbackpack.components.RenderInfo;
import com.tiviacz.travelersbackpack.config.TravelersBackpackConfig;
import com.tiviacz.travelersbackpack.init.ModDataComponents;
import com.tiviacz.travelersbackpack.inventory.FluidVariantWrapper;
import com.tiviacz.travelersbackpack.inventory.UpgradeManager;
import com.tiviacz.travelersbackpack.inventory.upgrades.UpgradeBase;
import com.tiviacz.travelersbackpack.inventory.upgrades.tanks.TanksUpgrade;
import com.tiviacz.travelersbackpack.util.FluidTypeHelper;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10712;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_7699;
import org.apache.commons.lang3.function.TriFunction;

import java.util.Optional;
import java.util.function.Consumer;

public class TanksUpgradeItem extends UpgradeItem {
    public TanksUpgradeItem(class_1793 pProperties) {
        super(pProperties.method_57349(ModDataComponents.FLUIDS, Fluids.empty()), "tanks_upgrade");
    }

    @Override
    public boolean method_45382(class_7699 enabledFeatures) {
        if(TravelersBackpackConfig.serverSpec.isLoaded()) {
            return TravelersBackpackConfig.SERVER.backpackUpgrades.enableTanksUpgrade.get() && super.method_45382(enabledFeatures);
        }
        return super.method_45382(enabledFeatures);
    }

    public static boolean canBePutInBackpack(long backpackFluidStorageSize, class_1799 tanksUpgrade) {
        long[] fluidTanks = new long[]{0, 0};
        if(tanksUpgrade.method_57826(ModDataComponents.FLUIDS)) {
            Fluids fluidTanks2 = tanksUpgrade.method_58694(ModDataComponents.FLUIDS);
            fluidTanks[0] = fluidTanks2.leftFluidStack().getAmount();
            fluidTanks[1] = fluidTanks2.rightFluidStack().getAmount();
        }
        return backpackFluidStorageSize >= fluidTanks[0] && backpackFluidStorageSize >= fluidTanks[1];
    }

    public static FluidVariantWrapper getLeftFluidStack(class_1799 tanksUpgrade) {
        if(tanksUpgrade.method_57826(ModDataComponents.FLUIDS)) {
            Fluids fluidTanks2 = tanksUpgrade.method_58694(ModDataComponents.FLUIDS);
            return fluidTanks2.leftFluidStack();
        }
        return FluidVariantWrapper.blank();
    }

    public static FluidVariantWrapper getRightFluidStack(class_1799 tanksUpgrade) {
        if(tanksUpgrade.method_57826(ModDataComponents.FLUIDS)) {
            Fluids fluidTanks2 = tanksUpgrade.method_58694(ModDataComponents.FLUIDS);
            return fluidTanks2.rightFluidStack();
        }
        return FluidVariantWrapper.blank();
    }

    public static RenderInfo writeToRenderData() {
        class_2487 tag = new class_2487();
        tag.method_10566("LeftTank", new class_2487());
        tag.method_10566("RightTank", new class_2487());
        return new RenderInfo(tag);
    }

    @Environment(EnvType.CLIENT)
    @Override
    public void method_67187(class_1799 stack, class_1792.class_9635 context, class_10712 tooltipDisplay, Consumer<class_2561> componentConsumer, class_1836 tooltipFlag) {
        super.method_67187(stack, context, tooltipDisplay, componentConsumer, tooltipFlag);

        if(stack.method_57826(ModDataComponents.FLUIDS)) {
            Fluids fluidTanks = stack.method_58694(ModDataComponents.FLUIDS);
            FluidVariantWrapper leftFluidStack = fluidTanks.leftFluidStack();
            FluidVariantWrapper rightFluidStack = fluidTanks.rightFluidStack();

            if(!leftFluidStack.isEmpty()) {
                componentConsumer.accept(class_2561.method_43470(FluidTypeHelper.getFluidVariantName(leftFluidStack.fluidVariant()).getString() + ": " + leftFluidStack.getViewAmount() + "mB").method_27692(class_124.field_1078));
            }
            if(!rightFluidStack.isEmpty()) {
                componentConsumer.accept(class_2561.method_43470(FluidTypeHelper.getFluidVariantName(rightFluidStack.fluidVariant()).getString() + ": " + rightFluidStack.getViewAmount() + "mB").method_27692(class_124.field_1078));
            }
        }
    }

    @Override
    public boolean requiresEquippedBackpack() {
        return false;
    }

    @Override
    public Class<? extends UpgradeBase<?>> getUpgradeClass() {
        return TanksUpgrade.class;
    }

    @Override
    public TriFunction<UpgradeManager, Integer, class_1799, Optional<? extends UpgradeBase<?>>> getUpgrade() {
        return (upgradeManager, dataHolderSlot, provider) -> {
            Fluids fluids = provider.method_58695(ModDataComponents.FLUIDS, new Fluids(FluidVariantWrapper.blank(), FluidVariantWrapper.blank()));
            return Optional.of(new TanksUpgrade(upgradeManager, dataHolderSlot, fluids));
        };
    }
}
