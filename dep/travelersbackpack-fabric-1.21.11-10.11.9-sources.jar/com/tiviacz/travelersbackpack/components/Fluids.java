package com.tiviacz.travelersbackpack.components;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.tiviacz.travelersbackpack.inventory.FluidVariantWrapper;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record Fluids(FluidVariantWrapper leftFluidStack, FluidVariantWrapper rightFluidStack) {
    public static final Codec<Fluids> CODEC = RecordCodecBuilder.create(instance ->
            instance.group(
                    FluidVariantWrapper.CODEC.fieldOf("leftFluidStack").forGetter(Fluids::leftFluidStack),
                    FluidVariantWrapper.CODEC.fieldOf("rightFluidStack").forGetter(Fluids::rightFluidStack)
            ).apply(instance, Fluids::new)
    );

    public static final class_9139<class_9129, Fluids> STREAM_CODEC = class_9139.method_56435(
            FluidVariantWrapper.STREAM_CODEC, Fluids::leftFluidStack,
            FluidVariantWrapper.STREAM_CODEC, Fluids::rightFluidStack,
            Fluids::new
    );

    public static Fluids empty() {
        return new Fluids(FluidVariantWrapper.blank(), FluidVariantWrapper.blank());
    }
}
