package com.tiviacz.travelersbackpack.components;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.ArrayList;
import java.util.List;
import java.util.OptionalInt;
import net.minecraft.class_11343;
import net.minecraft.class_11362;
import net.minecraft.class_11372;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_7225;
import net.minecraft.class_8942;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public final class BackpackContainerContents {
    public static final BackpackContainerContents EMPTY = new BackpackContainerContents(class_2371.method_10213(27, class_1799.field_8037));
    public static final Codec<BackpackContainerContents> CODEC = Slot.CODEC
            .sizeLimitedListOf(256)
            .xmap(BackpackContainerContents::fromSlots, BackpackContainerContents::asSlots);
    public static final class_9139<class_9129, BackpackContainerContents> STREAM_CODEC = class_1799.field_49268.method_56433(class_9135.method_58000(256)).method_56432
            (BackpackContainerContents::new, containerContents -> containerContents.items);

    private final class_2371<class_1799> items;
    private final int hashCode;

    private BackpackContainerContents(class_2371<class_1799> pItems) {
        if(pItems.size() > 256) {
            throw new IllegalArgumentException("Got " + pItems.size() + " items, but maximum is 256");
        } else {
            this.items = pItems;
            this.hashCode = class_1799.method_57361(pItems);
        }
    }

    public BackpackContainerContents(int pSize) {
        this(class_2371.method_10213(pSize, class_1799.field_8037));
    }

    //Only for Codec
    private BackpackContainerContents(List<class_1799> stacks) {
        this(stacks.size());
        for(int i = 0; i < stacks.size(); i++) {
            this.items.set(i, stacks.get(i));
        }
    }

    public class_2371<class_1799> getItems() {
        return this.items;
    }

    private static BackpackContainerContents fromSlots(List<Slot> slots) {
        OptionalInt optionalint = slots.stream().mapToInt(Slot::index).max();
        if(optionalint.isEmpty()) {
            return EMPTY;
        } else {
            BackpackContainerContents contents = new BackpackContainerContents(optionalint.getAsInt() + 1);
            for(Slot slot : slots) {
                contents.items.set(slot.index(), slot.item());
            }
            return contents;
        }
    }

    public static BackpackContainerContents fromItems(int size, List<class_1799> pItems) {
        BackpackContainerContents contents = new BackpackContainerContents(size);
        for(int j = 0; j < size; j++) {
            contents.items.set(j, pItems.get(j).method_7972());
        }
        return contents;
    }

    private List<Slot> asSlots() {
        List<Slot> list = new ArrayList<>();
        for(int i = 0; i < this.items.size(); i++) {
            class_1799 itemstack = this.items.get(i);
            list.add(new Slot(i, itemstack));
        }
        return list;
    }

    public static BackpackContainerContents updateSlot(BackpackContainerContents oldContents, BackpackContainerContents.Slot slot) {
        class_2371<class_1799> itemsCopy = class_2371.method_10213(oldContents.items.size(), class_1799.field_8037);
        oldContents.copyInto(itemsCopy);
        if(slot.index >= 0 && slot.index < itemsCopy.size()) {
            itemsCopy.set(slot.index, slot.item.method_7972());
        }
        return BackpackContainerContents.fromItems(itemsCopy.size(), itemsCopy);
    }

    public void copyInto(class_2371<class_1799> list) {
        for(int i = 0; i < list.size(); i++) {
            class_1799 itemstack = i < this.items.size() ? this.items.get(i) : class_1799.field_8037;
            list.set(i, itemstack.method_7972());
        }
    }

    /*public CompoundTag toNbt(HolderLookup.Provider provider) {
        ListTag nbtTagList = new ListTag();
        for(int i = 0; i < items.size(); i++) {
            if(!items.get(i).isEmpty()) {
                CompoundTag itemTag = new CompoundTag();
                itemTag.putInt("Slot", i);
                nbtTagList.add(items.get(i).save(provider, itemTag));
            }
        }
        CompoundTag nbt = new CompoundTag();
        nbt.put("Items", nbtTagList);
        //nbt.putInt("Size", items.size());
        return nbt;
    }*/
    public class_2487 toNbt(class_7225.class_7874 provider) {
        class_11362 output = class_11362.method_71459(class_8942.field_60348, provider);
        class_11372.class_11373<class_11343> itemList = output.method_71467("Items", class_11343.field_60354);
        for(int i = 0; i < items.size(); i++) {
            var stack = items.get(i);
            if(!stack.method_7960()) {
                itemList.method_71484(new class_11343(i, stack));
            }
        }
        output.method_71465("Size", items.size());
        return output.method_71475();
    }

    @Override
    public boolean equals(Object pOther) {
        if(this == pOther) {
            return true;
        } else {
            return pOther instanceof BackpackContainerContents contents && class_1799.method_57362(this.items, contents.items);
        }
    }

    @Override
    public int hashCode() {
        return this.hashCode;
    }

    public record Slot(int index, class_1799 item) {
        public static final Codec<Slot> CODEC = RecordCodecBuilder.create(inst -> inst.group(
                        Codec.intRange(0, 255).fieldOf("slot").forGetter(Slot::index),
                        class_1799.field_49266.fieldOf("item").forGetter(Slot::item))
                .apply(inst, Slot::new)
        );
    }
}
