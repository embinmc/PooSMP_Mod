package com.tiviacz.travelersbackpack.handlers;

import com.google.common.collect.ImmutableList;
import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.tiviacz.travelersbackpack.client.screens.ToolsScreen;
import com.tiviacz.travelersbackpack.common.BackpackAbilities;
import com.tiviacz.travelersbackpack.common.ServerActions;
import com.tiviacz.travelersbackpack.attachment.AttachmentUtils;
import com.tiviacz.travelersbackpack.config.TravelersBackpackConfig;
import com.tiviacz.travelersbackpack.init.ModItems;
import com.tiviacz.travelersbackpack.item.TravelersBackpackItem;
import com.tiviacz.travelersbackpack.network.ServerboundActionTagPacket;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenKeyboardEvents;
import net.fabricmc.fabric.api.event.Event;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1934;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import net.minecraft.class_465;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public class KeybindHandler {
    public static final class_2960 TRAVELERS_BACKPACK_PHASE = class_2960.method_60655(TravelersBackpack.MODID, "phase");
    public static final class_304.class_11900 CATEGORY = new class_304.class_11900(class_2960.method_60655(TravelersBackpack.MODID, "controls"));
   // private static final String CATEGORY = "key.travelersbackpack.category";
    public static final class_304 OPEN_BACKPACK = new class_304("key.travelersbackpack.inventory", class_3675.class_307.field_1668, GLFW.GLFW_KEY_B, CATEGORY);
    public static final class_304 SORT_BACKPACK = new class_304("key.travelersbackpack.sort", class_3675.class_307.field_1668, GLFW.GLFW_KEY_UNKNOWN, CATEGORY);
    public static final class_304 ABILITY = new class_304("key.travelersbackpack.ability", class_3675.class_307.field_1668, GLFW.GLFW_KEY_UNKNOWN, CATEGORY);
    public static final class_304 SWAP_TOOL = new class_304("key.travelersbackpack.cycle_tool", class_3675.class_307.field_1668, GLFW.GLFW_KEY_Z, CATEGORY);
    public static final class_304 TOGGLE_UPGRADE_0 = new class_304("key.travelersbackpack.toggle_upgrade_0", GLFW.GLFW_KEY_UNKNOWN, CATEGORY);
    public static final class_304 TOGGLE_UPGRADE_1 = new class_304("key.travelersbackpack.toggle_upgrade_1", GLFW.GLFW_KEY_UNKNOWN, CATEGORY);
    public static final class_304 TOGGLE_UPGRADE_2 = new class_304("key.travelersbackpack.toggle_upgrade_2", GLFW.GLFW_KEY_UNKNOWN, CATEGORY);
    public static final class_304 TOGGLE_UPGRADE_3 = new class_304("key.travelersbackpack.toggle_upgrade_3", GLFW.GLFW_KEY_UNKNOWN, CATEGORY);
    public static final List<class_304> TOGGLE_UPGRADE_KEYS = ImmutableList.of(TOGGLE_UPGRADE_0, TOGGLE_UPGRADE_1, TOGGLE_UPGRADE_2, TOGGLE_UPGRADE_3);

    public static void initKeybinds() {
        KeyBindingHelper.registerKeyBinding(OPEN_BACKPACK);
        KeyBindingHelper.registerKeyBinding(SORT_BACKPACK);
        KeyBindingHelper.registerKeyBinding(ABILITY);
        KeyBindingHelper.registerKeyBinding(SWAP_TOOL);
        KeyBindingHelper.registerKeyBinding(TOGGLE_UPGRADE_0);
        KeyBindingHelper.registerKeyBinding(TOGGLE_UPGRADE_1);
        KeyBindingHelper.registerKeyBinding(TOGGLE_UPGRADE_2);
        KeyBindingHelper.registerKeyBinding(TOGGLE_UPGRADE_3);
    }

    public static void registerListener() {
        ClientTickEvents.START_CLIENT_TICK.addPhaseOrdering(TRAVELERS_BACKPACK_PHASE, Event.DEFAULT_PHASE);

        ClientTickEvents.START_CLIENT_TICK.register(TRAVELERS_BACKPACK_PHASE, evt -> {
            class_310 mc = class_310.method_1551();
            class_1657 player = mc.field_1724;
            if(player == null) return;

            if(AttachmentUtils.isWearingBackpack(player)) {
                while(KeybindHandler.OPEN_BACKPACK.method_1436()) {
                    ServerboundActionTagPacket.create(ServerboundActionTagPacket.OPEN_SCREEN);
                }
                while(KeybindHandler.ABILITY.method_1436()) {
                    if(BackpackAbilities.ALLOWED_ABILITIES.contains(AttachmentUtils.getWearingBackpack(player).method_7909())) {
                        boolean ability = AttachmentUtils.getBackpackWrapperArtificial(player).isAbilityEnabled();
                        ServerboundActionTagPacket.create(ServerboundActionTagPacket.ABILITY_SLIDER, !ability);
                        player.method_7353(class_2561.method_43471(ability ? "screen.travelersbackpack.ability_disabled" : "screen.travelersbackpack.ability_enabled"), true);
                    }
                }
                while(KeybindHandler.SWAP_TOOL.method_1436()) {
                    if(mc.field_1755 == null && !mc.field_1690.field_1842 && mc.field_1761.method_2920() != class_1934.field_9219) {
                        if(!TravelersBackpackConfig.SERVER.backpackSettings.allowToolSwapping.get() && mc.field_1724.method_5998(class_1268.field_5808).method_7909() != ModItems.HOSE) {
                            return;
                        }
                        mc.method_1507(new ToolsScreen());
                    }
                }
                for(int i = 0; i < KeybindHandler.TOGGLE_UPGRADE_KEYS.size(); i++) {
                    class_304 key = KeybindHandler.TOGGLE_UPGRADE_KEYS.get(i);
                    while(key.method_1436()) {
                        ServerboundActionTagPacket.create(ServerboundActionTagPacket.UPGRADE_TAB, i, false, ServerActions.UPGRADE_ENABLED, false); //Upgrade status read on server
                    }
                }
            } else {
                while(KeybindHandler.OPEN_BACKPACK.method_1436()) {
                    for(int i = 0; i < player.method_31548().method_67533().size(); i++) {
                        class_1799 stack = player.method_31548().method_67533().get(i);
                        if(stack.method_7909() instanceof TravelersBackpackItem) {
                            ServerboundActionTagPacket.create(ServerboundActionTagPacket.OPEN_BACKPACK, i, false);
                            break;
                        }
                    }
                }
            }
        });

        ScreenEvents.BEFORE_INIT.register(((client, screen, scaledWidth, scaledHeight) -> {
            ScreenKeyboardEvents.beforeKeyPress(screen).register((gui, keyEvent) -> {
                class_1657 player = class_310.method_1551().field_1724;
                if(player == null) return;

                if(!TravelersBackpackConfig.SERVER.backpackSettings.allowOpeningFromSlot.get()) {
                    return;
                }
                if(screen instanceof class_465<?> containerScreen && client.field_1724 != null) {
                    if(KeybindHandler.OPEN_BACKPACK.method_1417(keyEvent)) {
                        class_1735 slot = containerScreen.field_2787;
                        if(slot != null && slot.method_7677().method_7909() instanceof TravelersBackpackItem && slot.method_32754(client.field_1724) && slot.field_7871 instanceof class_1661) {
                            ServerboundActionTagPacket.create(ServerboundActionTagPacket.OPEN_BACKPACK, slot.method_34266(), true);
                        }
                    }
                }
            });
        }));
    }

    public static boolean isKeyDown(class_304 keybind) {
        if(keybind.method_1415()) {
            return false;
        }
        return switch(keybind.field_1655.method_1442()) {
            case field_1668 ->
                    class_3675.method_15987(class_310.method_1551().method_22683(), keybind.field_1655.method_1444());
            case field_1672 ->
                    GLFW.glfwGetMouseButton(class_310.method_1551().method_22683().method_4490(), keybind.field_1655.method_1444()) == GLFW.GLFW_PRESS;
            default -> keybind.method_1434();
        };
    }
}