package com.tiviacz.travelersbackpack.handlers;

import com.tiviacz.travelersbackpack.config.TravelersBackpackConfig;
import com.tiviacz.travelersbackpack.init.ModItems;
import net.fabricmc.fabric.api.object.builder.v1.trade.TradeOfferHelper;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1914;
import net.minecraft.class_3852;
import net.minecraft.class_9306;

public class TradeOffersHandler {
    public static void init() {
        if(TravelersBackpackConfig.COMMON.enableVillagerTrade.get()) {
            TradeOfferHelper.registerVillagerOffers(class_3852.field_17060, 3, factories -> factories.add(
                    (trader, entity, randomSource) -> new class_1914(new class_9306(class_1802.field_8687, randomSource.method_43048(64) + 48),
                            new class_1799(ModItems.VILLAGER_TRAVELERS_BACKPACK, 1), 1, 50, 0.5F)));
        }
    }
}