package com.tiviacz.travelersbackpack.handlers;

import com.tiviacz.travelersbackpack.init.ModItems;
import com.tiviacz.travelersbackpack.item.TravelersBackpackItem;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1542;

public class EntityItemHandler {
    public static void registerListeners() {
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if(entity instanceof class_1542 itemEntity && itemEntity.method_6983().method_7909() instanceof TravelersBackpackItem backpack) {
                if(itemEntity.method_5864() != ModItems.BACKPACK_ITEM_ENTITY) {
                    class_1297 backpackEntity = backpack.createEntity(world, itemEntity, itemEntity.method_6983());
                    if(backpackEntity != null) {
                        itemEntity.method_31472();
                        world.method_8649(backpackEntity);
                    }
                }
            }
        });
    }
}