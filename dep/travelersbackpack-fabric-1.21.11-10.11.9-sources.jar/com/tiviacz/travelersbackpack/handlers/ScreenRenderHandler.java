package com.tiviacz.travelersbackpack.handlers;

import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.tiviacz.travelersbackpack.client.screens.tooltip.BackpackTooltipComponent;
import com.tiviacz.travelersbackpack.attachment.AttachmentUtils;
import com.tiviacz.travelersbackpack.config.TravelersBackpackConfig;
import com.tiviacz.travelersbackpack.inventory.menu.slot.BackpackSlotItemHandler;
import com.tiviacz.travelersbackpack.item.TravelersBackpackItem;
import com.tiviacz.travelersbackpack.network.ServerboundActionTagPacket;
import com.tiviacz.travelersbackpack.network.ServerboundRetrieveBackpackPacket;
import com.tiviacz.travelersbackpack.util.PacketDistributor;
import com.tiviacz.travelersbackpack.util.RenderHelper;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenMouseEvents;
import net.minecraft.class_10712;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_465;
import net.minecraft.class_490;
import net.minecraft.class_5632;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ScreenRenderHandler {
    public static void renderAboveContents(class_465<?> screen, class_332 guiGraphics, int mouseX, int mouseY) {
        class_310 mc = class_310.method_1551();
        class_1657 player = mc.field_1724;
        if(player == null) return;

        //Draw + and - for items that can be inserted to backpack
        if(!TravelersBackpackItem.isCreative(player)) {
            var menu = screen.method_17577();
            class_1799 carried = menu.method_34255();
            class_1735 hoveredSlot = screen.field_2787;
            Optional<class_5632> tooltip = Optional.empty();

            guiGraphics.method_51448().pushMatrix();
            guiGraphics.method_51448().translate((float)screen.field_2776, (float)screen.field_2800);

            for(class_1735 slot : menu.field_7761) {
                class_1799 slotStack = slot.method_7677();
                if(carried.method_7909() instanceof TravelersBackpackItem) {
                    tooltip = Optional.of(new BackpackTooltipComponent(carried, true));
                    if(!slotStack.method_7960() && slot.method_7674(player) && BackpackSlotItemHandler.isItemValid(slotStack)) {
                        guiGraphics.method_27535(mc.field_1772, class_2561.method_43470("-").method_27692(class_124.field_1054), slot.field_7873 + 2, slot.field_7872 - 1, -1); //16109090
                        if(slot == hoveredSlot) {
                            guiGraphics.method_64038(mc.field_1772, List.of(class_2561.method_43471("screen.travelersbackpack.add_to_backpack").method_27692(class_124.field_1054)), tooltip, mouseX, mouseY);
                        }
                    }
                } else if(!carried.method_7960() && BackpackSlotItemHandler.isItemValid(carried)) {
                    if(slotStack.method_7909() instanceof TravelersBackpackItem && slot.method_32754(player)) {
                        tooltip = Optional.of(new BackpackTooltipComponent(slotStack, true));
                        guiGraphics.method_27535(mc.field_1772, class_2561.method_43470("+").method_27692(class_124.field_1054), slot.field_7873 + 9, slot.field_7872 + 8, -1); //16109090
                        if(slot == hoveredSlot) {
                            guiGraphics.method_64038(mc.field_1772, List.of(class_2561.method_43471("screen.travelersbackpack.add_to_backpack").method_27692(class_124.field_1054)), tooltip, mouseX, mouseY);
                        }
                    }
                }
            }
            guiGraphics.method_51448().popMatrix();
        }

        //Render Backpack Icon if Backpack is equipped in Capability but Integration is enabled to easily retrieve the backpack
        if(mc.field_1755 instanceof class_490) {
            boolean highlighted = mouseX >= screen.field_2776 + 77 && mouseX < screen.field_2776 + 77 + 16 && mouseY >= screen.field_2800 + 62 - 18 && mouseY < screen.field_2800 + 62 - 18 + 16;
            if(AttachmentUtils.getAttachment(player).isPresent()) {
                if(AttachmentUtils.getAttachment(player).get().hasBackpack() && TravelersBackpack.enableIntegration()) {
                    class_1799 backpack = AttachmentUtils.getAttachment(player).get().getBackpack();
                    if(highlighted) {
                        RenderHelper.renderSlotHighlightBack(guiGraphics, screen.field_2776 + 77, screen.field_2800 + 62 - 18);
                    }
                    guiGraphics.method_51427(backpack, screen.field_2776 + 77, screen.field_2800 + 62 - 18);

                    if(highlighted) {
                        List<class_2561> components = new ArrayList<>();
                        components.add(class_2561.method_43471("screen.travelersbackpack.retrieve_backpack"));
                        guiGraphics.method_64038(class_310.method_1551().field_1772, components, Optional.of(new BackpackTooltipComponent(backpack)), mouseX, mouseY);
                        RenderHelper.renderSlotHighlightFront(guiGraphics, screen.field_2776 + 77, screen.field_2800 + 62 - 18);
                    }
                }
            }

            if(!TravelersBackpackConfig.CLIENT.showBackpackIconInInventory.get()) return;

            if(AttachmentUtils.isWearingBackpack(player)) {
                if(TravelersBackpack.enableIntegration()) return;

                class_1799 backpack = AttachmentUtils.getWearingBackpack(player);
                if(highlighted) {
                    RenderHelper.renderSlotHighlightBack(guiGraphics, screen.field_2776 + 77, screen.field_2800 + 62 - 18);
                }
                guiGraphics.method_51427(backpack, screen.field_2776 + 77, screen.field_2800 + 62 - 18);

                if(highlighted) {
                    String button = KeybindHandler.OPEN_BACKPACK.method_16007().getString();
                    List<class_2561> components = new ArrayList<>();
                    components.add(class_2561.method_43469("screen.travelersbackpack.open_inventory", button));
                    components.add(class_2561.method_43471("screen.travelersbackpack.unequip_tip"));
                    components.add(class_2561.method_43471("screen.travelersbackpack.hide_icon"));
                    class_1836.class_1837 tooltipflag$default = class_310.method_1551().field_1690.field_1827 ? class_1836.class_1837.field_41071 : class_1836.class_1837.field_41070;
                    backpack.method_7909().method_67187(backpack, class_1792.class_9635.method_59528(player.method_73183()), class_10712.field_56318, components::add, tooltipflag$default);
                    guiGraphics.method_64038(mc.field_1772, components, Optional.of(new BackpackTooltipComponent(backpack)), mouseX, mouseY);
                    RenderHelper.renderSlotHighlightFront(guiGraphics, screen.field_2776 + 77, screen.field_2800 + 62 - 18);
                }
            }
        }
    }

    public static void registerScreenEvents() {
        ScreenEvents.AFTER_INIT.register(((client, screen2, scaledWidth, scaledHeight) -> {
            class_310 mc = class_310.method_1551();
            class_1657 player = mc.field_1724;
            if(player == null) return;

            if(screen2 instanceof class_490 screen) {
                ScreenMouseEvents.afterMouseClick(screen).register((screen1, mouseButtonEvent, doubleClick) -> {
                    //Render Backpack Icon if Backpack is equipped in Capability but Integration is enabled to easily retrieve the backpack
                    if(class_310.method_1551().field_1755 instanceof class_490 && AttachmentUtils.getAttachment(player).isPresent()) {
                        if(AttachmentUtils.getAttachment(player).get().hasBackpack() && TravelersBackpack.enableIntegration()) {
                            if(mouseButtonEvent.comp_4798() >= screen.field_2776 + 77 && mouseButtonEvent.comp_4798() < screen.field_2776 + 77 + 16 && mouseButtonEvent.comp_4799() >= screen.field_2800 + 62 - 18 && mouseButtonEvent.comp_4799() < screen.field_2800 + 62 - 18 + 16) {
                                if(mouseButtonEvent.method_74245() == GLFW.GLFW_MOUSE_BUTTON_1) {
                                    PacketDistributor.sendToServer(new ServerboundRetrieveBackpackPacket(AttachmentUtils.getAttachment(player).get().getBackpack().method_7909().method_7854()));
                                    return true;
                                }
                            }
                        }
                    }

                    if(!TravelersBackpackConfig.CLIENT.showBackpackIconInInventory.get()) return false;

                    if(AttachmentUtils.isWearingBackpack(player)) {
                        if(TravelersBackpack.enableIntegration()) return false;

                        if(mouseButtonEvent.comp_4798() >= screen.field_2776 + 77 && mouseButtonEvent.comp_4798() < screen.field_2776 + 77 + 16 && mouseButtonEvent.comp_4799() >= screen.field_2800 + 62 - 18 && mouseButtonEvent.comp_4799() < screen.field_2800 + 62 - 18 + 16) {
                            if(mouseButtonEvent.method_74245() == GLFW.GLFW_MOUSE_BUTTON_1) {
                                ServerboundActionTagPacket.create(ServerboundActionTagPacket.OPEN_SCREEN);
                                return true;
                            }
                            if(mouseButtonEvent.method_74245() == GLFW.GLFW_MOUSE_BUTTON_2) {
                                if(class_3675.method_15987(class_310.method_1551().method_22683(), GLFW.GLFW_KEY_LEFT_SHIFT)) {
                                    class_310.method_1551().field_1705.method_1743().method_1812(class_2561.method_43471("screen.travelersbackpack.hide_icon_info"));
                                    return true;
                                }
                            }
                        }
                    }
                    return false;
                });
            }
        }));
    }
}