package com.tiviacz.travelersbackpack.handlers;

import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.tiviacz.travelersbackpack.common.BackpackAbilities;
import com.tiviacz.travelersbackpack.attachment.AttachmentUtils;
import com.tiviacz.travelersbackpack.init.ModItems;
import com.tiviacz.travelersbackpack.item.TravelersBackpackItem;
import com.tiviacz.travelersbackpack.network.ClientboundSendMessagePacket;
import com.tiviacz.travelersbackpack.util.BackpackDeathHelper;
import com.tiviacz.travelersbackpack.util.LogHelper;
import com.tiviacz.travelersbackpack.util.PacketDistributor;
import com.tiviacz.travelersbackpack.util.Reference;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.minecraft.class_1304;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1928;
import net.minecraft.class_3218;
import net.minecraft.class_3222;

public class DeathHandler {
    public static void registerListeners() {
        ServerLivingEntityEvents.ALLOW_DEATH.register((livingEntity, damageSource, damageAmount) -> {
            if(livingEntity instanceof class_3222 player) {
                if(BackpackAbilities.ABILITIES.checkBackpack(player, ModItems.CREEPER_TRAVELERS_BACKPACK)) {
                    return !BackpackAbilities.creeperAbility(player);
                }
            }
            return true;
        });

        ServerLivingEntityEvents.AFTER_DEATH.register((livingEntity, damageSource) -> {
            if(livingEntity instanceof class_3222 player) {
                if(AttachmentUtils.isWearingBackpack(player)) {
                    //If integration detected, then do not use this logic, it will be handled by the integration/added to the grave
                    if(TravelersBackpack.enableIntegration()) {
                        return;
                    }

                    //Keep backpack on with Keep Inventory game rule
                    if(player.method_51469() instanceof class_3218 serverLevel) {
                        if(serverLevel.method_64395().method_76185(class_1928.field_19389)) return;
                    }

                    class_1799 stack = AttachmentUtils.getWearingBackpack(player);

                    if(BackpackDeathHelper.onPlayerDrops(player.method_51469(), player, stack)) {
                        if(player.method_51469().method_8608()) return;

                        class_1542 itemEntity = new class_1542(player.method_51469(), player.method_23317(), player.method_23318(), player.method_23321(), stack);
                        itemEntity.method_6988();

                        PacketDistributor.sendToPlayer(player, new ClientboundSendMessagePacket(true, player.method_24515()));
                        LogHelper.info("There's no space for backpack. Dropping backpack item at" + " X: " + player.method_24515().method_10263() + " Y: " + player.method_23318() + " Z: " + player.method_24515().method_10260());

                        player.method_51469().method_8649(itemEntity);

                        AttachmentUtils.getAttachment(player).ifPresent(attachment -> {
                            attachment.remove(player);
                            attachment.synchronise(player);
                        });
                        return;
                    }
                }
            }
            if(Reference.ALLOWED_TYPE_ENTRIES.contains(livingEntity.method_5864())) {
                if(livingEntity.method_6118(class_1304.field_6174).method_7909() instanceof TravelersBackpackItem) {
                    if(!(damageSource.method_5526() instanceof class_1657)) return;

                    class_1542 itemEntity = new class_1542(livingEntity.method_73183(), livingEntity.method_23317(), livingEntity.method_23318(), livingEntity.method_23321(), livingEntity.method_6118(class_1304.field_6174));
                    livingEntity.method_73183().method_8649(itemEntity);
                }
            }
        });

        ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
            class_1799 backpack = AttachmentUtils.getWearingBackpack(oldPlayer);
            AttachmentUtils.getAttachment(oldPlayer).ifPresent(attachment -> attachment.equipBackpack(backpack, newPlayer));
            //AttachmentUtils.synchronise(oldPlayer);
        });
    }
}
