package com.tiviacz.travelersbackpack.handlers;

import com.tiviacz.travelersbackpack.config.TravelersBackpackConfig;
import com.tiviacz.travelersbackpack.init.ModItems;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.class_1792;
import net.minecraft.class_219;
import net.minecraft.class_39;
import net.minecraft.class_52;
import net.minecraft.class_55;
import net.minecraft.class_77;

public class LootHandler {
    public static void registerListeners() {
        if(TravelersBackpackConfig.COMMON.enableLoot.get()) {
            LootTableEvents.MODIFY.register((key, tableBuilder, source, provider) ->
            {
                if(class_39.field_472.equals(key)) {
                    addLootPool(tableBuilder, ModItems.BAT_TRAVELERS_BACKPACK, 0.05F);

                    addLootPool(tableBuilder, ModItems.STANDARD_TRAVELERS_BACKPACK, 0.06F);
                    addLootPool(tableBuilder, ModItems.IRON_TIER_UPGRADE, 0.05F);
                    addLootPool(tableBuilder, ModItems.GOLD_TIER_UPGRADE, 0.04F);
                }

                if(class_39.field_17009.equals(key)) {
                    addLootPool(tableBuilder, ModItems.IRON_GOLEM_TRAVELERS_BACKPACK, 0.1F);
                }

                if(class_39.field_356.equals(key)) {
                    addLootPool(tableBuilder, ModItems.STANDARD_TRAVELERS_BACKPACK, 0.06F);
                    addLootPool(tableBuilder, ModItems.IRON_TIER_UPGRADE, 0.05F);
                }

                if(class_39.field_885.equals(key)) {
                    addLootPool(tableBuilder, ModItems.STANDARD_TRAVELERS_BACKPACK, 0.06F);
                    addLootPool(tableBuilder, ModItems.IRON_TIER_UPGRADE, 0.05F);
                    addLootPool(tableBuilder, ModItems.GOLD_TIER_UPGRADE, 0.04F);
                }

                if(class_39.field_665.equals(key)) {
                    addLootPool(tableBuilder, ModItems.IRON_TIER_UPGRADE, 0.06F);
                    addLootPool(tableBuilder, ModItems.GOLD_TIER_UPGRADE, 0.05F);
                }

                if(class_39.field_484.equals(key)) {
                    addLootPool(tableBuilder, ModItems.IRON_TIER_UPGRADE, 0.06F);
                    addLootPool(tableBuilder, ModItems.GOLD_TIER_UPGRADE, 0.05F);
                }

                if(class_39.field_615.equals(key)) {
                    addLootPool(tableBuilder, ModItems.IRON_TIER_UPGRADE, 0.07F);
                    addLootPool(tableBuilder, ModItems.GOLD_TIER_UPGRADE, 0.06F);
                }

                if(class_39.field_24046.equals(key)) {
                    addLootPool(tableBuilder, ModItems.IRON_TIER_UPGRADE, 0.07F);
                    addLootPool(tableBuilder, ModItems.GOLD_TIER_UPGRADE, 0.06F);
                }

                if(class_39.field_274.equals(key)) {
                    addLootPool(tableBuilder, ModItems.GOLD_TIER_UPGRADE, 0.07F);
                    addLootPool(tableBuilder, ModItems.DIAMOND_TIER_UPGRADE, 0.06F);
                }
            });
        }
    }

    public static void addLootPool(class_52.class_53 builder, class_1792 item, float chance) {
        builder.pool(class_55.method_347().with(class_77.method_411(item).method_419()).conditionally(class_219.method_932(chance).build()).method_355());
    }
}