package com.tiviacz.travelersbackpack.mixin;

import com.tiviacz.travelersbackpack.attachment.AttachmentUtils;
import com.tiviacz.travelersbackpack.item.TravelersBackpackItem;
import com.tiviacz.travelersbackpack.util.HumanoidRenderStateBackpackInject;
import net.minecraft.class_10034;
import net.minecraft.class_10442;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1560;
import net.minecraft.class_1613;
import net.minecraft.class_1639;
import net.minecraft.class_1642;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_4836;
import net.minecraft.class_909;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_909.class)
public class HumoanoidMobRenderer {
    @Inject(at = @At(value = "TAIL"), method = "extractHumanoidRenderState")
    private static void render(class_1309 entity, class_10034 reusedState, float partialTick, class_10442 itemModelResolver, CallbackInfo ci) {
        if(entity instanceof class_1657 player && reusedState instanceof HumanoidRenderStateBackpackInject injectedReusedState) {
            class_1799 backpack = AttachmentUtils.getWearingBackpack(player);
            if(!backpack.method_7960()) {
                injectedReusedState.setBackpackStack(backpack);
            } else if(injectedReusedState.getBackpackStack() != null) {
                injectedReusedState.setBackpackStack(null);
            }
            injectedReusedState.setName(player.method_7334().name());
        }

        if(entity instanceof class_1642 || entity instanceof class_1613 || entity instanceof class_1560 || entity instanceof class_1639 || entity instanceof class_4836) {
            if(reusedState instanceof HumanoidRenderStateBackpackInject injectedReusedState) {
                class_1799 backpack = entity.method_6118(class_1304.field_6174);
                if(backpack.method_7909() instanceof TravelersBackpackItem) {
                    injectedReusedState.setChestItem(backpack);
                }
            }
        }
    }
}
