package com.tiviacz.travelersbackpack.mixin;

import net.minecraft.class_5218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_5218.class)
public interface LevelResourceMixin {
    @Invoker("<init>")
    static class_5218 invokeInit(String path) {
        throw new AssertionError();
    }
}