package com.tiviacz.travelersbackpack.mixin;

import com.tiviacz.travelersbackpack.inventory.menu.AbstractBackpackMenu;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_5536;
import net.minecraft.class_5630;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(class_1703.class)
public class AbstractContainerMenuMixin {
    //Fix for EasyShulkerBoxes Duplication bug - load only if said mod is installed
    @Redirect(method = "tryItemClickBehaviourOverride", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;overrideOtherStackedOnMe(Lnet/minecraft/world/item/ItemStack;Lnet/minecraft/world/inventory/Slot;Lnet/minecraft/world/inventory/ClickAction;Lnet/minecraft/world/entity/player/Player;Lnet/minecraft/world/entity/SlotAccess;)Z"))
    private boolean redirectOverride(class_1799 clickedItem, class_1799 carriedItem, class_1735 slot, class_5536 action, class_1657 player, class_5630 slotAccess) {
        boolean result = clickedItem.method_31576(carriedItem, slot, action, player, slotAccess);
        if(result) {
            if(player.field_7512 instanceof AbstractBackpackMenu && !(slot.field_7871 instanceof class_1661)) { //Only for backpack, vanilla inventory slots work fine so do not include them
                slot.method_7673(clickedItem.method_7972());
            }
        }
        return result;
    }
}