package com.tiviacz.travelersbackpack.mixin;

import com.tiviacz.travelersbackpack.handlers.ScreenRenderHandler;
import net.minecraft.class_332;
import net.minecraft.class_465;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_465.class)
public class AbstractContainerScreenMixin {
    @Inject(at = @At(value = "TAIL"), method = "renderContents")
    private void renderContents(class_332 guiGraphics, int i, int j, float f, CallbackInfo ci) {
        if((Object)this instanceof class_465<?> screen) {
            ScreenRenderHandler.renderAboveContents(screen, guiGraphics, i, j);
        }
    }
}