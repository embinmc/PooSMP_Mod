package com.tiviacz.travelersbackpack.mixin;

import com.tiviacz.travelersbackpack.client.screens.RadialToolsOverlay;
import com.tiviacz.travelersbackpack.client.screens.ToolsScreen;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_329.class)
public class GuiMixin {
    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    private void onRenderCrosshair(class_332 guiGraphics, class_9779 deltaTracker, CallbackInfo ci) {
        if(class_310.method_1551().field_1755 instanceof ToolsScreen && !RadialToolsOverlay.drawCrosshair) {
            ci.cancel();
        }
    }
}
