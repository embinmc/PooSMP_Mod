package com.tiviacz.travelersbackpack.mixin;

import com.tiviacz.travelersbackpack.components.RenderInfo;
import com.tiviacz.travelersbackpack.config.TravelersBackpackConfig;
import com.tiviacz.travelersbackpack.init.ModDataComponents;
import com.tiviacz.travelersbackpack.init.ModItems;
import com.tiviacz.travelersbackpack.item.upgrades.TanksUpgradeItem;
import com.tiviacz.travelersbackpack.util.Reference;
import net.minecraft.class_1266;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1315;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_3730;
import net.minecraft.class_5425;
import net.minecraft.class_5819;
import net.minecraft.class_9282;
import net.minecraft.class_9288;
import net.minecraft.class_9334;
import net.minecraft.world.entity.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;

@Mixin(class_1308.class)
public abstract class MobEntityMixin extends class_1309 {

    protected MobEntityMixin(class_1299<? extends class_1309> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(at = @At(value = "TAIL"), method = "finalizeSpawn")
    protected void initialize(class_5425 level, class_1266 difficulty, class_3730 spawnType, class_1315 spawnGroupData, CallbackInfoReturnable<class_1315> cir) {
        if(TravelersBackpackConfig.SERVER.world.spawnEntitiesWithBackpack.get()) {
            if((Object)this instanceof class_1309 livingEntity && livingEntity.method_6118(class_1304.field_6174).method_7960() && !livingEntity.method_6109() && Reference.ALLOWED_TYPE_ENTRIES.contains(livingEntity.method_5864())) {
                if(level.method_8409().method_43057() < TravelersBackpackConfig.SERVER.world.chance.get()) {
                    boolean isNether = livingEntity.method_5864() == class_1299.field_22281 || livingEntity.method_5864() == class_1299.field_6076;
                    class_5819 rand = level.method_8409();
                    class_1799 backpack = isNether ?
                            ModItems.COMPATIBLE_NETHER_BACKPACK_ENTRIES.get(rand.method_39332(0, ModItems.COMPATIBLE_NETHER_BACKPACK_ENTRIES.size() - 1)).method_7854() :
                            ModItems.COMPATIBLE_OVERWORLD_BACKPACK_ENTRIES.get(rand.method_39332(0, ModItems.COMPATIBLE_OVERWORLD_BACKPACK_ENTRIES.size() - 1)).method_7854();

                    backpack.method_57379(ModDataComponents.SLEEPING_BAG_COLOR, class_1767.values()[rand.method_39332(0, class_1767.values().length - 1)].method_7789());
                    boolean flag = false;
                    if(rand.method_43057() > 0.5F) {
                        backpack.method_57379(ModDataComponents.STARTER_UPGRADES, class_9288.method_57493(List.of(ModItems.TANKS_UPGRADE.method_7854())));
                        flag = true;
                    }
                    if(rand.method_43057() > 0.25F) {
                        backpack.method_57379(class_9334.field_49644, new class_9282(rand.method_43054()));
                    }
                    if(flag) {
                        backpack.method_57379(ModDataComponents.RENDER_INFO, TanksUpgradeItem.writeToRenderData());
                    } else {
                        backpack.method_57379(ModDataComponents.RENDER_INFO, RenderInfo.EMPTY);
                    }
                    livingEntity.method_5673(class_1304.field_6174, backpack);
                }
            }
        }
    }
}