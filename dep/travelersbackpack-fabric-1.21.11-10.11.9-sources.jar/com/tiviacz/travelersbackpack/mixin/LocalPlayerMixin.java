package com.tiviacz.travelersbackpack.mixin;

import com.tiviacz.travelersbackpack.client.screens.ToolsScreen;
import com.tiviacz.travelersbackpack.handlers.KeybindHandler;
import net.minecraft.class_10185;
import net.minecraft.class_241;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_744;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_746.class)
public abstract class LocalPlayerMixin {
    @Shadow
    public class_744 input;

    @Inject(method = "aiStep", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/player/ClientInput;tick()V", shift = At.Shift.AFTER))
    private void afterInputTick(CallbackInfo ci) {
        class_310 mc = class_310.method_1551();
        if(mc.field_1755 instanceof ToolsScreen) {
            class_315 settings = class_310.method_1551().field_1690;
            input.field_54155 = new class_10185(KeybindHandler.isKeyDown(settings.field_1894), KeybindHandler.isKeyDown(settings.field_1881), KeybindHandler.isKeyDown(settings.field_1913), KeybindHandler.isKeyDown(settings.field_1849), KeybindHandler.isKeyDown(settings.field_1903), KeybindHandler.isKeyDown(settings.field_1832), KeybindHandler.isKeyDown(settings.field_1867));
            input.field_55868 = new class_241(input.field_54155.comp_3161() == input.field_54155.comp_3162() ? 0.0F : (input.field_54155.comp_3161() ? 1.0F : -1.0F), input.field_54155.comp_3159() == input.field_54155.comp_3160() ? 0.0F : (input.field_54155.comp_3159() ? 1.0F : -1.0F));
            if (class_310.method_1551().field_1724.method_20303()) {
                input.field_55868 = new class_241((float)((double)input.field_55868.field_1343 * 0.3), (float)((double)input.field_55868.field_1342 * 0.3));
            }
        }
    }
}