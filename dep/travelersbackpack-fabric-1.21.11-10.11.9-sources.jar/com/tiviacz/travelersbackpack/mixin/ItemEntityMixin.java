package com.tiviacz.travelersbackpack.mixin;

import com.tiviacz.travelersbackpack.attachment.AttachmentUtils;
import com.tiviacz.travelersbackpack.inventory.BackpackWrapper;
import com.tiviacz.travelersbackpack.inventory.upgrades.pickup.AutoPickupUpgrade;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1542.class)
public abstract class ItemEntityMixin {
    @Shadow
    public abstract class_1799 getItem();

    @Shadow
    public int pickupDelay;

    @Shadow
    public abstract void setItem(class_1799 stack);

    @Inject(method = "playerTouch", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/item/ItemStack;getCount()I"), cancellable = true)
    private void playerTouch(class_1657 player, CallbackInfo ci) {
        if(this.getItem().method_7960() || this.pickupDelay > 0) {
            return;
        }

        class_1937 level = player.method_73183();

        if(AttachmentUtils.isWearingBackpack(player)) {
            BackpackWrapper wrapper = AttachmentUtils.getBackpackWrapper(player);
            wrapper.getUpgradeManager().getUpgrade(AutoPickupUpgrade.class).ifPresent(pickupUpgrade -> {
                if(pickupUpgrade.canPickup(getItem()) && pickupUpgrade.tryPickup((class_1542)(Object)this, level, player.method_24515())) {
                    ci.cancel();
                }
            });
        }
    }
}