package com.tiviacz.travelersbackpack.mixin.abilities;

import com.tiviacz.travelersbackpack.common.BackpackAbilities;
import com.tiviacz.travelersbackpack.config.TravelersBackpackConfig;
import net.minecraft.class_1299;
import net.minecraft.class_1677;
import net.minecraft.class_1937;
import net.minecraft.class_3855;
import net.minecraft.class_3966;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1677.class)
public class SmallFireballEntityMixin extends class_3855 {
    public SmallFireballEntityMixin(class_1299<? extends class_3855> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(at = @At(value = "HEAD"), method = "onHitEntity", cancellable = true)
    public void onEntityHit(class_3966 entityHitResult, CallbackInfo ci) {
        if(TravelersBackpackConfig.SERVER.backpackAbilities.enableBackpackAbilities.get()) {
            if(!this.method_73183().method_8608()) {
                if(this instanceof Object) {
                    if((Object)this instanceof class_1677 smallFireball) {
                        BackpackAbilities.blazeAbility(entityHitResult, smallFireball, ci);
                    }
                }
            }
        }
    }
}