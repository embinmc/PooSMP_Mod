package com.tiviacz.travelersbackpack.mixin.abilities;

import com.tiviacz.travelersbackpack.common.BackpackAbilities;
import net.minecraft.class_1299;
import net.minecraft.class_1560;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1560.class)
public class EndermanEntityMixin extends class_1588 {
    protected EndermanEntityMixin(class_1299<? extends class_1588> entityType, class_1937 level) {
        super(entityType, level);
    }

    @Inject(at = @At(value = "HEAD"), method = "isBeingStaredBy", cancellable = true)
    public void isPlayerStaring(class_1657 player, CallbackInfoReturnable<Boolean> cir) {
        BackpackAbilities.pumpkinAbility(player, cir);
    }
}