package com.tiviacz.travelersbackpack.mixin;

import com.tiviacz.travelersbackpack.inventory.menu.AbstractBackpackMenu;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_5536;
import net.minecraft.class_5630;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1799.class)
public class ItemStackMixin {
    //Fix for bundle not saving when contents change in backpack (Potentially any resource handler)
    @Inject(method = "overrideOtherStackedOnMe", at = @At(value = "TAIL"))
    private void afterOverrideOtherStackedOnMe(class_1799 stack, class_1735 slot, class_5536 action, class_1657 player, class_5630 access, CallbackInfoReturnable<Boolean> cir) {
        boolean result = cir.getReturnValue();
        if(player.field_7512 instanceof AbstractBackpackMenu && !(slot.field_7871 instanceof class_1661)) { //Only for backpack, vanilla inventory slots work fine so do not include them
            if(result && (Object)this instanceof class_1799 clicked) {
                slot.method_7673(clicked.method_7972());
            }
        }
    }
}