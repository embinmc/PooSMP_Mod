package com.tiviacz.travelersbackpack.mixin;

import com.tiviacz.travelersbackpack.attachment.TravelersBackpackAttachment;
import com.tiviacz.travelersbackpack.common.BackpackAbilities;
import com.tiviacz.travelersbackpack.common.ServerActions;
import com.tiviacz.travelersbackpack.attachment.AttachmentUtils;
import com.tiviacz.travelersbackpack.config.TravelersBackpackConfig;
import com.tiviacz.travelersbackpack.init.ModAttachmentTypes;
import com.tiviacz.travelersbackpack.init.ModItems;
import com.tiviacz.travelersbackpack.inventory.BackpackWrapper;
import com.tiviacz.travelersbackpack.item.TravelersBackpackItem;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;
import net.minecraft.class_11368;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1656;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;

@Mixin(class_1657.class)
public abstract class PlayerMixin extends class_1309 {
    @Shadow
    @Final
    private class_1656 abilities;

    protected PlayerMixin(class_1299<? extends class_1309> entityType, class_1937 level) {
        super(entityType, level);
    }

    private static long nextBackpackCountCheck = 0;
    private static final int BACKPACK_COUNT_CHECK_COOLDOWN = 100;

    /**
     * Ability removal for attribute modifiers
     */
    private static boolean checkAbilitiesForRemoval = true;

    @Inject(at = @At(value = "TAIL"), method = "tick")
    private void abilityTick(CallbackInfo info) {
        if(this instanceof Object) {
            if((Object)this instanceof class_1657 player) {
                if(AttachmentUtils.isWearingBackpack(player)) {
                    BackpackWrapper.tick(AttachmentUtils.getWearingBackpack(player), player, false);
                }
                if(TravelersBackpackConfig.SERVER.backpackAbilities.enableBackpackAbilities.get() && BackpackAbilities.isOnList(BackpackAbilities.ITEM_ABILITIES_LIST, AttachmentUtils.getWearingBackpack(player))) {
                    if(!checkAbilitiesForRemoval && BackpackAbilities.isOnList(BackpackAbilities.ITEM_ABILITIES_REMOVAL_LIST, AttachmentUtils.getWearingBackpack(player)))
                        checkAbilitiesForRemoval = true;
                }
                if(checkAbilitiesForRemoval && !player.method_73183().method_8608() && (!AttachmentUtils.isWearingBackpack(player) || !TravelersBackpackConfig.SERVER.backpackAbilities.enableBackpackAbilities.get())) {
                    ServerActions.runAbilitiesRemoval(player);
                    checkAbilitiesForRemoval = false;
                }

                //Slowness
                if(TravelersBackpackConfig.SERVER.slownessDebuff.tooManyBackpacksSlowness.get() && !player.method_68878()) {
                    if(nextBackpackCountCheck > player.method_73183().method_75260()) {
                        return;
                    }

                    nextBackpackCountCheck = player.method_73183().method_75260() + BACKPACK_COUNT_CHECK_COOLDOWN;

                    AtomicInteger numberOfBackpacks = checkBackpacksForSlowness(player);

                    if(numberOfBackpacks.get() == 0) return;

                    int maxNumberOfBackpacks = TravelersBackpackConfig.SERVER.slownessDebuff.maxNumberOfBackpacks.get();

                    if(numberOfBackpacks.get() > maxNumberOfBackpacks) {
                        int numberOfSlownessLevels = Math.min(10, (int)Math.ceil((numberOfBackpacks.get() - maxNumberOfBackpacks) * TravelersBackpackConfig.SERVER.slownessDebuff.slownessPerExcessedBackpack.get()));
                        player.method_6092(new class_1293(class_1294.field_5909, BACKPACK_COUNT_CHECK_COOLDOWN * 2, numberOfSlownessLevels - 1, false, false));
                    }
                }
            }
        }
    }

    @Inject(at = @At(value = "HEAD"), method = "attack")
    private void attack(class_1297 target, CallbackInfo ci) {
        if(TravelersBackpackConfig.SERVER.backpackAbilities.enableBackpackAbilities.get()) {
            if(this instanceof Object) {
                if((Object)this instanceof class_1657 player) {
                    BackpackAbilities.beeAbility(player, target);
                    BackpackAbilities.witherAbility(player, target);
                    BackpackAbilities.wardenAbility(player, target);
                }
            }
        }
    }

    @Inject(method = "getFlyingSpeed", at = @At(value = "RETURN"), cancellable = true)
    protected void getFlyingSpeed(CallbackInfoReturnable<Float> cir) {
        if((Object)this instanceof class_1657 player) {
            if(BackpackAbilities.ABILITIES.checkBackpack(player, ModItems.FOX_TRAVELERS_BACKPACK)) {
                if(!this.abilities.field_7479 || this.method_5765()) {
                    cir.setReturnValue(this.method_5624() ? 0.025999999F + 0.013F : 0.02F + 0.013F);
                }
            }
        }
    }

    private static AtomicInteger checkBackpacksForSlowness(class_1657 player) {
        AtomicInteger atomic = new AtomicInteger(0);

        for(int i = 0; i < player.method_31548().method_67533().size(); i++) {
            if(player.method_31548().method_67533().get(i).method_7909() instanceof TravelersBackpackItem) {
                atomic.incrementAndGet();
            }
        }

        if(player.method_6079().method_7909() instanceof TravelersBackpackItem) {
            atomic.incrementAndGet();
        }

        return atomic;
    }

    //Transfer method for cardinal components data
    @Inject(method = "readAdditionalSaveData", at = @At(value = "HEAD"))
    private void fromTag(class_11368 view, CallbackInfo ci) {
        Optional<class_11368> cca = view.method_71420("cardinal_components");
        cca.ifPresent(nested -> {
            Optional<class_11368> backpack = nested.method_71420("travelersbackpack:travelersbackpack");
            backpack.ifPresent(nestedBackpack -> {
                class_1799 stack = nestedBackpack.method_71426("Wearable", class_1799.field_49266).orElseGet(() -> new class_1799(class_1802.field_8162, 0));
                this.setAttached(ModAttachmentTypes.TRAVELERS_BACKPACK, new TravelersBackpackAttachment(stack));
            });
        });
    }
}