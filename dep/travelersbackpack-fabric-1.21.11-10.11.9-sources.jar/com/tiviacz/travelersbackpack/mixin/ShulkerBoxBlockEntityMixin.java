package com.tiviacz.travelersbackpack.mixin;

import com.tiviacz.travelersbackpack.item.TravelersBackpackItem;
import net.minecraft.class_1799;
import net.minecraft.class_2350;
import net.minecraft.class_2627;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_2627.class)
public abstract class ShulkerBoxBlockEntityMixin {
    @Inject(at = @At(value = "HEAD"), method = "canPlaceItemThroughFace", cancellable = true)
    public void canInsert(int slot, class_1799 stack, class_2350 dir, CallbackInfoReturnable<Boolean> cir) {
        if(stack.method_7909() instanceof TravelersBackpackItem) {
            cir.setReturnValue(false);
        }
    }
}