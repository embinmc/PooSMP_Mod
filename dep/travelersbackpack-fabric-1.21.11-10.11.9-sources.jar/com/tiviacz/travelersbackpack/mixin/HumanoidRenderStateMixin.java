package com.tiviacz.travelersbackpack.mixin;

import com.tiviacz.travelersbackpack.util.HumanoidRenderStateBackpackInject;
import net.minecraft.class_10034;
import net.minecraft.class_1799;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

@Mixin(class_10034.class)
public class HumanoidRenderStateMixin implements HumanoidRenderStateBackpackInject {
    @Shadow
    public class_1799 chestEquipment;
    public class_1799 backpack;
    @Nullable
    public String name;

    @Override
    public void setBackpackStack(class_1799 stack) {
        this.backpack = stack;
    }

    @Override
    public class_1799 getBackpackStack() {
        return this.backpack;
    }

    @Override
    public void setChestItem(class_1799 stack) {
        chestEquipment = stack;
    }

    @Override
    public void setName(@Nullable String name) {
        this.name = name;
    }

    @Override
    @Nullable
    public String getName() {
        return this.name;
    }
}
