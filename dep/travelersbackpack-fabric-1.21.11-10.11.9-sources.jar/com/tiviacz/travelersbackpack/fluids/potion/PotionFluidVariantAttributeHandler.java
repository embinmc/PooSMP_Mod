package com.tiviacz.travelersbackpack.fluids.potion;

import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariantAttributeHandler;
import net.minecraft.class_1844;
import net.minecraft.class_2561;
import net.minecraft.class_9334;

public class PotionFluidVariantAttributeHandler implements FluidVariantAttributeHandler {
    @Override
    public class_2561 getName(FluidVariant fluidVariant) {
        return class_2561.method_43471(getTranslationKey(fluidVariant));
    }

    public String getTranslationKey(FluidVariant fluidVariant) {
        if(fluidVariant.hasComponents() && fluidVariant.getComponents().method_57846().stream().anyMatch(entry -> entry.getKey().equals(class_9334.field_49651))) {
            class_1844 contents = fluidVariant.getComponents().method_57845(class_9334.field_49651).get();
            String s = contents.comp_3209().or(() -> contents.comp_2378().map(p_372776_ -> p_372776_.comp_349().method_63990())).orElse("empty");
            return "item.minecraft.potion.effect." + s;
        }
        return "item.minecraft.potion.effect.empty";
        /*if(fluidVariant.hasComponents() && fluidVariant.getComponents().entrySet().stream().anyMatch(entry -> entry.getKey().equals(DataComponents.POTION_CONTENTS))) {
            return Potion.getName(fluidVariant.getComponents().get(DataComponents.POTION_CONTENTS).get().potion(), "item.minecraft.potion.effect.");
        }
        return Potion.getName(PotionContents.EMPTY.potion(), "item.minecraft.potion.effect."); */
    }
}