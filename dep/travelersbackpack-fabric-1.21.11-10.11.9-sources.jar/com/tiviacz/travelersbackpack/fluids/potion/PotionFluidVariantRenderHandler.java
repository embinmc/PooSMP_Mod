package com.tiviacz.travelersbackpack.fluids.potion;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.transfer.v1.client.fluid.FluidVariantRenderHandler;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_9334;
import org.jetbrains.annotations.Nullable;

@Environment(EnvType.CLIENT)
public class PotionFluidVariantRenderHandler implements FluidVariantRenderHandler {
    private static final int EMPTY_COLOR = 0xf800f8;

    @Override
    public int getColor(FluidVariant fluidVariant, @Nullable class_1920 view, @Nullable class_2338 pos) {
        if(fluidVariant.hasComponents() && fluidVariant.getComponents().method_57846().stream().anyMatch(entry -> entry.getKey().equals(class_9334.field_49651))) {
            return fluidVariant.getComponents().method_57845(class_9334.field_49651).get().method_8064();
        }
        return EMPTY_COLOR | 0xFF000000;
        //return getColor(fluidVariant.getNbt()) | 0xFF000000;
    }
}