package com.tiviacz.travelersbackpack.fluids.effects;

import com.tiviacz.travelersbackpack.api.fluids.EffectFluid;
import com.tiviacz.travelersbackpack.inventory.FluidVariantWrapper;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;

public class MilkEffect extends EffectFluid {
    public MilkEffect() {
        super("minecraft:milk", "minecraft", "milk", FluidConstants.BUCKET);
    }

    @Override
    public void affectDrinker(FluidVariantWrapper fluidStack, class_1937 level, class_1297 entity) {
        if(entity instanceof class_1657 player) {
            player.method_6012();
            //player.removeEffectsCuredBy(EffectCures.MILK);
        }
    }

    @Override
    public boolean canExecuteEffect(FluidVariantWrapper stack, class_1937 level, class_1297 entity) {
        return stack.getAmount() >= amountRequired;
    }
}