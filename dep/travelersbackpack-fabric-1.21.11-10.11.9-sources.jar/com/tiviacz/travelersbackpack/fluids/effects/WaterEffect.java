package com.tiviacz.travelersbackpack.fluids.effects;

import com.tiviacz.travelersbackpack.api.fluids.EffectFluid;
import com.tiviacz.travelersbackpack.inventory.FluidVariantWrapper;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_1959;
import net.minecraft.class_3612;
import net.minecraft.class_6880;

public class WaterEffect extends EffectFluid {
    public WaterEffect() {
        super("minecraft:water", class_3612.field_15910, FluidConstants.BUCKET);
    }

    @Override
    public void affectDrinker(FluidVariantWrapper fluidStack, class_1937 level, class_1297 entity) {
        if(entity instanceof class_1657 player) {
            class_6880<class_1959> biome = level.method_23753(player.method_24515());
            int duration = 7 * 20;
            if(player.method_5809()) {
                player.method_5646();
            } else {
                if(biome.comp_349().method_8712() >= 2.0F) {
                    player.method_6092(new class_1293(class_1294.field_5924, duration, 0));
                }
            }

            /*if(biome.value().getBaseTemperature() >= 2.0F) {
                if(player.isOnFire()) {
                    player.clearFire();
                } else {
                    player.addEffect(new MobEffectInstance(MobEffects.REGENERATION, duration, 0));
                }
            }*/
        }
    }

    @Override
    public boolean canExecuteEffect(FluidVariantWrapper stack, class_1937 level, class_1297 entity) {
        return stack.getAmount() >= amountRequired;
    }
}