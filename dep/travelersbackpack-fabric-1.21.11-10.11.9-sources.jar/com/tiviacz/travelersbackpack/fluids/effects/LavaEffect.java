package com.tiviacz.travelersbackpack.fluids.effects;

import com.tiviacz.travelersbackpack.api.fluids.EffectFluid;
import com.tiviacz.travelersbackpack.inventory.FluidVariantWrapper;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_3612;

public class LavaEffect extends EffectFluid {
    public LavaEffect() {
        super("minecraft:lava", class_3612.field_15908, FluidConstants.BUCKET);
    }

    @Override
    public void affectDrinker(FluidVariantWrapper fluidStack, class_1937 level, class_1297 entity) {
        if(entity instanceof class_1657 player) {
            int duration = 15;

            player.method_20803(duration * 20);
            player.method_6092(new class_1293(class_1294.field_5904, duration * 20 * 4, 2));
            player.method_6092(new class_1293(class_1294.field_5913, duration * 20 * 4, 0));
            player.method_6092(new class_1293(class_1294.field_5901, duration * 20 * 4, 3));
        }
    }

    @Override
    public boolean canExecuteEffect(FluidVariantWrapper stack, class_1937 level, class_1297 entity) {
        return stack.getAmount() >= amountRequired;
    }
}