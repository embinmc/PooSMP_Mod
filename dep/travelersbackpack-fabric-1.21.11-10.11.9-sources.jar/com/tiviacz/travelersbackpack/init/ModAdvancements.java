package com.tiviacz.travelersbackpack.init;

import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.tiviacz.travelersbackpack.advancements.ActionTypeTrigger;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModAdvancements {
    public static ActionTypeTrigger ACTION_TRIGGER;

    public static void init() {
        ACTION_TRIGGER = class_2378.method_10230(class_7923.field_47496, class_2960.method_60655(TravelersBackpack.MODID, "action_type"), new ActionTypeTrigger());
    }
}