package com.tiviacz.travelersbackpack.init;

import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.tiviacz.travelersbackpack.entity.BackpackItemEntity;
import com.tiviacz.travelersbackpack.item.BackpackTankItem;
import com.tiviacz.travelersbackpack.item.HoseItem;
import com.tiviacz.travelersbackpack.item.SleepingBagItem;
import com.tiviacz.travelersbackpack.item.TravelersBackpackItem;
import com.tiviacz.travelersbackpack.item.upgrades.*;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

import static com.tiviacz.travelersbackpack.init.ModBlocks.SKELETON_TRAVELERS_BACKPACK;

public class ModItems {
    //Backpacks
    public static TravelersBackpackItem STANDARD_TRAVELERS_BACKPACK;

    public static TravelersBackpackItem NETHERITE_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem DIAMOND_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem GOLD_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem EMERALD_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem IRON_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem LAPIS_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem REDSTONE_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem COAL_TRAVELERS_BACKPACK;

    public static TravelersBackpackItem QUARTZ_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem BOOKSHELF_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem END_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem NETHER_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem SANDSTONE_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem SNOW_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem SPONGE_TRAVELERS_BACKPACK;

    public static TravelersBackpackItem CAKE_TRAVELERS_BACKPACK;

    public static TravelersBackpackItem CACTUS_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem HAY_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem MELON_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem PUMPKIN_TRAVELERS_BACKPACK;

    public static TravelersBackpackItem CREEPER_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem DRAGON_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem ENDERMAN_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem BLAZE_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem GHAST_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem MAGMA_CUBE_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem SKELETON_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem SPIDER_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem WITHER_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem WARDEN_TRAVELERS_BACKPACK;

    public static TravelersBackpackItem BAT_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem BEE_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem WOLF_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem FOX_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem OCELOT_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem HORSE_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem COW_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem PIG_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem SHEEP_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem CHICKEN_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem SQUID_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem VILLAGER_TRAVELERS_BACKPACK;
    public static TravelersBackpackItem IRON_GOLEM_TRAVELERS_BACKPACK;

    //Other
    public static class_1792 WHITE_SLEEPING_BAG;
    public static class_1792 ORANGE_SLEEPING_BAG;
    public static class_1792 MAGENTA_SLEEPING_BAG;
    public static class_1792 LIGHT_BLUE_SLEEPING_BAG;
    public static class_1792 YELLOW_SLEEPING_BAG;
    public static class_1792 LIME_SLEEPING_BAG;
    public static class_1792 PINK_SLEEPING_BAG;
    public static class_1792 GRAY_SLEEPING_BAG;
    public static class_1792 LIGHT_GRAY_SLEEPING_BAG;
    public static class_1792 CYAN_SLEEPING_BAG;
    public static class_1792 PURPLE_SLEEPING_BAG;
    public static class_1792 BLUE_SLEEPING_BAG;
    public static class_1792 BROWN_SLEEPING_BAG;
    public static class_1792 GREEN_SLEEPING_BAG;
    public static class_1792 RED_SLEEPING_BAG;
    public static class_1792 BLACK_SLEEPING_BAG;
    public static class_1792 BACKPACK_TANK;
    public static class_1792 HOSE;
    public static class_1792 HOSE_NOZZLE;
    public static class_1792 BLANK_UPGRADE;
    public static class_1792 IRON_TIER_UPGRADE;
    public static class_1792 GOLD_TIER_UPGRADE;
    public static class_1792 DIAMOND_TIER_UPGRADE;
    public static class_1792 NETHERITE_TIER_UPGRADE;
    public static class_1792 TANKS_UPGRADE;
    public static class_1792 CRAFTING_UPGRADE;
    public static class_1792 FURNACE_UPGRADE;
    public static class_1792 SMOKER_UPGRADE;
    public static class_1792 BLAST_FURNACE_UPGRADE;
    public static class_1792 PICKUP_UPGRADE;
    public static class_1792 MAGNET_UPGRADE;
    public static class_1792 JUKEBOX_UPGRADE;
    public static class_1792 VOID_UPGRADE;
    public static class_1792 FEEDING_UPGRADE;
    public static class_1792 REFILL_UPGRADE;

    //Backpack Item Entity
    public static class_1299<BackpackItemEntity> BACKPACK_ITEM_ENTITY;

    public static void init() {
        STANDARD_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "standard"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("standard")), ModBlocks.STANDARD_TRAVELERS_BACKPACK));

        NETHERITE_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "netherite"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("netherite")), ModBlocks.NETHERITE_TRAVELERS_BACKPACK));
        DIAMOND_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "diamond"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("diamond")), ModBlocks.DIAMOND_TRAVELERS_BACKPACK));
        GOLD_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "gold"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("gold")), ModBlocks.GOLD_TRAVELERS_BACKPACK));
        EMERALD_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "emerald"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("emerald")), ModBlocks.EMERALD_TRAVELERS_BACKPACK));
        IRON_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "iron"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("iron")), ModBlocks.IRON_TRAVELERS_BACKPACK));
        LAPIS_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "lapis"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("lapis")), ModBlocks.LAPIS_TRAVELERS_BACKPACK));
        REDSTONE_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "redstone"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("redstone")), ModBlocks.REDSTONE_TRAVELERS_BACKPACK));
        COAL_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "coal"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("coal")), ModBlocks.COAL_TRAVELERS_BACKPACK));

        QUARTZ_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "quartz"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("quartz")), ModBlocks.QUARTZ_TRAVELERS_BACKPACK));
        BOOKSHELF_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "bookshelf"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("bookshelf")), ModBlocks.BOOKSHELF_TRAVELERS_BACKPACK));
        END_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "end"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("end")), ModBlocks.END_TRAVELERS_BACKPACK));
        NETHER_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "nether"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("nether")), ModBlocks.NETHER_TRAVELERS_BACKPACK));
        SANDSTONE_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "sandstone"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("sandstone")), ModBlocks.SANDSTONE_TRAVELERS_BACKPACK));
        SNOW_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "snow"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("snow")), ModBlocks.SNOW_TRAVELERS_BACKPACK));
        SPONGE_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "sponge"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("sponge")), ModBlocks.SPONGE_TRAVELERS_BACKPACK));

        CAKE_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "cake"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("cake")), ModBlocks.CAKE_TRAVELERS_BACKPACK));

        CACTUS_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "cactus"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("cactus")), ModBlocks.CACTUS_TRAVELERS_BACKPACK));
        HAY_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "hay"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("hay")), ModBlocks.HAY_TRAVELERS_BACKPACK));
        MELON_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "melon"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("melon")), ModBlocks.MELON_TRAVELERS_BACKPACK));
        PUMPKIN_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "pumpkin"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("pumpkin")), ModBlocks.PUMPKIN_TRAVELERS_BACKPACK));

        CREEPER_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "creeper"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("creeper")), ModBlocks.CREEPER_TRAVELERS_BACKPACK));
        DRAGON_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "dragon"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("dragon")), ModBlocks.DRAGON_TRAVELERS_BACKPACK));
        ENDERMAN_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "enderman"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("enderman")), ModBlocks.ENDERMAN_TRAVELERS_BACKPACK));
        BLAZE_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "blaze"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("blaze")), ModBlocks.BLAZE_TRAVELERS_BACKPACK));
        GHAST_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "ghast"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("ghast")), ModBlocks.GHAST_TRAVELERS_BACKPACK));
        MAGMA_CUBE_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "magma_cube"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("magma_cube")), ModBlocks.MAGMA_CUBE_TRAVELERS_BACKPACK));
        SKELETON_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "skeleton"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("skeleton")), ModBlocks.SKELETON_TRAVELERS_BACKPACK));
        SPIDER_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "spider"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("spider")), ModBlocks.SPIDER_TRAVELERS_BACKPACK));
        WITHER_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "wither"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("wither")), ModBlocks.WITHER_TRAVELERS_BACKPACK));
        WARDEN_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "warden"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("warden")), ModBlocks.WARDEN_TRAVELERS_BACKPACK));

        BAT_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "bat"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("bat")), ModBlocks.BAT_TRAVELERS_BACKPACK));
        BEE_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "bee"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("bee")), ModBlocks.BEE_TRAVELERS_BACKPACK));
        WOLF_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "wolf"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("wolf")), ModBlocks.WOLF_TRAVELERS_BACKPACK));
        FOX_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "fox"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("fox")), ModBlocks.FOX_TRAVELERS_BACKPACK));
        OCELOT_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "ocelot"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("ocelot")), ModBlocks.OCELOT_TRAVELERS_BACKPACK));
        HORSE_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "horse"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("horse")), ModBlocks.HORSE_TRAVELERS_BACKPACK));
        COW_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "cow"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("cow")), ModBlocks.COW_TRAVELERS_BACKPACK));
        PIG_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "pig"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("pig")), ModBlocks.PIG_TRAVELERS_BACKPACK));
        SHEEP_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "sheep"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("sheep")), ModBlocks.SHEEP_TRAVELERS_BACKPACK));
        CHICKEN_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "chicken"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("chicken")), ModBlocks.CHICKEN_TRAVELERS_BACKPACK));
        SQUID_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "squid"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("squid")), ModBlocks.SQUID_TRAVELERS_BACKPACK));
        VILLAGER_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "villager"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("villager")), ModBlocks.VILLAGER_TRAVELERS_BACKPACK));
        IRON_GOLEM_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "iron_golem"), new TravelersBackpackItem(new class_1792.class_1793().method_63686(resourceKey("iron_golem")), ModBlocks.IRON_GOLEM_TRAVELERS_BACKPACK));

        WHITE_SLEEPING_BAG = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "white_sleeping_bag"), new SleepingBagItem(ModBlocks.WHITE_SLEEPING_BAG, new class_1792.class_1793().method_63686(resourceKey("white_sleeping_bag"))));
        ORANGE_SLEEPING_BAG = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "orange_sleeping_bag"), new SleepingBagItem(ModBlocks.ORANGE_SLEEPING_BAG, new class_1792.class_1793().method_63686(resourceKey("orange_sleeping_bag"))));
        MAGENTA_SLEEPING_BAG = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "magenta_sleeping_bag"), new SleepingBagItem(ModBlocks.MAGENTA_SLEEPING_BAG, new class_1792.class_1793().method_63686(resourceKey("magenta_sleeping_bag"))));
        LIGHT_BLUE_SLEEPING_BAG = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "light_blue_sleeping_bag"), new SleepingBagItem(ModBlocks.LIGHT_BLUE_SLEEPING_BAG, new class_1792.class_1793().method_63686(resourceKey("light_blue_sleeping_bag"))));
        YELLOW_SLEEPING_BAG = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "yellow_sleeping_bag"), new SleepingBagItem(ModBlocks.YELLOW_SLEEPING_BAG, new class_1792.class_1793().method_63686(resourceKey("yellow_sleeping_bag"))));
        LIME_SLEEPING_BAG = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "lime_sleeping_bag"), new SleepingBagItem(ModBlocks.LIME_SLEEPING_BAG, new class_1792.class_1793().method_63686(resourceKey("lime_sleeping_bag"))));
        PINK_SLEEPING_BAG = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "pink_sleeping_bag"), new SleepingBagItem(ModBlocks.PINK_SLEEPING_BAG, new class_1792.class_1793().method_63686(resourceKey("pink_sleeping_bag"))));
        GRAY_SLEEPING_BAG = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "gray_sleeping_bag"), new SleepingBagItem(ModBlocks.GRAY_SLEEPING_BAG, new class_1792.class_1793().method_63686(resourceKey("gray_sleeping_bag"))));
        LIGHT_GRAY_SLEEPING_BAG = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "light_gray_sleeping_bag"), new SleepingBagItem(ModBlocks.LIGHT_GRAY_SLEEPING_BAG, new class_1792.class_1793().method_63686(resourceKey("light_gray_sleeping_bag"))));
        CYAN_SLEEPING_BAG = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "cyan_sleeping_bag"), new SleepingBagItem(ModBlocks.CYAN_SLEEPING_BAG, new class_1792.class_1793().method_63686(resourceKey("cyan_sleeping_bag"))));
        PURPLE_SLEEPING_BAG = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "purple_sleeping_bag"), new SleepingBagItem(ModBlocks.PURPLE_SLEEPING_BAG, new class_1792.class_1793().method_63686(resourceKey("purple_sleeping_bag"))));
        BLUE_SLEEPING_BAG = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "blue_sleeping_bag"), new SleepingBagItem(ModBlocks.BLUE_SLEEPING_BAG, new class_1792.class_1793().method_63686(resourceKey("blue_sleeping_bag"))));
        BROWN_SLEEPING_BAG = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "brown_sleeping_bag"), new SleepingBagItem(ModBlocks.BROWN_SLEEPING_BAG, new class_1792.class_1793().method_63686(resourceKey("brown_sleeping_bag"))));
        GREEN_SLEEPING_BAG = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "green_sleeping_bag"), new SleepingBagItem(ModBlocks.GREEN_SLEEPING_BAG, new class_1792.class_1793().method_63686(resourceKey("green_sleeping_bag"))));
        RED_SLEEPING_BAG = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "red_sleeping_bag"), new SleepingBagItem(ModBlocks.RED_SLEEPING_BAG, new class_1792.class_1793().method_63686(resourceKey("red_sleeping_bag"))));
        BLACK_SLEEPING_BAG = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "black_sleeping_bag"), new SleepingBagItem(ModBlocks.BLACK_SLEEPING_BAG, new class_1792.class_1793().method_63686(resourceKey("black_sleeping_bag"))));
        BACKPACK_TANK = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "backpack_tank"), new BackpackTankItem(new class_1792.class_1793().method_7889(16).method_63686(resourceKey("backpack_tank"))));
        HOSE = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "hose"), new HoseItem(new class_1792.class_1793().method_7889(1).method_63686(resourceKey("hose"))));
        HOSE_NOZZLE = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "hose_nozzle"), new class_1792(new class_1792.class_1793().method_63686(resourceKey("hose_nozzle"))));
        BLANK_UPGRADE = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "blank_upgrade"), new TierUpgrade(new class_1792.class_1793().method_63686(resourceKey("blank_upgrade")), TierUpgrade.Upgrade.BLANK_UPGRADE));
        IRON_TIER_UPGRADE = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "iron_tier_upgrade"), new TierUpgrade(new class_1792.class_1793().method_7889(16).method_63686(resourceKey("iron_tier_upgrade")), TierUpgrade.Upgrade.IRON_TIER_UPGRADE));
        GOLD_TIER_UPGRADE = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "gold_tier_upgrade"), new TierUpgrade(new class_1792.class_1793().method_7889(16).method_63686(resourceKey("gold_tier_upgrade")), TierUpgrade.Upgrade.GOLD_TIER_UPGRADE));
        DIAMOND_TIER_UPGRADE = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "diamond_tier_upgrade"), new TierUpgrade(new class_1792.class_1793().method_7889(16).method_63686(resourceKey("diamond_tier_upgrade")), TierUpgrade.Upgrade.DIAMOND_TIER_UPGRADE));
        NETHERITE_TIER_UPGRADE = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "netherite_tier_upgrade"), new TierUpgrade(new class_1792.class_1793().method_7889(16).method_63686(resourceKey("netherite_tier_upgrade")), TierUpgrade.Upgrade.NETHERITE_TIER_UPGRADE));
        TANKS_UPGRADE = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "tanks_upgrade"), new TanksUpgradeItem(new class_1792.class_1793().method_7889(16).method_63686(resourceKey("tanks_upgrade"))));
        CRAFTING_UPGRADE = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "crafting_upgrade"), new CraftingUpgradeItem(new class_1792.class_1793().method_7889(16).method_63686(resourceKey("crafting_upgrade"))));
        FURNACE_UPGRADE = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "furnace_upgrade"), new FurnaceUpgradeItem(new class_1792.class_1793().method_7889(16).method_63686(resourceKey("furnace_upgrade"))));
        SMOKER_UPGRADE = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "smoker_upgrade"), new SmokerUpgradeItem(new class_1792.class_1793().method_7889(16).method_63686(resourceKey("smoker_upgrade"))));
        BLAST_FURNACE_UPGRADE = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "blast_furnace_upgrade"), new BlastFurnaceUpgradeItem(new class_1792.class_1793().method_7889(16).method_63686(resourceKey("blast_furnace_upgrade"))));
        PICKUP_UPGRADE = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "pickup_upgrade"), new PickupUpgradeItem(new class_1792.class_1793().method_7889(16).method_63686(resourceKey("pickup_upgrade"))));
        MAGNET_UPGRADE = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "magnet_upgrade"), new MagnetUpgradeItem(new class_1792.class_1793().method_7889(16).method_63686(resourceKey("magnet_upgrade"))));
        JUKEBOX_UPGRADE = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "jukebox_upgrade"), new JukeboxUpgradeItem(new class_1792.class_1793().method_7889(16).method_63686(resourceKey("jukebox_upgrade"))));
        VOID_UPGRADE = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "void_upgrade"), new VoidUpgradeItem(new class_1792.class_1793().method_7889(16).method_63686(resourceKey("void_upgrade"))));
        FEEDING_UPGRADE = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "feeding_upgrade"), new FeedingUpgradeItem(new class_1792.class_1793().method_7889(16).method_63686(resourceKey("feeding_upgrade"))));
        REFILL_UPGRADE = class_2378.method_10230(class_7923.field_41178, class_2960.method_60655(TravelersBackpack.MODID, "refill_upgrade"), new RefillUpgradeItem(new class_1792.class_1793().method_7889(16).method_63686(resourceKey("refill_upgrade"))));

        BACKPACK_ITEM_ENTITY = class_2378.method_10230(class_7923.field_41177, class_2960.method_60655(TravelersBackpack.MODID, "backpack"), class_1299.class_1300.method_5903(BackpackItemEntity::new, class_1311.field_17715).method_17687(0.25F, 0.25F).method_27299(6).method_27300(20).method_5905(class_5321.method_29179(class_7924.field_41266, class_2960.method_60655(TravelersBackpack.MODID, "backpack"))));
    }

    public static class_2960 resourceLocation(String name) {
        return class_2960.method_60655(TravelersBackpack.MODID, name);
    }

    public static class_5321<class_1792> resourceKey(String name) {
        return class_5321.method_29179(class_7924.field_41197, resourceLocation(name));
    }

    public static final List<class_1792> COMPATIBLE_OVERWORLD_BACKPACK_ENTRIES = new ArrayList<>();
    public static final List<class_1792> COMPATIBLE_NETHER_BACKPACK_ENTRIES = new ArrayList<>();
}