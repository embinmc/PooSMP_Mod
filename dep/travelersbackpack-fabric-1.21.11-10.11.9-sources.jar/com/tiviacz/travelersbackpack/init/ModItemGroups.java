package com.tiviacz.travelersbackpack.init;

import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.tiviacz.travelersbackpack.components.RenderInfo;
import com.tiviacz.travelersbackpack.inventory.Tiers;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.class_1761;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9288;
import java.util.List;

public class ModItemGroups {
    public static final class_5321<class_1761> TRAVELERS_BACKPACK = class_5321.method_29179(class_7924.field_44688, class_2960.method_60655(TravelersBackpack.MODID, "travelers_backpack"));

    public static void registerItemGroup() {
        class_2378.method_39197(class_7923.field_44687, TRAVELERS_BACKPACK, FabricItemGroup.builder()
                .method_47320(ModItemGroups::createTabStack)
                .method_47321(class_2561.method_43471("itemGroup.travelersbackpack")).method_47324());
    }

    public static class_1799 createTabStack() {
        class_1799 stack = new class_1799(ModItems.STANDARD_TRAVELERS_BACKPACK);
        stack.method_57379(ModDataComponents.RENDER_INFO, RenderInfo.createCreativeTabInfo());
        return stack;
    }

    public static void addItemGroup() {
        ItemGroupEvents.modifyEntriesEvent(TRAVELERS_BACKPACK).register(output ->
        {
            output.method_45421(ModItems.BACKPACK_TANK);
            output.method_45421(ModItems.HOSE_NOZZLE);
            output.method_45421(ModItems.HOSE);

            //Tiers
            output.method_45421(ModItems.BLANK_UPGRADE);
            output.method_45421(ModItems.IRON_TIER_UPGRADE);
            output.method_45421(ModItems.GOLD_TIER_UPGRADE);
            output.method_45421(ModItems.DIAMOND_TIER_UPGRADE);
            output.method_45421(ModItems.NETHERITE_TIER_UPGRADE);
            output.method_45421(ModItems.TANKS_UPGRADE);
            output.method_45421(ModItems.CRAFTING_UPGRADE);
            output.method_45421(ModItems.FURNACE_UPGRADE);
            output.method_45421(ModItems.SMOKER_UPGRADE);
            output.method_45421(ModItems.BLAST_FURNACE_UPGRADE);
            output.method_45421(ModItems.FEEDING_UPGRADE);
            output.method_45421(ModItems.REFILL_UPGRADE);
            output.method_45421(ModItems.PICKUP_UPGRADE);
            output.method_45421(ModItems.MAGNET_UPGRADE);
            output.method_45421(ModItems.VOID_UPGRADE);
            output.method_45421(ModItems.JUKEBOX_UPGRADE);

            //Standard
            output.method_45420(withTanks(ModBlocks.STANDARD_TRAVELERS_BACKPACK));
            output.method_45420(createTieredBackpack(Tiers.IRON));
            output.method_45420(createTieredBackpack(Tiers.GOLD));
            output.method_45420(createTieredBackpack(Tiers.DIAMOND));
            output.method_45420(createTieredBackpack(Tiers.NETHERITE));

            //Blocks
            output.method_45420(withTanks(ModBlocks.NETHERITE_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.DIAMOND_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.GOLD_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.EMERALD_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.IRON_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.LAPIS_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.REDSTONE_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.COAL_TRAVELERS_BACKPACK));

            output.method_45420(withTanks(ModBlocks.QUARTZ_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.BOOKSHELF_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.END_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.NETHER_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.SANDSTONE_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.SNOW_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.SPONGE_TRAVELERS_BACKPACK));

            output.method_45420(withTanks(ModBlocks.CAKE_TRAVELERS_BACKPACK));

            output.method_45420(withTanks(ModBlocks.CACTUS_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.HAY_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.MELON_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.PUMPKIN_TRAVELERS_BACKPACK));

            output.method_45420(withTanks(ModBlocks.CREEPER_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.DRAGON_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.ENDERMAN_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.BLAZE_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.GHAST_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.MAGMA_CUBE_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.SKELETON_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.SPIDER_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.WITHER_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.WARDEN_TRAVELERS_BACKPACK));

            //Friendly Mobs
            output.method_45420(withTanks(ModBlocks.BAT_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.BEE_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.WOLF_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.FOX_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.OCELOT_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.HORSE_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.COW_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.PIG_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.SHEEP_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.CHICKEN_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.SQUID_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.VILLAGER_TRAVELERS_BACKPACK));
            output.method_45420(withTanks(ModBlocks.IRON_GOLEM_TRAVELERS_BACKPACK));

            output.method_45421(ModItems.WHITE_SLEEPING_BAG);
            output.method_45421(ModItems.ORANGE_SLEEPING_BAG);
            output.method_45421(ModItems.MAGENTA_SLEEPING_BAG);
            output.method_45421(ModItems.LIGHT_BLUE_SLEEPING_BAG);
            output.method_45421(ModItems.YELLOW_SLEEPING_BAG);
            output.method_45421(ModItems.LIME_SLEEPING_BAG);
            output.method_45421(ModItems.PINK_SLEEPING_BAG);
            output.method_45421(ModItems.GRAY_SLEEPING_BAG);
            output.method_45421(ModItems.LIGHT_GRAY_SLEEPING_BAG);
            output.method_45421(ModItems.CYAN_SLEEPING_BAG);
            output.method_45421(ModItems.PURPLE_SLEEPING_BAG);
            output.method_45421(ModItems.BLUE_SLEEPING_BAG);
            output.method_45421(ModItems.BROWN_SLEEPING_BAG);
            output.method_45421(ModItems.GREEN_SLEEPING_BAG);
            output.method_45421(ModItems.RED_SLEEPING_BAG);
            output.method_45421(ModItems.BLACK_SLEEPING_BAG);
        });
    }

    public static class_1799 createTieredBackpack(Tiers.Tier tier) {
        class_1799 stack = new class_1799(ModItems.STANDARD_TRAVELERS_BACKPACK);
        stack.method_57379(ModDataComponents.TIER, tier.getOrdinal());
        stack.method_57379(ModDataComponents.STARTER_UPGRADES, class_9288.method_57493(List.of(ModItems.TANKS_UPGRADE.method_7854())));
        return stack;
    }

    public static class_1799 withTanks(class_2248 block) {
        class_1799 stack = new class_1799(block);
        stack.method_57379(ModDataComponents.STARTER_UPGRADES, class_9288.method_57493(List.of(ModItems.TANKS_UPGRADE.method_7854())));
        return stack;
    }
}
