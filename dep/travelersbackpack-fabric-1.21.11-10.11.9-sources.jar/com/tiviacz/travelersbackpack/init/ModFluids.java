package com.tiviacz.travelersbackpack.init;

import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.tiviacz.travelersbackpack.fluids.PotionFluid;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3609;
import net.minecraft.class_7923;

public class ModFluids {
    public static final class_3609 POTION_STILL = register("potion_still", new PotionFluid.Still());
    public static final class_3609 POTION_FLOWING = register("potion_flowing", new PotionFluid.Flowing());
    //public static final FlowingFluid MILK_STILL = register("milk_still", new MilkFluid.Still());
    //public static final FlowingFluid MILK_FLOWING = register("milk_flowing", new MilkFluid.Flowing());

    private static class_3609 register(String name, class_3609 flowableFluid) {
        return class_2378.method_10230(class_7923.field_41173, class_2960.method_60655(TravelersBackpack.MODID, name), flowableFluid);
    }
}