package com.tiviacz.travelersbackpack.init;

import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.tiviacz.travelersbackpack.attachment.TravelersBackpackAttachment;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;

public class ModAttachmentTypes {
    public static final AttachmentType<TravelersBackpackAttachment> TRAVELERS_BACKPACK = AttachmentRegistry.create(class_2960.method_60655(TravelersBackpack.MODID, "travelers_backpack"), builder -> builder
            .initializer(() -> new TravelersBackpackAttachment(new class_1799(class_1802.field_8162, 0)))
            .persistent(TravelersBackpackAttachment.CODEC).copyOnDeath());

    public static void init() {

    }
}