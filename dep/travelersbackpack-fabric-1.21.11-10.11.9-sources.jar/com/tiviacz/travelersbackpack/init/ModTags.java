package com.tiviacz.travelersbackpack.init;

import com.tiviacz.travelersbackpack.TravelersBackpack;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class ModTags {
    public static final class_6862<class_1792> BLACKLISTED_ITEMS = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655(TravelersBackpack.MODID, "blacklisted_items"));
    public static final class_6862<class_1792> ACCEPTABLE_TOOLS = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655(TravelersBackpack.MODID, "acceptable_tools"));
    public static final class_6862<class_1792> CUSTOM_TRAVELERS_BACKPACK = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655(TravelersBackpack.MODID, "custom_travelers_backpack"));
    public static final class_6862<class_1792> SLEEPING_BAGS = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655(TravelersBackpack.MODID, "sleeping_bags"));
    public static final class_6862<class_1792> BACKPACK_UPGRADES = class_6862.method_40092(class_7924.field_41197, class_2960.method_60655(TravelersBackpack.MODID, "backpack_upgrades"));
}