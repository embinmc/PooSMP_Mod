package com.tiviacz.travelersbackpack.init;

import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.tiviacz.travelersbackpack.inventory.menu.BackpackBlockEntityMenu;
import com.tiviacz.travelersbackpack.inventory.menu.BackpackItemMenu;
import com.tiviacz.travelersbackpack.inventory.menu.BackpackSettingsMenu;
import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public class ModScreenHandlerTypes {
    public static ExtendedScreenHandlerType<BackpackItemMenu, ItemScreenData> BACKPACK_MENU = new ExtendedScreenHandlerType<>(BackpackItemMenu::new, ItemScreenData.PACKET_CODEC);
    public static ExtendedScreenHandlerType<BackpackBlockEntityMenu, BlockEntityScreenData> BACKPACK_BLOCK_MENU = new ExtendedScreenHandlerType<>(BackpackBlockEntityMenu::new, BlockEntityScreenData.PACKET_CODEC);
    public static ExtendedScreenHandlerType<BackpackSettingsMenu, SettingsScreenData> BACKPACK_SETTINGS_MENU = new ExtendedScreenHandlerType<>(BackpackSettingsMenu::new, SettingsScreenData.PACKET_CODEC);

    public static void init() {
        class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(TravelersBackpack.MODID, "backpack_item"), BACKPACK_MENU);
        class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(TravelersBackpack.MODID, "backpack_block"), BACKPACK_BLOCK_MENU);
        class_2378.method_10230(class_7923.field_41187, class_2960.method_60655(TravelersBackpack.MODID, "backpack_settings"), BACKPACK_SETTINGS_MENU);
    }

    public record ItemScreenData(int screenID, int entityID) {
        public static final class_9139<class_9129, ItemScreenData> PACKET_CODEC = class_9139.method_56435(class_9135.field_49675, ItemScreenData::screenID,
                class_9135.field_49675, ItemScreenData::entityID, ItemScreenData::new);
    }

    public record BlockEntityScreenData(int entityId, class_2338 pos) {
        public static final class_9139<class_9129, BlockEntityScreenData> PACKET_CODEC = class_9139.method_56435(class_9135.field_49675, BlockEntityScreenData::entityId,
                class_2338.field_48404, BlockEntityScreenData::pos, BlockEntityScreenData::new);
    }

    public record SettingsScreenData(boolean isBlockEntity, int screenId, class_2338 pos, int index) {
        public static final class_9139<class_9129, SettingsScreenData> PACKET_CODEC = class_9139.method_56905(class_9135.field_48547, SettingsScreenData::isBlockEntity,
                class_9135.field_49675, SettingsScreenData::screenId, class_2338.field_48404, SettingsScreenData::pos, class_9135.field_49675, SettingsScreenData::index, SettingsScreenData::new);
    }
}