package com.tiviacz.travelersbackpack.init;

import com.mojang.serialization.Codec;
import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.tiviacz.travelersbackpack.components.*;
import java.util.List;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_9135;
import net.minecraft.class_9288;
import net.minecraft.class_9331;

public class ModDataComponents {
    public static final class_9331<Integer> TIER = class_9331.<Integer>method_57873().method_57881(Codec.INT).method_57882(class_9135.field_49675).method_57880();
    public static final class_9331<Integer> STORAGE_SLOTS = class_9331.<Integer>method_57873().method_57881(Codec.INT).method_57882(class_9135.field_49675).method_57880();
    public static final class_9331<Integer> UPGRADE_SLOTS = class_9331.<Integer>method_57873().method_57881(Codec.INT).method_57882(class_9135.field_49675).method_57880();
    public static final class_9331<Integer> TOOL_SLOTS = class_9331.<Integer>method_57873().method_57881(Codec.INT).method_57882(class_9135.field_49675).method_57880();
    public static final class_9331<Fluids> FLUIDS = class_9331.<Fluids>method_57873().method_57881(Fluids.CODEC).method_57882(Fluids.STREAM_CODEC).method_57880();
    public static final class_9331<Boolean> TAB_OPEN = class_9331.<Boolean>method_57873().method_57881(Codec.BOOL).method_57882(class_9135.field_48547).method_57880();
    public static final class_9331<List<Integer>> FILTER_SETTINGS = class_9331.<List<Integer>>method_57873().method_57881(Codec.INT.listOf()).method_57882(class_9135.field_49675.method_56433(class_9135.method_56363())).method_57880();
    public static final class_9331<List<String>> FILTER_TAGS = class_9331.<List<String>>method_57873().method_57881(Codec.STRING.listOf()).method_57882(class_9135.field_48554.method_56433(class_9135.method_56363())).method_57880();
    public static final class_9331<Boolean> UPGRADE_ENABLED = class_9331.<Boolean>method_57873().method_57881(Codec.BOOL).method_57882(class_9135.field_48547).method_57880();
    public static final class_9331<Boolean> SHIFT_CLICK_TO_BACKPACK = class_9331.<Boolean>method_57873().method_57881(Codec.BOOL).method_57882(class_9135.field_48547).method_57880();
    public static final class_9331<Boolean> SHOW_TOOL_SLOTS = class_9331.<Boolean>method_57873().method_57881(Codec.BOOL).method_57882(class_9135.field_48547).method_57880();
    public static final class_9331<Boolean> SHOW_MORE_BUTTONS = class_9331.<Boolean>method_57873().method_57881(Codec.BOOL).method_57882(class_9135.field_48547).method_57880();
    public static final class_9331<Boolean> IS_PLAYING = class_9331.<Boolean>method_57873().method_57881(Codec.BOOL).method_57882(class_9135.field_48547).method_57880();
    public static final class_9331<Integer> COOLDOWN = class_9331.<Integer>method_57873().method_57881(Codec.INT).method_57882(class_9135.field_49675).method_57880();
    public static final class_9331<class_9288> STARTER_UPGRADES = class_9331.<class_9288>method_57873().method_57881(class_9288.field_49335).method_57882(class_9288.field_49336).method_57880();
    public static final class_9331<RenderInfo> RENDER_INFO = class_9331.<RenderInfo>method_57873().method_57881(RenderInfo.CODEC).method_57882(RenderInfo.STREAM_CODEC).method_57880();
    public static final class_9331<BackpackContainerContents> BACKPACK_CONTAINER = class_9331.<BackpackContainerContents>method_57873().method_57881(BackpackContainerContents.CODEC).method_57882(BackpackContainerContents.STREAM_CODEC).method_57880();
    public static final class_9331<BackpackContainerContents> UPGRADES = class_9331.<BackpackContainerContents>method_57873().method_57881(BackpackContainerContents.CODEC).method_57882(BackpackContainerContents.STREAM_CODEC).method_57880();
    public static final class_9331<BackpackContainerContents> TOOLS_CONTAINER = class_9331.<BackpackContainerContents>method_57873().method_57881(BackpackContainerContents.CODEC).method_57882(BackpackContainerContents.STREAM_CODEC).method_57880();
    public static final class_9331<Integer> SLEEPING_BAG_COLOR = class_9331.<Integer>method_57873().method_57881(Codec.INT).method_57882(class_9135.field_49675).method_57880();
    public static final class_9331<Integer> SORT_TYPE = class_9331.<Integer>method_57873().method_57881(Codec.INT).method_57882(class_9135.field_49675).method_57880();
    public static final class_9331<Boolean> ABILITY_ENABLED = class_9331.<Boolean>method_57873().method_57881(Codec.BOOL).method_57882(class_9135.field_48547).method_57880();
    public static final class_9331<Boolean> IS_VISIBLE = class_9331.<Boolean>method_57873().method_57881(Codec.BOOL).method_57882(class_9135.field_48547).method_57880();
    public static final class_9331<Slots> SLOTS = class_9331.<Slots>method_57873().method_57881(Slots.CODEC).method_57882(Slots.STREAM_CODEC).method_57880();
    public static final class_9331<Integer> UPGRADE_TICK_INTERVAL = class_9331.<Integer>method_57873().method_57881(Codec.INT).method_57882(class_9135.field_49675).method_57880();
    public static final class_9331<List<Integer>> HOSE_MODES = class_9331.<List<Integer>>method_57873().method_57881(Codec.INT.listOf()).method_57882(class_9135.field_49675.method_56433(class_9135.method_56363())).method_57880();

    //Smelting
    public static final class_9331<Long> BURN_FINISH_TIME = class_9331.<Long>method_57873().method_57881(Codec.LONG).method_57882(class_9135.field_48551).method_57880();
    public static final class_9331<Long> COOKING_FINISH_TIME = class_9331.<Long>method_57873().method_57881(Codec.LONG).method_57882(class_9135.field_48551).method_57880();
    public static final class_9331<Integer> BURN_TOTAL_TIME = class_9331.<Integer>method_57873().method_57881(Codec.INT).method_57882(class_9135.field_49675).method_57880();
    public static final class_9331<Integer> COOKING_TOTAL_TIME = class_9331.<Integer>method_57873().method_57881(Codec.INT).method_57882(class_9135.field_49675).method_57880();

    public static void init() {
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(TravelersBackpack.MODID, "tier"), TIER);
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(TravelersBackpack.MODID, "storage_slots"), STORAGE_SLOTS);
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(TravelersBackpack.MODID, "upgrade_slots"), UPGRADE_SLOTS);
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(TravelersBackpack.MODID, "tool_slots"), TOOL_SLOTS);
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(TravelersBackpack.MODID, "fluids"), FLUIDS);
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(TravelersBackpack.MODID, "tab_open"), TAB_OPEN);
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(TravelersBackpack.MODID, "filter_settings"), FILTER_SETTINGS);
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(TravelersBackpack.MODID, "filter_tags"), FILTER_TAGS);
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(TravelersBackpack.MODID, "upgrade_enabled"), UPGRADE_ENABLED);
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(TravelersBackpack.MODID, "shift_click_to_backpack"), SHIFT_CLICK_TO_BACKPACK);
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(TravelersBackpack.MODID, "show_tool_slots"), SHOW_TOOL_SLOTS);
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(TravelersBackpack.MODID, "show_more_buttons"), SHOW_MORE_BUTTONS);
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(TravelersBackpack.MODID, "is_playing"), IS_PLAYING);
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(TravelersBackpack.MODID, "cooldown"), COOLDOWN);
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(TravelersBackpack.MODID, "starter_upgrades"), STARTER_UPGRADES);
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(TravelersBackpack.MODID, "render_info"), RENDER_INFO);
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(TravelersBackpack.MODID, "backpack_container"), BACKPACK_CONTAINER);
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(TravelersBackpack.MODID, "upgrades"), UPGRADES);
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(TravelersBackpack.MODID, "tools_container"), TOOLS_CONTAINER);
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(TravelersBackpack.MODID, "sleeping_bag_color"), SLEEPING_BAG_COLOR);
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(TravelersBackpack.MODID, "sort_type"), SORT_TYPE);
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(TravelersBackpack.MODID, "ability_enabled"), ABILITY_ENABLED);
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(TravelersBackpack.MODID, "is_visible"), IS_VISIBLE);
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(TravelersBackpack.MODID, "slots"), SLOTS);
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(TravelersBackpack.MODID, "upgrade_tick_interval"), UPGRADE_TICK_INTERVAL);
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(TravelersBackpack.MODID, "hose_modes"), HOSE_MODES);

        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(TravelersBackpack.MODID, "burn_finish_time"), BURN_FINISH_TIME);
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(TravelersBackpack.MODID, "cooking_finish_time"), COOKING_FINISH_TIME);
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(TravelersBackpack.MODID, "burn_total_time"), BURN_TOTAL_TIME);
        class_2378.method_10230(class_7923.field_49658, class_2960.method_60655(TravelersBackpack.MODID, "cooking_total_time"), COOKING_TOTAL_TIME);
    }
}