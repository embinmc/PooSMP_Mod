package com.tiviacz.travelersbackpack.init;

import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.tiviacz.travelersbackpack.common.recipes.BackpackUpgradeRecipe;
import com.tiviacz.travelersbackpack.common.recipes.ShapedBackpackRecipe;
import net.minecraft.class_1865;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;

public class ModRecipeSerializers {
    public static class_1865<ShapedBackpackRecipe> BACKPACK_SHAPED;
    public static class_1865<BackpackUpgradeRecipe> BACKPACK_UPGRADE;

    public static void init() {
        BACKPACK_SHAPED = class_2378.method_10230(class_7923.field_41189, class_2960.method_60655(TravelersBackpack.MODID, "backpack_shaped"), new ShapedBackpackRecipe.Serializer());
        BACKPACK_UPGRADE = class_2378.method_10230(class_7923.field_41189, class_2960.method_60655(TravelersBackpack.MODID, "backpack_upgrade"), new BackpackUpgradeRecipe.Serializer());
    }
}