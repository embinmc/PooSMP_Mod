package com.tiviacz.travelersbackpack.init;

import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.tiviacz.travelersbackpack.blocks.SleepingBagBlock;
import com.tiviacz.travelersbackpack.blocks.TravelersBackpackBlock;
import net.minecraft.class_1767;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2498;
import net.minecraft.class_2960;
import net.minecraft.class_3619;
import net.minecraft.class_3620;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

public class ModBlocks {

    //Backpacks
    public static class_2248 STANDARD_TRAVELERS_BACKPACK;

    public static class_2248 NETHERITE_TRAVELERS_BACKPACK;
    public static class_2248 DIAMOND_TRAVELERS_BACKPACK;
    public static class_2248 GOLD_TRAVELERS_BACKPACK;
    public static class_2248 EMERALD_TRAVELERS_BACKPACK;
    public static class_2248 IRON_TRAVELERS_BACKPACK;
    public static class_2248 LAPIS_TRAVELERS_BACKPACK;
    public static class_2248 REDSTONE_TRAVELERS_BACKPACK;
    public static class_2248 COAL_TRAVELERS_BACKPACK;

    public static class_2248 QUARTZ_TRAVELERS_BACKPACK;
    public static class_2248 BOOKSHELF_TRAVELERS_BACKPACK;
    public static class_2248 END_TRAVELERS_BACKPACK;
    public static class_2248 NETHER_TRAVELERS_BACKPACK;
    public static class_2248 SANDSTONE_TRAVELERS_BACKPACK;
    public static class_2248 SNOW_TRAVELERS_BACKPACK;
    public static class_2248 SPONGE_TRAVELERS_BACKPACK;

    public static class_2248 CAKE_TRAVELERS_BACKPACK;

    public static class_2248 CACTUS_TRAVELERS_BACKPACK;
    public static class_2248 HAY_TRAVELERS_BACKPACK;
    public static class_2248 MELON_TRAVELERS_BACKPACK;
    public static class_2248 PUMPKIN_TRAVELERS_BACKPACK;

    public static class_2248 CREEPER_TRAVELERS_BACKPACK;
    public static class_2248 DRAGON_TRAVELERS_BACKPACK;
    public static class_2248 ENDERMAN_TRAVELERS_BACKPACK;
    public static class_2248 BLAZE_TRAVELERS_BACKPACK;
    public static class_2248 GHAST_TRAVELERS_BACKPACK;
    public static class_2248 MAGMA_CUBE_TRAVELERS_BACKPACK;
    public static class_2248 SKELETON_TRAVELERS_BACKPACK;
    public static class_2248 SPIDER_TRAVELERS_BACKPACK;
    public static class_2248 WITHER_TRAVELERS_BACKPACK;
    public static class_2248 WARDEN_TRAVELERS_BACKPACK;

    public static class_2248 BAT_TRAVELERS_BACKPACK;
    public static class_2248 BEE_TRAVELERS_BACKPACK;
    public static class_2248 WOLF_TRAVELERS_BACKPACK;
    public static class_2248 FOX_TRAVELERS_BACKPACK;
    public static class_2248 OCELOT_TRAVELERS_BACKPACK;
    public static class_2248 HORSE_TRAVELERS_BACKPACK;
    public static class_2248 COW_TRAVELERS_BACKPACK;
    public static class_2248 PIG_TRAVELERS_BACKPACK;
    public static class_2248 SHEEP_TRAVELERS_BACKPACK;
    public static class_2248 CHICKEN_TRAVELERS_BACKPACK;
    public static class_2248 SQUID_TRAVELERS_BACKPACK;
    public static class_2248 VILLAGER_TRAVELERS_BACKPACK;
    public static class_2248 IRON_GOLEM_TRAVELERS_BACKPACK;

    public static class_2248 WHITE_SLEEPING_BAG;
    public static class_2248 ORANGE_SLEEPING_BAG;
    public static class_2248 MAGENTA_SLEEPING_BAG;
    public static class_2248 LIGHT_BLUE_SLEEPING_BAG;
    public static class_2248 YELLOW_SLEEPING_BAG;
    public static class_2248 LIME_SLEEPING_BAG;
    public static class_2248 PINK_SLEEPING_BAG;
    public static class_2248 GRAY_SLEEPING_BAG;
    public static class_2248 LIGHT_GRAY_SLEEPING_BAG;
    public static class_2248 CYAN_SLEEPING_BAG;
    public static class_2248 PURPLE_SLEEPING_BAG;
    public static class_2248 BLUE_SLEEPING_BAG;
    public static class_2248 BROWN_SLEEPING_BAG;
    public static class_2248 GREEN_SLEEPING_BAG;
    public static class_2248 RED_SLEEPING_BAG;
    public static class_2248 BLACK_SLEEPING_BAG;

    public static void init() {
        STANDARD_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "standard"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_15977).method_9626(class_2498.field_11543).method_63500(resourceKey("standard"))));

        NETHERITE_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "netherite"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_16009).method_9626(class_2498.field_22150).method_63500(resourceKey("netherite"))));
        DIAMOND_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "diamond"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_15983).method_9626(class_2498.field_11533).method_63500(resourceKey("diamond"))));
        GOLD_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "gold"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_15994).method_9626(class_2498.field_11533).method_63500(resourceKey("gold")).method_9631(f -> 10)));
        EMERALD_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "emerald"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_16001).method_9626(class_2498.field_11533).method_63500(resourceKey("emerald"))));
        IRON_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "iron"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_16005).method_9626(class_2498.field_11533).method_63500(resourceKey("iron"))));
        LAPIS_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "lapis"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_15980).method_9626(class_2498.field_11544).method_63500(resourceKey("lapis"))));
        REDSTONE_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "redstone"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_16002).method_9626(class_2498.field_11533).method_63500(resourceKey("redstone")).method_26236((blockState, blockView, pos) -> false)));
        COAL_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "coal"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_16009).method_9626(class_2498.field_11544).method_63500(resourceKey("coal"))));

        QUARTZ_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "quartz"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_16025).method_9626(class_2498.field_11544).method_63500(resourceKey("quartz"))));
        BOOKSHELF_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "bookshelf"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_15977).method_9626(class_2498.field_11547).method_63500(resourceKey("bookshelf"))));
        END_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "end"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_15995).method_9626(class_2498.field_11537).method_63500(resourceKey("end")).method_9631(f -> 1)));
        NETHER_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "nether"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_16012).method_9626(class_2498.field_22146).method_63500(resourceKey("nether")).method_9631(f -> 11)));
        SANDSTONE_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "sandstone"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_15986).method_9626(class_2498.field_11544).method_63500(resourceKey("sandstone"))));
        SNOW_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "snow"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_16022).method_9626(class_2498.field_11548).method_63500(resourceKey("snow"))));
        SPONGE_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "sponge"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_16010).method_9626(class_2498.field_11535).method_63500(resourceKey("sponge"))));

        CAKE_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "cake"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_16008).method_9626(class_2498.field_11543).method_63500(resourceKey("cake"))));

        CACTUS_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "cactus"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_16004).method_9626(class_2498.field_11543).method_63500(resourceKey("cactus"))));
        HAY_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "hay"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_16010).method_9626(class_2498.field_11535).method_63500(resourceKey("hay"))));
        MELON_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "melon"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_15997).method_9626(class_2498.field_11547).method_63500(resourceKey("melon"))));
        PUMPKIN_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "pumpkin"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_15987).method_9626(class_2498.field_11547).method_63500(resourceKey("pumpkin"))));

        CREEPER_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "creeper"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_15995).method_9626(class_2498.field_11543).method_63500(resourceKey("creeper"))));
        DRAGON_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "dragon"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_16007).method_9626(class_2498.field_11533).method_63500(resourceKey("dragon"))));
        ENDERMAN_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "enderman"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_16009).method_9626(class_2498.field_11543).method_63500(resourceKey("enderman"))));
        BLAZE_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "blaze"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_15981).method_9626(class_2498.field_11533).method_63500(resourceKey("blaze"))));
        GHAST_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "ghast"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_15993).method_9626(class_2498.field_11543).method_63500(resourceKey("ghast"))));
        MAGMA_CUBE_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "magma_cube"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_16012).method_9626(class_2498.field_11545).method_63500(resourceKey("magma_cube"))));
        SKELETON_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "skeleton"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_15979).method_9626(class_2498.field_22149).method_63500(resourceKey("skeleton"))));
        SPIDER_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "spider"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_16009).method_9626(class_2498.field_11543).method_63500(resourceKey("spider"))));
        WITHER_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "wither"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_16009).method_9626(class_2498.field_22149).method_63500(resourceKey("wither"))));
        WARDEN_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "warden"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_16009).method_9626(class_2498.field_37646).method_63500(resourceKey("warden"))));

        BAT_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "bat"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_15977).method_9626(class_2498.field_11543).method_63500(resourceKey("bat"))));
        BEE_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "bee"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_16010).method_9626(class_2498.field_11543).method_63500(resourceKey("bee"))));
        WOLF_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "wolf"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_15978).method_9626(class_2498.field_11543).method_63500(resourceKey("wolf"))));
        FOX_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "fox"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_15981).method_9626(class_2498.field_11543).method_63500(resourceKey("fox"))));
        OCELOT_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "ocelot"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_15981).method_9626(class_2498.field_11543).method_63500(resourceKey("ocelot"))));
        HORSE_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "horse"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_15977).method_9626(class_2498.field_11543).method_63500(resourceKey("horse"))));
        COW_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "cow"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_15977).method_9626(class_2498.field_11545).method_63500(resourceKey("cow"))));
        PIG_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "pig"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_16030).method_9626(class_2498.field_11545).method_63500(resourceKey("pig"))));
        SHEEP_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "sheep"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_16003).method_9626(class_2498.field_11543).method_63500(resourceKey("sheep"))));
        SQUID_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "squid"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_16015).method_9626(class_2498.field_11545).method_63500(resourceKey("squid"))));
        CHICKEN_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "chicken"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_16003).method_9626(class_2498.field_11543).method_63500(resourceKey("chicken"))));
        VILLAGER_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "villager"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_15978).method_9626(class_2498.field_11543).method_63500(resourceKey("villager"))));
        IRON_GOLEM_TRAVELERS_BACKPACK = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "iron_golem"), new TravelersBackpackBlock(class_2248.Properties.method_9637().method_31710(class_3620.field_16005).method_9626(class_2498.field_11533).method_63500(resourceKey("iron_golem"))));

        WHITE_SLEEPING_BAG = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "white_sleeping_bag"), new SleepingBagBlock(class_1767.field_7952, class_2248.Properties.method_9637().method_31710(class_3620.field_16022).method_9626(class_2498.field_11543).method_63500(resourceKey("white_sleeping_bag")).method_9632(0.2F).method_50012(class_3619.field_15971)));
        ORANGE_SLEEPING_BAG = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "orange_sleeping_bag"), new SleepingBagBlock(class_1767.field_7946, class_2248.Properties.method_9637().method_31710(class_3620.field_15987).method_9626(class_2498.field_11543).method_63500(resourceKey("orange_sleeping_bag")).method_9632(0.2F).method_50012(class_3619.field_15971)));
        MAGENTA_SLEEPING_BAG = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "magenta_sleeping_bag"), new SleepingBagBlock(class_1767.field_7958, class_2248.Properties.method_9637().method_31710(class_3620.field_15998).method_9626(class_2498.field_11543).method_63500(resourceKey("magenta_sleeping_bag")).method_9632(0.2F).method_50012(class_3619.field_15971)));
        LIGHT_BLUE_SLEEPING_BAG = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "light_blue_sleeping_bag"), new SleepingBagBlock(class_1767.field_7951, class_2248.Properties.method_9637().method_31710(class_3620.field_16024).method_9626(class_2498.field_11543).method_63500(resourceKey("light_blue_sleeping_bag")).method_9632(0.2F).method_50012(class_3619.field_15971)));
        YELLOW_SLEEPING_BAG = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "yellow_sleeping_bag"), new SleepingBagBlock(class_1767.field_7947, class_2248.Properties.method_9637().method_31710(class_3620.field_16010).method_9626(class_2498.field_11543).method_63500(resourceKey("yellow_sleeping_bag")).method_9632(0.2F).method_50012(class_3619.field_15971)));
        LIME_SLEEPING_BAG = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "lime_sleeping_bag"), new SleepingBagBlock(class_1767.field_7961, class_2248.Properties.method_9637().method_31710(class_3620.field_15997).method_9626(class_2498.field_11543).method_63500(resourceKey("lime_sleeping_bag")).method_9632(0.2F).method_50012(class_3619.field_15971)));
        PINK_SLEEPING_BAG = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "pink_sleeping_bag"), new SleepingBagBlock(class_1767.field_7954, class_2248.Properties.method_9637().method_31710(class_3620.field_16030).method_9626(class_2498.field_11543).method_63500(resourceKey("pink_sleeping_bag")).method_9632(0.2F).method_50012(class_3619.field_15971)));
        GRAY_SLEEPING_BAG = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "gray_sleeping_bag"), new SleepingBagBlock(class_1767.field_7944, class_2248.Properties.method_9637().method_31710(class_3620.field_15978).method_9626(class_2498.field_11543).method_63500(resourceKey("gray_sleeping_bag")).method_9632(0.2F).method_50012(class_3619.field_15971)));
        LIGHT_GRAY_SLEEPING_BAG = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "light_gray_sleeping_bag"), new SleepingBagBlock(class_1767.field_7967, class_2248.Properties.method_9637().method_31710(class_3620.field_15993).method_63500(resourceKey("light_gray_sleeping_bag")).method_9626(class_2498.field_11543).method_9632(0.2F).method_50012(class_3619.field_15971)));
        CYAN_SLEEPING_BAG = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "cyan_sleeping_bag"), new SleepingBagBlock(class_1767.field_7955, class_2248.Properties.method_9637().method_31710(class_3620.field_16026).method_9626(class_2498.field_11543).method_63500(resourceKey("cyan_sleeping_bag")).method_9632(0.2F).method_50012(class_3619.field_15971)));
        PURPLE_SLEEPING_BAG = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "purple_sleeping_bag"), new SleepingBagBlock(class_1767.field_7945, class_2248.Properties.method_9637().method_31710(class_3620.field_16014).method_9626(class_2498.field_11543).method_63500(resourceKey("purple_sleeping_bag")).method_9632(0.2F).method_50012(class_3619.field_15971)));
        BLUE_SLEEPING_BAG = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "blue_sleeping_bag"), new SleepingBagBlock(class_1767.field_7966, class_2248.Properties.method_9637().method_31710(class_3620.field_15984).method_9626(class_2498.field_11543).method_63500(resourceKey("blue_sleeping_bag")).method_9632(0.2F).method_50012(class_3619.field_15971)));
        BROWN_SLEEPING_BAG = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "brown_sleeping_bag"), new SleepingBagBlock(class_1767.field_7957, class_2248.Properties.method_9637().method_31710(class_3620.field_15977).method_9626(class_2498.field_11543).method_63500(resourceKey("brown_sleeping_bag")).method_9632(0.2F).method_50012(class_3619.field_15971)));
        GREEN_SLEEPING_BAG = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "green_sleeping_bag"), new SleepingBagBlock(class_1767.field_7942, class_2248.Properties.method_9637().method_31710(class_3620.field_15995).method_9626(class_2498.field_11543).method_63500(resourceKey("green_sleeping_bag")).method_9632(0.2F).method_50012(class_3619.field_15971)));
        RED_SLEEPING_BAG = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "red_sleeping_bag"), new SleepingBagBlock(class_1767.field_7964, class_2248.Properties.method_9637().method_31710(class_3620.field_16020).method_9626(class_2498.field_11543).method_63500(resourceKey("red_sleeping_bag")).method_9632(0.2F).method_50012(class_3619.field_15971)));
        BLACK_SLEEPING_BAG = class_2378.method_10230(class_7923.field_41175, class_2960.method_60655(TravelersBackpack.MODID, "black_sleeping_bag"), new SleepingBagBlock(class_1767.field_7963, class_2248.Properties.method_9637().method_31710(class_3620.field_16009).method_9626(class_2498.field_11543).method_63500(resourceKey("black_sleeping_bag")).method_9632(0.2F).method_50012(class_3619.field_15971)));
    }

    public static class_2960 resourceLocation(String name) {
        return class_2960.method_60655(TravelersBackpack.MODID, name);
    }

    public static class_5321<class_2248> resourceKey(String name) {
        return class_5321.method_29179(class_7924.field_41254, resourceLocation(name));
    }
}