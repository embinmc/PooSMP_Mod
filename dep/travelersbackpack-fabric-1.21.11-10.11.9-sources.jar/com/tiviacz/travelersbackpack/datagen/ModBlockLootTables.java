package com.tiviacz.travelersbackpack.datagen;

import com.tiviacz.travelersbackpack.blocks.SleepingBagBlock;
import com.tiviacz.travelersbackpack.init.ModBlocks;
import com.tiviacz.travelersbackpack.init.ModDataComponents;
import net.fabricmc.fabric.api.datagen.v1.FabricDataOutput;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.minecraft.class_1792;
import net.minecraft.class_181;
import net.minecraft.class_212;
import net.minecraft.class_2248;
import net.minecraft.class_2742;
import net.minecraft.class_44;
import net.minecraft.class_4559;
import net.minecraft.class_52;
import net.minecraft.class_55;
import net.minecraft.class_7225;
import net.minecraft.class_77;
import net.minecraft.class_9317;
import net.minecraft.class_9334;
import java.util.concurrent.CompletableFuture;

public class ModBlockLootTables extends FabricBlockLootTableProvider {
    protected ModBlockLootTables(FabricDataOutput output, CompletableFuture<class_7225.class_7874> holderLookupProvidr) {
        super(output, holderLookupProvidr);
    }

    @Override
    public void method_10379() {
        for(class_1792 item : ModRecipeProvider.BACKPACKS) {
            this.method_45994(class_2248.method_9503(item), this::createBackpackDrop);
        }

        this.method_45994(ModBlocks.BLACK_SLEEPING_BAG, this::createSleepingBagDrop);
        this.method_45994(ModBlocks.BLUE_SLEEPING_BAG, this::createSleepingBagDrop);
        this.method_45994(ModBlocks.BROWN_SLEEPING_BAG, this::createSleepingBagDrop);
        this.method_45994(ModBlocks.CYAN_SLEEPING_BAG, this::createSleepingBagDrop);
        this.method_45994(ModBlocks.GRAY_SLEEPING_BAG, this::createSleepingBagDrop);
        this.method_45994(ModBlocks.GREEN_SLEEPING_BAG, this::createSleepingBagDrop);
        this.method_45994(ModBlocks.LIGHT_BLUE_SLEEPING_BAG, this::createSleepingBagDrop);
        this.method_45994(ModBlocks.LIGHT_GRAY_SLEEPING_BAG, this::createSleepingBagDrop);
        this.method_45994(ModBlocks.LIME_SLEEPING_BAG, this::createSleepingBagDrop);
        this.method_45994(ModBlocks.MAGENTA_SLEEPING_BAG, this::createSleepingBagDrop);
        this.method_45994(ModBlocks.PURPLE_SLEEPING_BAG, this::createSleepingBagDrop);
        this.method_45994(ModBlocks.ORANGE_SLEEPING_BAG, this::createSleepingBagDrop);
        this.method_45994(ModBlocks.PINK_SLEEPING_BAG, this::createSleepingBagDrop);
        this.method_45994(ModBlocks.RED_SLEEPING_BAG, this::createSleepingBagDrop);
        this.method_45994(ModBlocks.WHITE_SLEEPING_BAG, this::createSleepingBagDrop);
        this.method_45994(ModBlocks.YELLOW_SLEEPING_BAG, this::createSleepingBagDrop);
    }

    protected class_52.class_53 createBackpackDrop(class_2248 block) {
        return class_52.method_324()
                .method_336(method_45978(block, class_55.method_347().method_352(class_44.method_32448(1.0F))
                        .method_351(class_77.method_411(block)
                                .method_438(class_9317.method_74903(class_181.field_1228)
                                        .method_58730(ModDataComponents.TIER)
                                        .method_58730(ModDataComponents.STORAGE_SLOTS)
                                        .method_58730(ModDataComponents.UPGRADE_SLOTS)
                                        .method_58730(ModDataComponents.TOOL_SLOTS)
                                        .method_58730(ModDataComponents.BACKPACK_CONTAINER)
                                        .method_58730(ModDataComponents.TOOLS_CONTAINER)
                                        .method_58730(ModDataComponents.UPGRADES)
                                        .method_58730(ModDataComponents.SHOW_TOOL_SLOTS)
                                        .method_58730(ModDataComponents.SLEEPING_BAG_COLOR)
                                        .method_58730(ModDataComponents.ABILITY_ENABLED)
                                        .method_58730(ModDataComponents.COOLDOWN)
                                        .method_58730(ModDataComponents.RENDER_INFO)
                                        .method_58730(ModDataComponents.STARTER_UPGRADES)
                                        .method_58730(ModDataComponents.SLOTS)
                                        .method_58730(ModDataComponents.IS_VISIBLE)
                                        .method_58730(ModDataComponents.UPGRADE_TICK_INTERVAL)
                                        .method_58730(class_9334.field_49631)
                                        .method_58730(class_9334.field_49644)))));
    }

    protected class_52.class_53 createSleepingBagDrop(class_2248 block) {
        return class_52.method_324()
                .method_336(method_45978(block, class_55.method_347().method_352(class_44.method_32448(1.0F))
                        .method_351(class_77.method_411(block).method_421(class_212.method_900(block)
                                .method_22584(class_4559.class_4560.method_22523().method_22525(SleepingBagBlock.field_9967, class_2742.field_12560))))));
    }
}