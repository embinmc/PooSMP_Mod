package com.tiviacz.travelersbackpack.common;

import com.tiviacz.travelersbackpack.mixin.LevelResourceMixin;
import com.tiviacz.travelersbackpack.util.LogHelper;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.UUID;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2507;
import net.minecraft.class_2509;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5218;

public class BackpackManager {
    public static class_5218 BACKPACKS = LevelResourceMixin.invokeInit("backpacks");

    public static void addBackpack(class_3222 player, class_1799 stack) {
        try {
            LocalDateTime deathTime = LocalDateTime.now();
            //Format
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd.MM.yyyy-HH.mm.ss");
            String formattedDeathTime = deathTime.format(formatter);

            String datedBackpackName = stack.method_41409().method_55840().replace(":", ".") + "_" + formattedDeathTime + ".dat";
            File backpackFile = getBackpackFile(player, datedBackpackName);
            backpackFile.getParentFile().mkdirs();
            class_2487 stackTag = (class_2487)class_1799.field_24671.encodeStart(player.method_56673().method_57093(class_2509.field_11560), stack).result().orElseGet(class_2487::new);
            class_2507.method_10630(stackTag, backpackFile.toPath());
            LogHelper.info("Created new backpack backup file for " + player.method_5476().getString() + " with unique ID " + datedBackpackName);
        } catch(Exception e) {
            e.printStackTrace();
        }
    }

    @Nullable
    public static class_1799 readBackpack(class_3218 serverLevel, UUID playerUUID, String backpackId) {
        try {
            class_2487 data = class_2507.method_10633(getBackpackFile(serverLevel, playerUUID, backpackId).toPath());
            if(data == null) {
                return null;
            }
            return class_1799.field_24671.parse(serverLevel.method_30349().method_57093(class_2509.field_11560), data).result().orElse(class_1799.field_8037);
        } catch(Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Nullable
    public static class_1799 getBackpack(class_3218 serverLevel, String backpackId) {
        File deathFolder = getBackpackFolder(serverLevel);
        File[] players = deathFolder.listFiles((dir, name) -> name.matches("^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$"));

        if(players == null) {
            return null;
        }

        for(File f : players) {
            if(!f.isDirectory()) {
                continue;
            }
            File[] files = f.listFiles((dir, name) -> name.equals(backpackId));
            if(files != null && files.length > 0) {
                return readBackpack(serverLevel, UUID.fromString(f.getName()), backpackId);
            }
        }
        return null;
    }

    public static File getBackpackFile(class_3218 serverLevel, UUID playerUUID, String backpackId) {
        return new File(getPlayerBackpackFolder(serverLevel, playerUUID), backpackId);
    }

    public static File getBackpackFile(class_3222 player, String backpackId) {
        return new File(getPlayerBackpackFolder(player), backpackId);
    }

    public static File getPlayerBackpackFolder(class_3222 player) {
        return getPlayerBackpackFolder(player.method_51469(), player.method_5667());
    }

    public static File getPlayerBackpackFolder(class_3218 serverLevel, UUID uuid) {
        return new File(getBackpackFolder(serverLevel), uuid.toString());
    }

    public static File getBackpackFolder(class_3218 serverLevel) {
        return getWorldFolder(serverLevel, BACKPACKS);
    }

    public static File getWorldFolder(class_3218 serverLevel, class_5218 path) {
        return serverLevel.method_8503().method_27050(path).toFile();
    }
}