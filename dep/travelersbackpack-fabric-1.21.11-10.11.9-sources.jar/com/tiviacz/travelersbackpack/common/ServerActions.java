package com.tiviacz.travelersbackpack.common;

import com.tiviacz.travelersbackpack.advancements.ActionTypeTrigger;
import com.tiviacz.travelersbackpack.blockentity.BackpackBlockEntity;
import com.tiviacz.travelersbackpack.blocks.SleepingBagBlock;
import com.tiviacz.travelersbackpack.attachment.AttachmentUtils;
import com.tiviacz.travelersbackpack.config.TravelersBackpackConfig;
import com.tiviacz.travelersbackpack.fluids.EffectFluidRegistry;
import com.tiviacz.travelersbackpack.init.ModAdvancements;
import com.tiviacz.travelersbackpack.init.ModDataComponents;
import com.tiviacz.travelersbackpack.init.ModItems;
import com.tiviacz.travelersbackpack.inventory.*;
import com.tiviacz.travelersbackpack.inventory.handler.ItemStackHandler;
import com.tiviacz.travelersbackpack.inventory.menu.BackpackBaseMenu;
import com.tiviacz.travelersbackpack.inventory.menu.BackpackItemMenu;
import com.tiviacz.travelersbackpack.inventory.menu.BackpackSettingsMenu;
import com.tiviacz.travelersbackpack.inventory.menu.slot.ToolSlotItemHandler;
import com.tiviacz.travelersbackpack.inventory.sorter.ContainerSorter;
import com.tiviacz.travelersbackpack.inventory.upgrades.IEnable;
import com.tiviacz.travelersbackpack.inventory.upgrades.UpgradeBase;
import com.tiviacz.travelersbackpack.inventory.upgrades.tanks.TanksUpgrade;
import com.tiviacz.travelersbackpack.item.HoseItem;
import com.tiviacz.travelersbackpack.item.TravelersBackpackItem;
import com.tiviacz.travelersbackpack.util.InventoryHelper;
import com.tiviacz.travelersbackpack.util.Reference;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.minecraft.class_10690;
import net.minecraft.class_10691;
import net.minecraft.class_12206;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1676;
import net.minecraft.class_1767;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2404;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2742;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_4537;
import net.minecraft.class_9331;
import java.util.List;
import java.util.Optional;

public class ServerActions {
    public static void swapTool(class_1657 player, int slot, int button) {
        if(!TravelersBackpackConfig.SERVER.backpackSettings.allowToolSwapping.get()) {
            return;
        }
        if(AttachmentUtils.isWearingBackpack(player)) {
            BackpackWrapper wrapper = AttachmentUtils.getBackpackWrapper(player, AttachmentUtils.TOOLS_ONLY.get());
            ItemStackHandler inv = wrapper.getTools();
            class_1268 hand = button == 0 ? class_1268.field_5808 : class_1268.field_5810;
            class_1799 handStack = player.method_5998(hand);

            if(!handStack.method_7960() && !ToolSlotItemHandler.isValid(handStack)) {
                return;
            }

            if(slot == -999) {
                if(handStack.method_7960()) return;

                class_1799 remaining = InventoryHelper.addItemStackToHandler(inv, handStack.method_7972(), false);
                if(remaining.method_7960()) {
                    player.method_6122(hand, class_1799.field_8037);
                } else {
                    player.method_6122(hand, remaining);
                }
            } else {
                class_1799 currentTool = inv.getStackInSlot(slot).method_7972();

                inv.setStackInSlot(slot, handStack.method_7972());
                player.method_6122(hand, currentTool);
            }

            if(player instanceof class_3222 serverPlayer) {
                ModAdvancements.ACTION_TRIGGER.trigger(serverPlayer, ActionTypeTrigger.SWAP_TOOLS);
            }
            player.method_73183().method_60511(null, player.method_73189().method_10216(), player.method_73189().method_10214() + 0.5, player.method_73189().method_10215(), class_3417.field_14581, class_3419.field_15245, 1.0F, 1.0F);
            wrapper.sendDataToClients(ModDataComponents.TOOLS_CONTAINER);
        }
    }

    public static void equipBackpack(class_1657 player, boolean equip) {
        if(equip) {
            handleEquipBackpack(player);
        } else {
            handleUnequipBackpack(player);
        }
    }

    public static boolean swapBackpack(class_1657 player) {
        class_1937 level = player.method_73183();

        if(level.method_8608() || !AttachmentUtils.isWearingBackpack(player)) {
            return false;
        }

        if(player.field_7512 instanceof BackpackItemMenu) {
            ((class_3222)player).method_7346();
        }

        class_1799 equippedBackpack = AttachmentUtils.getWearingBackpack(player).method_7972();
        class_1799 newBackpack = player.method_6047().method_7972();

        AttachmentUtils.getAttachment(player).ifPresent(attachment -> {
            attachment.equipBackpack(newBackpack, player);
            attachment.synchronise(player);
        });

        runAbilitiesRemoval(player);

        player.method_6047().method_7934(1);
        player.method_31548().method_7394(equippedBackpack);

        return true;
    }

    public static void runAbilitiesRemoval(class_1657 player) {
        BackpackAbilities.ABILITIES.armorAbilityRemovals(player);
    }

    public static boolean equipBackpack(class_1657 player) {
        class_1937 level = player.method_73183();

        if(level.method_8608()) {
            return false;
        }

        if(AttachmentUtils.isWearingBackpack(player)) {
            return swapBackpack(player);
        }

        if(player.field_7512 instanceof BackpackItemMenu) {
            ((class_3222)player).method_7346();
        }

        class_1799 stack = player.method_6047().method_7972();

        AttachmentUtils.getAttachment(player).ifPresent(attachment -> {
            attachment.equipBackpack(stack, player);
            attachment.synchronise(player);
        });

        player.method_6047().method_7934(1);
        return true;
    }

    public static void handleEquipBackpack(class_1657 player) {
        if(!equipBackpack(player))
            return;

        playEquippingSound(player);
    }

    public static boolean unequipBackpack(class_1657 player) {
        class_1937 level = player.method_73183();

        if(level.method_8608() || !AttachmentUtils.isWearingBackpack(player)) {
            return false;
        }

        if(player.field_7512 instanceof BackpackItemMenu) {
            ((class_3222)player).method_7346();
        }

        class_1799 backpack = AttachmentUtils.getWearingBackpack(player).method_7972();

        //Try to add to inventory
        int index = player.method_31548().method_7390(backpack);
        if(index == -1) {
            index = player.method_31548().method_7376();
        }

        if(index != -1) {
            player.method_31548().method_7398(backpack);
        } else {
            if(player instanceof class_3222 serverPlayer) {
                serverPlayer.method_64398(class_2561.method_43471(Reference.NO_SPACE));
            }
            return false;
        }

        AttachmentUtils.getAttachment(player).ifPresent(attachment -> {
            attachment.equipBackpack(new class_1799(class_1802.field_8162, 0), player);
            attachment.synchronise(player);
        });

        return true;
    }

    public static void handleUnequipBackpack(class_1657 player) {
        if(!unequipBackpack(player))
            return;

        playEquippingSound(player);
    }

    private static void playEquippingSound(class_1657 player) {
        player.method_73183().method_8396(null, player.method_24515(), class_3417.field_14581.comp_349(), class_3419.field_15248, 1.05F, (1.0F + (player.method_73183().method_8409().method_43057() - player.method_73183().method_8409().method_43057()) * 0.2F) * 0.7F);
    }

    public static void openBackpackFromSlot(class_3222 player, int index, boolean fromSlot) {
        if(index >= 0 && index < player.method_31548().method_67533().size()) {
            class_1799 backpackStack = player.method_31548().method_67533().get(index);
            if(backpackStack.method_7909() instanceof TravelersBackpackItem) {
                if(!TravelersBackpackConfig.SERVER.backpackSettings.allowOnlyEquippedBackpack.get()) {
                    if(!fromSlot || TravelersBackpackConfig.SERVER.backpackSettings.allowOpeningFromSlot.get()) {
                        BackpackContainer.openBackpack(player, backpackStack, Reference.ITEM_SCREEN_ID, index);
                    }
                }
            }
        }
    }

    public static void openBackpackSettings(class_3222 player, int entityId, boolean open) {
        if(player.method_5628() == entityId) {
            if(player.field_7512 instanceof BackpackBaseMenu menu) {
                if(open) {
                    if(menu.getWrapper().getScreenID() == Reference.BLOCK_ENTITY_SCREEN_ID) {
                        if(player.method_51469().method_8321(menu.getWrapper().getBackpackPos()) instanceof BackpackBlockEntity backpackBlockEntity) {
                            backpackBlockEntity.openSettings(player, backpackBlockEntity, menu.getWrapper().getBackpackPos());
                        }
                    } else {
                        BackpackSettingsContainer.openSettings(player, menu.getWrapper().getBackpackStack(), menu.getWrapper().getScreenID(), menu.getWrapper().getBackpackSlotIndex());
                    }
                }
            } else if(player.field_7512 instanceof BackpackSettingsMenu menu) {
                if(!open) {
                    if(menu.getWrapper().getScreenID() == Reference.BLOCK_ENTITY_SCREEN_ID) {
                        if(player.method_51469().method_8321(menu.getWrapper().getBackpackPos()) instanceof BackpackBlockEntity backpackBlockEntity) {
                            backpackBlockEntity.openBackpack(player, backpackBlockEntity, menu.getWrapper().getBackpackPos());
                        }
                    } else {
                        BackpackContainer.openBackpack(player, menu.getWrapper().getBackpackStack(), menu.getWrapper().getScreenID(), menu.getWrapper().getBackpackSlotIndex());
                    }
                }
            }
        }
    }

    public static final int TAB_OPEN = 0;
    public static final int UPGRADE_ENABLED = 1;
    public static final int SHIFT_CLICK_TO_BACKPACK = 2;
    public static final int PLAY_RECORD = 3;

    public static void modifyUpgradeTab(class_3222 player, int slot, boolean open, int packetType, boolean fromMenu) {
        if(fromMenu) {
            if(player.field_7512 instanceof BackpackBaseMenu menu) {
                modifyUpgradeTab(menu.getWrapper(), slot, open, packetType);
            }
        } else {
            BackpackWrapper wrapper = AttachmentUtils.getBackpackWrapper(player, AttachmentUtils.UPGRADES_ONLY.get());
            wrapper.getUpgradeManager().mappedUpgrades.get(slot).ifPresent(upgrade -> {
                if(upgrade instanceof IEnable enable) {
                    boolean isEnabled = enable.isEnabled(upgrade);
                    modifyUpgradeTab(wrapper, slot, !isEnabled, UPGRADE_ENABLED);
                    class_2561 upgradeName = upgrade.getDataHolderStack().method_7909().method_7864(upgrade.getDataHolderStack());
                    player.method_7353(class_2561.method_43469(isEnabled ? "screen.travelersbackpack.upgrade_disabled" : "screen.travelersbackpack.upgrade_enabled", upgradeName), true);
                }
            });
        }
    }

    public static void modifyUpgradeTab(BackpackWrapper wrapper, int slot, boolean open, int packetType) {
        class_1799 upgradeStack = wrapper.getUpgrades().getStackInSlot(slot);
        if(!upgradeStack.method_7960()) {
            class_1799 updateStack = upgradeStack.method_7972();
            updateStack.method_57379(getPacketType(packetType), open);
            wrapper.getUpgrades().setStackInSlot(slot, updateStack);

            if(packetType == UPGRADE_ENABLED) {
                if(wrapper.getUpgradeManager().hasUpgradeInSlot(slot)) {
                    wrapper.getUpgradeManager().mappedUpgrades.get(slot).ifPresent(upgradeBase -> {
                        if(upgradeBase instanceof IEnable upg) {
                            upg.setEnabled(open);
                        }
                    });
                }
            }
        }
    }

    public static class_9331 getPacketType(int type) {
        return switch(type) {
            case 0 -> ModDataComponents.TAB_OPEN;
            case 1 -> ModDataComponents.UPGRADE_ENABLED;
            case 2 -> ModDataComponents.SHIFT_CLICK_TO_BACKPACK;
            case 3 -> ModDataComponents.IS_PLAYING;
            default -> ModDataComponents.TAB_OPEN;
        };
    }

    public static void removeBackpackUpgrade(class_3222 player, int slot) {
        if(player.field_7512 instanceof BackpackBaseMenu menu) {
            BackpackWrapper wrapper = menu.getWrapper();
            if(!wrapper.getUpgrades().getStackInSlot(slot).method_7960()) {
                Optional<? extends UpgradeBase<?>> upgrade = wrapper.getUpgradeManager().mappedUpgrades.get(slot);

                class_1799 upgradeStack = wrapper.getUpgrades().getStackInSlot(slot).method_7972();
                upgradeStack.method_57379(ModDataComponents.TAB_OPEN, false);
                wrapper.getUpgrades().setStackInSlot(slot, class_1799.field_8037);

                upgrade.ifPresent(upgradeBase -> upgradeBase.onUpgradeRemoved(upgradeStack, player));

                if(!player.method_31548().method_7394(upgradeStack)) {
                    player.method_7328(upgradeStack, true);
                }
                wrapper.saveHandler.run();
            }
        }
    }

    public static void switchAbilitySlider(class_3222 player, boolean sliderValue) {
        BackpackWrapper wrapper = AttachmentUtils.getBackpackWrapperArtificial(player);

        //If ability slider is being switched in the backpack screen, then reassign the wrapper
        if(player.field_7512 instanceof BackpackBaseMenu menu) {
            wrapper = menu.getWrapper();
        }

        wrapper.setDataAndSync(ModDataComponents.ABILITY_ENABLED, sliderValue);

        //Run for equipped backpack
        if(wrapper.getBackpackOwner() != null) {
            if(BackpackAbilities.isOnList(BackpackAbilities.ITEM_ABILITIES_REMOVAL_LIST, wrapper.getBackpackStack()) && !sliderValue) {
                BackpackAbilities.ABILITIES.abilityRemoval(wrapper.getBackpackStack(), wrapper.getBackpackOwner());
            }

            if(wrapper.getBackpackStack().method_7909() == ModItems.CHICKEN_TRAVELERS_BACKPACK && wrapper.getCooldown() <= 0) {
                BackpackAbilities.ABILITIES.chickenAbility(wrapper.getBackpackStack(), wrapper.getBackpackOwner(), true);
            }
        }
    }

    public static void showToolSlots(class_3222 player, boolean show) {
        if(player.field_7512 instanceof BackpackBaseMenu menu) {
            //menu.getWrapper().setShowToolSlots(show);
            menu.getWrapper().setDataAndSync(ModDataComponents.SHOW_TOOL_SLOTS, show);
        }
    }

    public static void sortBackpack(class_3222 player, int button, boolean shiftPressed) {
        if(player.field_7512 instanceof BackpackBaseMenu menu) {
            ContainerSorter.selectSort(menu.getWrapper(), player, button, shiftPressed);
        }
    }

    public static void toggleVisibility(class_1657 player) {
        if(player.field_7512 instanceof BackpackSettingsMenu menu) {
            boolean visibility = menu.getWrapper().getBackpackStack().method_58695(ModDataComponents.IS_VISIBLE, true);
            menu.getWrapper().setDataAndSync(ModDataComponents.IS_VISIBLE, !visibility);
            //menu.getWrapper().setVisibility(!visibility);
        }
    }

    public static void toggleButtonsVisibility(class_1657 player) {
        if(player.field_7512 instanceof BackpackBaseMenu menu) {
            boolean current = menu.getWrapper().showMoreButtons();
            menu.getWrapper().setDataAndSync(ModDataComponents.SHOW_MORE_BUTTONS, !current);
            //menu.getWrapper().setShowMoreButtons(!current);
        }
    }

    public static void toggleSleepingBag(class_1657 player, class_2338 pos, boolean isEquipped) {
        class_1937 level = player.method_73183();
        if(isEquipped) {
            class_2338 sleepingBagPos1 = pos;
            class_2338 sleepingBagPos2 = sleepingBagPos1.method_10093(player.method_5735());
            boolean canPlace = placeAndUseSleepingBag(player, sleepingBagPos1, sleepingBagPos2, pos, level, player.method_5735());
            if(!canPlace) {
                if(player instanceof class_3222 serverPlayer) {
                    serverPlayer.method_64398(class_2561.method_43471(Reference.DEPLOY));
                    serverPlayer.method_7346();
                }
                return;
            }

            if(!level.method_8608()) {
                if(player instanceof class_3222 serverPlayer) {
                    player.method_7269(pos.method_10093(player.method_5735())).ifLeft(bedSleepingProblem -> {
                        if(bedSleepingProblem.comp_5144() != null) {
                            player.method_7353(bedSleepingProblem.comp_5144(), true);
                            if(level.method_8320(sleepingBagPos1).method_26204() instanceof SleepingBagBlock) {
                                level.method_8501(sleepingBagPos1, class_2246.field_10124.method_9564());
                            }
                            if(level.method_8320(sleepingBagPos2).method_26204() instanceof SleepingBagBlock) {
                                level.method_8501(sleepingBagPos2, class_2246.field_10124.method_9564());
                            }
                        }
                    });
                    ModAdvancements.ACTION_TRIGGER.trigger(serverPlayer, ActionTypeTrigger.USE_SLEEPING_BAG);
                    serverPlayer.method_7346();
                }
            }
        } else {
            if(level.method_8321(pos) instanceof BackpackBlockEntity blockEntity) {
                if(!blockEntity.isSleepingBagDeployed()) {
                    if(!blockEntity.deploySleepingBag(level, pos)) {
                        if(player instanceof class_3222 serverPlayer) {
                            serverPlayer.method_64398(class_2561.method_43471(Reference.DEPLOY));
                        }
                    }
                } else {
                    blockEntity.removeSleepingBag(level, blockEntity.getBlockDirection());
                }
                if(!level.method_8608()) {
                    ((class_3222)player).method_7346();
                }
            }
        }
    }

    public static boolean placeAndUseSleepingBag(class_1657 player, class_2338 sleepingBagPos1, class_2338 sleepingBagPos2, class_2338 pos, class_1937 level, class_2350 direction) {
        if(!player.method_24828() || level.method_8320(sleepingBagPos1.method_10074()).method_26215() || level.method_8320(sleepingBagPos1.method_10074()).method_26204() instanceof class_2404 || level.method_75728().method_75697(class_12206.field_63756, pos).comp_5138()) {
            return false;
        }
        class_1799 backpack = AttachmentUtils.getWearingBackpack(player);
        if(BackpackBlockEntity.canPlaceSleepingBag(sleepingBagPos2, level) && BackpackBlockEntity.canPlaceSleepingBag(sleepingBagPos1, level)) {
            level.method_8396(null, sleepingBagPos2, class_3417.field_15226, class_3419.field_15245, 0.5F, 1.0F);

            if(!level.method_8608()) {
                class_2680 sleepingBagState = BackpackBlockEntity.getProperSleepingBag(backpack.method_58695(ModDataComponents.SLEEPING_BAG_COLOR, class_1767.field_7964.method_7789()));
                level.method_8652(sleepingBagPos1, sleepingBagState.method_11657(SleepingBagBlock.field_11177, direction).method_11657(SleepingBagBlock.PART, class_2742.field_12557).method_11657(SleepingBagBlock.CAN_DROP, false), 3);
                level.method_8652(sleepingBagPos2, sleepingBagState.method_11657(SleepingBagBlock.field_11177, direction).method_11657(SleepingBagBlock.PART, class_2742.field_12560).method_11657(SleepingBagBlock.CAN_DROP, false), 3);

                level.method_8408(pos, sleepingBagState.method_26204());
                level.method_8408(sleepingBagPos2, sleepingBagState.method_26204());
            }
            return true;
        }
        return false;
    }

    public static final int SLOT = 0;
    public static final int TANK = 1;

    public static void setStack(class_1657 player, int type, class_1799 stack, int index) {
        if(!(player.field_7512 instanceof BackpackBaseMenu menu)) {
            return;
        }

        switch(type) {
            case SLOT: {
                player.field_7512.method_7611(index).method_7673(stack);
                break;
            }
            case TANK: {
                BackpackWrapper wrapper = menu.getWrapper();
                wrapper.getUpgradeManager().getUpgrade(TanksUpgrade.class).ifPresent(tanks -> {
                    if(index == 0) {
                        tanks.getLeftTank().drain(wrapper.getBackpackTankCapacity(), false);
                    }
                    if(index == 1) {
                        tanks.getRightTank().drain(wrapper.getBackpackTankCapacity(), false);
                    }
                });
                break;
            }
        }
    }

    public static long throwPotion(class_1937 level, class_1657 player, class_1799 potionStack, boolean isSplash) {
        level.method_43128(null, player.method_23317(), player.method_23318(), player.method_23321(), isSplash ? class_3417.field_14910 : class_3417.field_14767, class_3419.field_15254, 0.5F, 0.4F / (level.method_8409().method_43057() * 0.4F + 0.8F));

        if(level instanceof class_3218 serverlevel) {
            class_1676.method_61549(isSplash ? class_10691::new : class_10690::new, serverlevel, potionStack, player, -20.0F, class_4537.field_55046, 1.0F);
        }

        if(!player.method_31549().field_7477) {
            return FluidConstants.BOTTLE;
        }
        return 0;
    }

    public static boolean setFluidEffect(class_1937 level, class_1657 player, FluidTank tank) {
        FluidVariantWrapper fluidStack = tank.getFluid();
        boolean done = false;
        if(EffectFluidRegistry.hasExecutableEffects(fluidStack, level, player)) {
            done = EffectFluidRegistry.executeEffects(fluidStack, player, level);
        }
        return done;
    }

    public static void switchHoseMode(class_1657 player, int mode) {
        class_1799 hose = player.method_6047();
        if(hose.method_7909() instanceof HoseItem) {
            List<Integer> settings = hose.method_58695(ModDataComponents.HOSE_MODES, List.of(1, 1));
            hose.method_57379(ModDataComponents.HOSE_MODES, List.of(mode, settings.get(1)));
        }
        player.method_73183().method_43128(null, player.method_73189().method_10216(), player.method_73189().method_10214() + 0.5, player.method_73189().method_10215(), class_3417.field_46932, class_3419.field_15245, 1.0F, 1.0F);
    }

    public static void toggleHoseTank(class_1657 player, int tank) {
        class_1799 hose = player.method_6047();
        if(hose.method_7909() instanceof HoseItem) {
            List<Integer> settings = hose.method_58695(ModDataComponents.HOSE_MODES, List.of(1, 1));
            hose.method_57379(ModDataComponents.HOSE_MODES, List.of(settings.get(0), tank));
        }
        player.method_73183().method_43128(null, player.method_73189().method_10216(), player.method_73189().method_10214() + 0.5, player.method_73189().method_10215(), class_3417.field_14779, class_3419.field_15245, 1.0F, 1.0F);
    }
}