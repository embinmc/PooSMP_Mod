package com.tiviacz.travelersbackpack.common.recipes;

import com.tiviacz.travelersbackpack.TravelersBackpack;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_10591;
import net.minecraft.class_161;
import net.minecraft.class_170;
import net.minecraft.class_175;
import net.minecraft.class_1792;
import net.minecraft.class_1856;
import net.minecraft.class_1860;
import net.minecraft.class_2119;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7800;
import net.minecraft.class_7924;
import net.minecraft.class_8782;
import net.minecraft.class_8790;

public class BackpackUpgradeRecipeBuilder {
    private final class_1856 template;
    private final class_1856 base;
    private final class_1856 addition;
    private final class_7800 category;
    private final class_1792 result;
    private final Map<String, class_175<?>> criteria = new LinkedHashMap<>();

    public BackpackUpgradeRecipeBuilder(class_1856 pTemplate, class_1856 pBase, class_1856 pAddition, class_7800 pCategory, class_1792 pResult) {
        this.category = pCategory;
        this.template = pTemplate;
        this.base = pBase;
        this.addition = pAddition;
        this.result = pResult;
    }

    public static BackpackUpgradeRecipeBuilder backpackUpgrade(class_1856 pTemplate, class_1856 pBase, class_1856 pAddition, class_7800 pCategory, class_1792 pResult) {
        return new BackpackUpgradeRecipeBuilder(pTemplate, pBase, pAddition, pCategory, pResult);
    }

    public BackpackUpgradeRecipeBuilder unlocks(String pKey, class_175<?> criterion) {
        this.criteria.put(pKey, criterion);
        return this;
    }

    public void save(class_8790 recipeOutput, String recipeId) {
        this.save(recipeOutput, class_5321.method_29179(class_7924.field_52178, class_2960.method_60655(TravelersBackpack.MODID, recipeId)));
    }

    public void save(class_8790 output, class_5321<class_1860<?>> resourceKey) {
        this.ensureValid(resourceKey);
        class_161.class_162 advancement$builder = output.method_53818()
                .method_705("has_the_recipe", class_2119.method_27847(resourceKey))
                .method_703(class_170.class_171.method_753(resourceKey))
                .method_704(class_8782.class_8797.field_1257);
        this.criteria.forEach(advancement$builder::method_705);
        BackpackUpgradeRecipe backpackUpgradeRecipe = new BackpackUpgradeRecipe(
                Optional.of(this.template), this.base, Optional.of(this.addition), new class_10591(this.result)
        );
        output.method_53819(
                resourceKey, backpackUpgradeRecipe, advancement$builder.method_695(resourceKey.method_29177().method_45138("recipes/" + this.category.method_46203() + "/"))
        );
    }

    private void ensureValid(class_5321<class_1860<?>> recipe) {
        if(this.criteria.isEmpty()) {
            throw new IllegalStateException("No way of obtaining recipe " + recipe.method_29177());
        }
    }
}