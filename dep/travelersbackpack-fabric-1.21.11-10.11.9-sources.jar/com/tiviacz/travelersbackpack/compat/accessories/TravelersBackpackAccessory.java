package com.tiviacz.travelersbackpack.compat.accessories;

import com.tiviacz.travelersbackpack.client.model.StackModelPart;
import com.tiviacz.travelersbackpack.client.renderer.BackpackLayer;
import com.tiviacz.travelersbackpack.config.TravelersBackpackConfig;
import com.tiviacz.travelersbackpack.inventory.BackpackWrapper;
import com.tiviacz.travelersbackpack.item.TravelersBackpackItem;
import io.wispforest.accessories.api.AccessoriesAPI;
import io.wispforest.accessories.api.client.AccessoriesRenderStateKeys;
import io.wispforest.accessories.api.client.AccessoriesRendererRegistry;
import io.wispforest.accessories.api.client.AccessoryRenderState;
import io.wispforest.accessories.api.client.renderers.SimpleAccessoryRenderer;
import io.wispforest.accessories.api.core.Accessory;
import io.wispforest.accessories.api.slot.SlotReference;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_10042;
import net.minecraft.class_10055;
import net.minecraft.class_10444;
import net.minecraft.class_11659;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_583;
import net.minecraft.class_591;
import net.minecraft.class_7923;

public class TravelersBackpackAccessory implements Accessory {
    public static void init() {
        class_7923.field_41178.method_10220()
                .filter(item -> item instanceof TravelersBackpackItem)
                .forEach(item -> AccessoriesAPI.registerAccessory(item, new TravelersBackpackAccessory()));
    }

    @Environment(EnvType.CLIENT)
    public static void initClient() {
        class_7923.field_41178.method_10220()
                .filter(holder -> holder instanceof TravelersBackpackItem)
                .forEach(holder -> AccessoriesRendererRegistry.registerRenderer(holder, Renderer::new));
    }

    @Override
    public boolean canEquip(class_1799 stack, SlotReference reference) {
        return TravelersBackpackConfig.SERVER.backpackSettings.backSlotIntegration.get();
    }

    @Override
    public boolean canEquipFromUse(class_1799 stack, SlotReference reference) {
        return false;
    }

    @Override
    public void tick(class_1799 stack, SlotReference reference) {
        if(!TravelersBackpackConfig.SERVER.backpackSettings.backSlotIntegration.get()) return;
        if(reference.entity() instanceof class_1657 player) {
            BackpackWrapper.tick(stack, player, true);
        }
    }

    @Environment(EnvType.CLIENT)
    public static class Renderer implements SimpleAccessoryRenderer {
        @Override
        public <S extends class_10042> void render(AccessoryRenderState accessoryState, S entityState, class_583<S> model, class_4587 matrices, class_11659 collector) {
            var stack = accessoryState.getStateData(AccessoriesRenderStateKeys.ITEM_STACK);
            var light = accessoryState.getStateData(AccessoriesRenderStateKeys.LIGHT);
            class_10444 backpackRenderState = new class_10444();
            StackModelPart tools = new StackModelPart();
            if(stack.method_7909() instanceof TravelersBackpackItem && model instanceof class_591 playerModel && entityState instanceof class_10055 playerRenderState) {
                BackpackLayer.renderBackpackLayer(playerModel, matrices, collector, light, playerRenderState, backpackRenderState, tools, stack);
            }
        }

        @Override
        public <S extends class_10042> void align(AccessoryRenderState accessoryRenderState, S s, class_583<S> entityModel, class_4587 poseStack) {

        }
    }
}