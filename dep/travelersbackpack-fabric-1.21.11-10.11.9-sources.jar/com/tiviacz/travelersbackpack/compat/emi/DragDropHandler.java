package com.tiviacz.travelersbackpack.compat.emi;

import com.google.common.collect.Maps;
import com.tiviacz.travelersbackpack.client.screens.BackpackScreen;
import com.tiviacz.travelersbackpack.common.ServerActions;
import com.tiviacz.travelersbackpack.inventory.menu.BackpackBaseMenu;
import com.tiviacz.travelersbackpack.inventory.menu.slot.FilterSlotItemHandler;
import com.tiviacz.travelersbackpack.network.ServerboundActionTagPacket;
import dev.emi.emi.api.EmiDragDropHandler;
import dev.emi.emi.api.stack.EmiIngredient;
import dev.emi.emi.api.stack.EmiStack;
import dev.emi.emi.api.widget.Bounds;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import net.minecraft.class_1799;
import net.minecraft.class_332;

public class DragDropHandler implements EmiDragDropHandler<BackpackScreen> {
    private final BiFunction<BackpackScreen, EmiIngredient, Map<Bounds, Consumer<EmiIngredient>>> bounds;

    public DragDropHandler() {
        this.bounds = (screen, ingredient) -> {
            Map<Bounds, Consumer<EmiIngredient>> map = Maps.newHashMap();
            if(ingredient.getEmiStacks().isEmpty()) {
                return map;
            }

            EmiStack emiGhostStack = ingredient.getEmiStacks().get(0);
            if(!emiGhostStack.isEmpty()) {
                class_1799 ghostStack = emiGhostStack.getItemStack();
                BackpackBaseMenu menu = screen.method_17577();
                menu.mappedSlots.values().forEach(list -> list.forEach(slot -> {
                    if(slot >= menu.field_7761.size()) {
                        return;
                    }
                    if(menu.method_7611(slot) instanceof FilterSlotItemHandler filterSlot && filterSlot.method_7680(ghostStack)) {
                        map.put(new Bounds(screen.getGuiLeft() + filterSlot.field_7873, screen.getGuiTop() + filterSlot.field_7872, 16, 16), (i) -> ServerboundActionTagPacket.create(ServerboundActionTagPacket.SET_STACK, ServerActions.SLOT, ghostStack, menu.method_7611(slot).field_7874));
                    }
                }));
            }
            return map;
        };
    }

    @Override
    public boolean dropStack(BackpackScreen backpackScreen, EmiIngredient emiIngredient, int x, int y) {
        Map<Bounds, Consumer<EmiIngredient>> bounds = this.bounds.apply(backpackScreen, emiIngredient);
        for(Bounds b : bounds.keySet()) {
            if(b.contains(x, y)) {
                bounds.get(b).accept(emiIngredient);
                return true;
            }
        }
        return false;
    }

    @Override
    public void render(BackpackScreen screen, EmiIngredient dragged, class_332 draw, int mouseX, int mouseY, float delta) {
        for(Bounds b : this.bounds.apply(screen, dragged).keySet()) {
            draw.method_25294(b.x(), b.y(), b.x() + b.width(), b.y() + b.height(), 0x8822BB33);
        }
    }
}