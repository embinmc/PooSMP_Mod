package com.tiviacz.travelersbackpack.compat.comforts;

import com.illusivesoulworks.comforts.common.block.SleepingBagBlock;
import com.illusivesoulworks.comforts.common.item.SleepingBagItem;
import net.minecraft.class_1767;
import net.minecraft.class_1792;

public class ComfortsCompat {
    public static int getComfortsSleepingBagColor(class_1792 item) {
        if(item instanceof SleepingBagItem sleepingBagItem && sleepingBagItem.method_7711() instanceof SleepingBagBlock sleepingBagBlock) {
            return sleepingBagBlock.method_9487().method_7789();
        }
        return class_1767.field_7964.method_7789();
    }
}