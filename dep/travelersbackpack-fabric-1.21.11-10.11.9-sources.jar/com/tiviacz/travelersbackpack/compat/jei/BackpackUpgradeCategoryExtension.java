package com.tiviacz.travelersbackpack.compat.jei;

import com.tiviacz.travelersbackpack.common.recipes.BackpackUpgradeRecipe;
import mezz.jei.api.gui.builder.IIngredientAcceptor;
import mezz.jei.api.recipe.category.extensions.vanilla.smithing.ISmithingCategoryExtension;
import mezz.jei.library.util.RecipeUtil;
import net.minecraft.class_10352;
import net.minecraft.class_10363;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_1937;
import net.minecraft.class_310;
import net.minecraft.class_9697;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public class BackpackUpgradeCategoryExtension implements ISmithingCategoryExtension<BackpackUpgradeRecipe> {
    @Override
    public <T extends IIngredientAcceptor<T>> void setTemplate(BackpackUpgradeRecipe recipe, T ingredientAcceptor) {
        Optional<class_1856> template = recipe.method_64722();
        Objects.requireNonNull(ingredientAcceptor);
        template.ifPresent(ingredientAcceptor::add);
    }

    public <T extends IIngredientAcceptor<T>> void setBase(BackpackUpgradeRecipe recipe, T ingredientAcceptor) {
        class_1856 base = recipe.method_64723();
        ingredientAcceptor.add(base);
    }

    public <T extends IIngredientAcceptor<T>> void setAddition(BackpackUpgradeRecipe recipe, T ingredientAcceptor) {
        Optional<class_1856> addition = recipe.method_64724();
        Objects.requireNonNull(ingredientAcceptor);
        addition.ifPresent(ingredientAcceptor::add);
    }

    public <T extends IIngredientAcceptor<T>> void setOutput(BackpackUpgradeRecipe recipe, T ingredientAcceptor) {
        Optional<class_1856> templateIngredient = recipe.method_64722();
        class_1856 baseIngredient = recipe.method_64723();
        Optional<class_1856> additionIngredient = recipe.method_64724();
        class_310 minecraft = class_310.method_1551();
        class_10352 contextmap = class_10363.method_65008((class_1937)Objects.requireNonNull(minecraft.field_1687));
        List<class_1799> templateStacks = (List)templateIngredient.map((i) -> i.method_64673().method_64738(contextmap)).orElse(List.of(class_1799.field_8037));
        if (templateStacks.isEmpty()) {
            templateStacks = List.of(class_1799.field_8037);
        }

        List<class_1799> baseStacks = baseIngredient.method_64673().method_64738(contextmap);
        if (baseStacks.isEmpty()) {
            baseStacks = List.of(class_1799.field_8037);
        }

        class_1799 addition = (class_1799)additionIngredient.map((i) -> i.method_64673().method_64742(contextmap)).orElse(class_1799.field_8037);

        for(class_1799 template : templateStacks) {
            for(class_1799 base : baseStacks) {
                class_9697 recipeInput = new class_9697(template, base, addition);
                class_1799 output = RecipeUtil.assembleResultItem(recipeInput, recipe);
                ingredientAcceptor.add(output);
            }
        }

    }
}