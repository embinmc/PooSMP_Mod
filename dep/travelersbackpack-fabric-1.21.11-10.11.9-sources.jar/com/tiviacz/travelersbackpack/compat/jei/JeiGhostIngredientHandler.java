package com.tiviacz.travelersbackpack.compat.jei;

import com.tiviacz.travelersbackpack.client.screens.BackpackScreen;
import com.tiviacz.travelersbackpack.common.ServerActions;
import com.tiviacz.travelersbackpack.inventory.menu.BackpackBaseMenu;
import com.tiviacz.travelersbackpack.inventory.menu.slot.FilterSlotItemHandler;
import com.tiviacz.travelersbackpack.network.ServerboundActionTagPacket;
import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.gui.handlers.IGhostIngredientHandler;
import mezz.jei.api.ingredients.ITypedIngredient;
import net.minecraft.class_768;
import java.util.ArrayList;
import java.util.List;

public class JeiGhostIngredientHandler implements IGhostIngredientHandler<BackpackScreen> {
    @Override
    public <I> List<Target<I>> getTargetsTyped(BackpackScreen screen, ITypedIngredient<I> ingredient, boolean doStart) {
        List<Target<I>> targets = new ArrayList<>();
        if(ingredient.getType() == VanillaTypes.ITEM_STACK) {
            BackpackBaseMenu menu = screen.method_17577();
            ingredient.getItemStack().ifPresent(ghostStack -> {
                menu.mappedSlots.values().forEach(list -> list.forEach(slot -> {
                    if(slot >= menu.field_7761.size()) {
                        return;
                    }
                    if(menu.method_7611(slot) instanceof FilterSlotItemHandler filterSlot && filterSlot.method_7680(ghostStack)) {
                        targets.add(new Target<>() {
                            @Override
                            public class_768 getArea() {
                                return new class_768(screen.getGuiLeft() + filterSlot.field_7873, screen.getGuiTop() + filterSlot.field_7872, 16, 16);
                            }

                            @Override
                            public void accept(I i) {
                                ServerboundActionTagPacket.create(ServerboundActionTagPacket.SET_STACK, ServerActions.SLOT, ghostStack, menu.method_7611(slot).field_7874);
                            }
                        });
                    }
                }));
            });
        }
        return targets;
    }

    @Override
    public void onComplete() {

    }
}