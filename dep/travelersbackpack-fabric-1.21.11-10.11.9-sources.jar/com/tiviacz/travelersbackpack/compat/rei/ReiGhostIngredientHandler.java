package com.tiviacz.travelersbackpack.compat.rei;

import com.tiviacz.travelersbackpack.client.screens.BackpackScreen;
import com.tiviacz.travelersbackpack.common.ServerActions;
import com.tiviacz.travelersbackpack.inventory.menu.BackpackBaseMenu;
import com.tiviacz.travelersbackpack.inventory.menu.slot.FilterSlotItemHandler;
import com.tiviacz.travelersbackpack.network.ServerboundActionTagPacket;
import me.shedaniel.math.Point;
import me.shedaniel.math.Rectangle;
import me.shedaniel.rei.api.client.gui.drag.*;
import me.shedaniel.rei.api.common.entry.type.VanillaEntryTypes;
import net.minecraft.class_1799;
import net.minecraft.class_238;
import net.minecraft.class_265;
import net.minecraft.class_437;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Stream;

public class ReiGhostIngredientHandler implements DraggableStackVisitor<BackpackScreen> {
    @Override
    public DraggedAcceptorResult acceptDraggedStack(DraggingContext<BackpackScreen> context, DraggableStack stack) {
        Point cursor = context.getCurrentPosition();
        if(cursor != null) {
            Optional<BackpackBoundsProvider> target = getDraggableAcceptingBounds(context, stack)
                    .map(BackpackBoundsProvider.class::cast)
                    .filter(b -> b.contains(cursor.getX(), cursor.getY()))
                    .findFirst();
            if(target.isPresent()) {
                target.get().accept();
                return DraggedAcceptorResult.CONSUMED;
            }
        }
        return DraggableStackVisitor.super.acceptDraggedStack(context, stack);
    }

    @Override
    public Stream<BoundsProvider> getDraggableAcceptingBounds(DraggingContext<BackpackScreen> context, DraggableStack stack) {
        List<BoundsProvider> targets = new ArrayList<>();
        BackpackScreen screen = context.getScreen();

        if(stack.getStack().getType() == VanillaEntryTypes.ITEM) {
            BackpackBaseMenu menu = context.getScreen().method_17577();
            if(stack.getStack().getValue() instanceof class_1799 ghostStack) {
                menu.mappedSlots.values().forEach(list -> list.forEach(slot -> {
                    if(slot >= menu.field_7761.size()) {
                        return;
                    }
                    if(menu.method_7611(slot) instanceof FilterSlotItemHandler filterSlot && filterSlot.method_7680(ghostStack)) {
                        targets.add(new BackpackBoundsProvider() {
                            @Override
                            public class_265 bounds() {
                                return DraggableBoundsProvider.fromRectangle(new Rectangle(screen.getGuiLeft() + filterSlot.field_7873, screen.getGuiTop() + filterSlot.field_7872, 16, 16));
                            }

                            @Override
                            public void accept() {
                                ServerboundActionTagPacket.create(ServerboundActionTagPacket.SET_STACK, ServerActions.SLOT, ghostStack, menu.method_7611(slot).field_7874);
                            }
                        });
                    }
                }));
            }
        }
        return targets.stream();
    }

    @Override
    public <R extends class_437> boolean isHandingScreen(R screen) {
        return screen instanceof BackpackScreen;
    }

    public abstract class BackpackBoundsProvider implements BoundsProvider {
        public BackpackBoundsProvider() {
        }

        public abstract void accept();

        public boolean contains(int x, int y) {
            class_238 box = bounds().method_1107();
            return box.method_1008(x, y, box.field_1321);
        }
    }
}