package com.tiviacz.travelersbackpack.compat.vinurl;

import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.vinurl.api.VinURLSound;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record ServerboundVinURLStartPacket(class_1799 stack) implements class_8710 {
    public static final class_9154<ServerboundVinURLStartPacket> TYPE = new class_9154<>(class_2960.method_60655(TravelersBackpack.MODID, "start_vinurl"));

    public static final class_9139<class_9129, ServerboundVinURLStartPacket> STREAM_CODEC =
            class_9139.method_56434(
                    class_1799.field_48349, ServerboundVinURLStartPacket::stack,
                    ServerboundVinURLStartPacket::new
            );


    public static void handle(ServerboundVinURLStartPacket message, ServerPlayNetworking.Context ctx) {
        ctx.server().execute(() -> {
            if(TravelersBackpack.vinurlLoaded) {
                if(ctx.player().method_51469() instanceof class_3218 serverLevel) {
                    VinURLSound.playFor(serverLevel, message.stack, ctx.player().method_5667());
                }
            }
        });
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}