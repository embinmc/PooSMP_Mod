package com.tiviacz.travelersbackpack.compat.vinurl;

import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.vinurl.api.VinURLSound;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record ServerboundVinURLStopPacket(class_1799 stack, boolean cancelable) implements class_8710 {
    public static final class_9154<ServerboundVinURLStopPacket> TYPE = new class_9154<>(class_2960.method_60655(TravelersBackpack.MODID, "stop_vinurl"));

    public static final class_9139<class_9129, ServerboundVinURLStopPacket> STREAM_CODEC =
            class_9139.method_56435(
                    class_1799.field_48349, ServerboundVinURLStopPacket::stack,
                    class_9135.field_48547, ServerboundVinURLStopPacket::cancelable,
                    ServerboundVinURLStopPacket::new
            );


    public static void handle(ServerboundVinURLStopPacket message, ServerPlayNetworking.Context ctx) {
        ctx.server().execute(() -> {
            if(TravelersBackpack.vinurlLoaded) {
                if(ctx.player().method_51469() instanceof class_3218 serverLevel) {
                    VinURLSound.stopFor(serverLevel, message.stack, ctx.player().method_5667(), message.cancelable);
                }
            }
        });
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}