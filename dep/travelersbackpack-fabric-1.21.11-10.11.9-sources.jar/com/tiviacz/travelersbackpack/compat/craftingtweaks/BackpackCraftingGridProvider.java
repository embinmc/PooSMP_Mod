package com.tiviacz.travelersbackpack.compat.craftingtweaks;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.HashMultiset;
import com.google.common.collect.Multiset;
import com.tiviacz.travelersbackpack.inventory.menu.BackpackBaseMenu;
import com.tiviacz.travelersbackpack.inventory.upgrades.crafting.CraftingUpgrade;
import net.blay09.mods.craftingtweaks.api.*;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.class_9326;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

public class BackpackCraftingGridProvider implements CraftingGridProvider {
    @Override
    public String getModId() {
        return "travelersbackpack";
    }

    @Override
    public boolean requiresServerSide() {
        return true;
    }

    @Override
    public boolean handles(class_1703 menu) {
        return menu instanceof BackpackBaseMenu;
    }

    @Override
    public void buildCraftingGrids(CraftingGridBuilder craftingGridBuilder, class_1703 abstractContainerMenu) {
        if(abstractContainerMenu instanceof BackpackBaseMenu backpackMenu) {
            craftingGridBuilder.addGrid(backpackMenu.CRAFTING_GRID_START, 9).setButtonAlignment(ButtonAlignment.RIGHT)
                    .clearHandler(this::clearGrid).rotateHandler(this::rotateGrid)
                    .balanceHandler(new BackpackBalanceGridHandler()).transferHandler(new BackpackTransferGridHandler())
                    .hideAllTweakButtons();
        }
    }

    public void clearGrid(CraftingGrid grid, class_1657 player, class_1703 menu, boolean forced) {
        if(!(menu instanceof BackpackBaseMenu backpackMenu)) {
            return;
        }
        Optional<CraftingUpgrade> upgrade = backpackMenu.getWrapper().getUpgradeManager().getUpgrade(CraftingUpgrade.class);
        if(upgrade.isEmpty() || !upgrade.get().isTabOpened()) {
            return;
        }

        class_1263 craftMatrix = grid.getCraftingMatrix(player, menu);
        if(craftMatrix != null) {
            int start = grid.getGridStartSlot(player, menu);
            int size = grid.getGridSize(player, menu);

            for(int i = start; i < start + size; ++i) {
                int slotIndex = menu.field_7761.get(i).method_34266();
                class_1799 itemStack = craftMatrix.method_5438(slotIndex);
                if(!itemStack.method_7960()) {
                    class_1799 returnStack = itemStack.method_7972();
                    player.method_31548().method_7394(returnStack);
                    craftMatrix.method_5447(slotIndex, returnStack.method_7947() == 0 ? class_1799.field_8037 : returnStack);
                    if(returnStack.method_7947() > 0 && forced) {
                        player.method_7328(returnStack, false);
                        craftMatrix.method_5447(slotIndex, class_1799.field_8037);
                    }
                }
            }
            menu.method_7623();
        }
    }

    protected boolean ignoresSlotId(int slotId) {
        return slotId == 4;
    }

    protected int rotateSlotId(int slotId, boolean counterClockwise) {
        if(!counterClockwise) {
            switch(slotId) {
                case 0:
                    return 1;
                case 1:
                    return 2;
                case 2:
                    return 5;
                case 3:
                    return 0;
                case 4:
                default:
                    break;
                case 5:
                    return 8;
                case 6:
                    return 3;
                case 7:
                    return 6;
                case 8:
                    return 7;
            }
        } else {
            switch(slotId) {
                case 0:
                    return 3;
                case 1:
                    return 0;
                case 2:
                    return 1;
                case 3:
                    return 6;
                case 4:
                default:
                    break;
                case 5:
                    return 2;
                case 6:
                    return 7;
                case 7:
                    return 8;
                case 8:
                    return 5;
            }
        }

        return 0;
    }

    public void rotateGrid(CraftingGrid grid, class_1657 player, class_1703 menu, boolean reverse) {
        if(!(menu instanceof BackpackBaseMenu backpackMenu)) {
            return;
        }
        Optional<CraftingUpgrade> upgrade = backpackMenu.getWrapper().getUpgradeManager().getUpgrade(CraftingUpgrade.class);
        if(upgrade.isEmpty() || !upgrade.get().isTabOpened()) {
            return;
        }

        class_1263 craftMatrix = grid.getCraftingMatrix(player, menu);
        if(craftMatrix != null) {
            int start = grid.getGridStartSlot(player, menu);
            int size = grid.getGridSize(player, menu);
            class_1263 matrixClone = new class_1277(size);

            for(int i = 0; i < size; ++i) {
                int slotIndex = menu.field_7761.get(start + i).method_34266();
                matrixClone.method_5447(i, craftMatrix.method_5438(slotIndex));
            }

            for(int i = 0; i < size; ++i) {
                if(!this.ignoresSlotId(i)) {
                    int slotIndex = menu.field_7761.get(start + this.rotateSlotId(i, reverse)).method_34266();
                    craftMatrix.method_5447(slotIndex, matrixClone.method_5438(i));
                }
            }

            menu.method_7623();
        }
    }

    public static class BackpackBalanceGridHandler implements GridBalanceHandler<class_1703> {

        @Override
        public void balanceGrid(CraftingGrid grid, class_1657 player, class_1703 menu) {
            if(!(menu instanceof BackpackBaseMenu backpackMenu)) {
                return;
            }
            Optional<CraftingUpgrade> upgrade = backpackMenu.getWrapper().getUpgradeManager().getUpgrade(CraftingUpgrade.class);
            if(upgrade.isEmpty() || !upgrade.get().isTabOpened()) {
                return;
            }

            class_1263 craftMatrix = grid.getCraftingMatrix(player, menu);
            if(craftMatrix != null) {
                ArrayListMultimap<String, Integer> itemMap = ArrayListMultimap.create();
                Multiset<String> itemCount = HashMultiset.create();
                int start = grid.getGridStartSlot(player, menu);
                int size = grid.getGridSize(player, menu);

                for(int i = start; i < start + size; ++i) {
                    int slotIndex = menu.field_7761.get(i).method_34266();
                    class_1799 itemStack = craftMatrix.method_5438(slotIndex);
                    if(!itemStack.method_7960() && itemStack.method_7914() > 1) {
                        class_2960 registryName = class_7923.field_41178.method_10221(itemStack.method_7909());
                        String key = Objects.toString(registryName);
                        class_9326 componentsPatch = itemStack.method_57380();
                        if(!componentsPatch.method_57848()) {
                            key = key + "@" + componentsPatch;
                        }

                        itemMap.put(key, slotIndex);
                        itemCount.add(key, itemStack.method_7947());
                    }
                }

                for(String key : itemMap.keySet()) {
                    List<Integer> balanceList = itemMap.get(key);
                    int totalCount = itemCount.count(key);
                    int countPerStack = totalCount / balanceList.size();
                    int restCount = totalCount % balanceList.size();

                    for(int index : balanceList) {
                        class_1799 stack = craftMatrix.method_5438(index);
                        stack.method_7939(countPerStack);
                        craftMatrix.method_5447(index, stack);
                    }

                    int idx = 0;

                    while(restCount > 0) {
                        int index = balanceList.get(idx);
                        class_1799 stack = craftMatrix.method_5438(index);
                        if(stack.method_7947() < stack.method_7914()) {
                            class_1799 copy = stack.method_7972();
                            copy.method_7933(1);
                            craftMatrix.method_5447(index, copy);
                            //itemStack.grow(1);
                            --restCount;
                        }

                        ++idx;
                        if(idx >= balanceList.size()) {
                            idx = 0;
                        }
                    }
                }

                menu.method_7623();
            }
        }

        @Override
        public void spreadGrid(CraftingGrid grid, class_1657 player, class_1703 menu) {
            if(!(menu instanceof BackpackBaseMenu backpackMenu)) {
                return;
            }
            Optional<CraftingUpgrade> upgrade = backpackMenu.getWrapper().getUpgradeManager().getUpgrade(CraftingUpgrade.class);
            if(upgrade.isEmpty() || !upgrade.get().isTabOpened()) {
                return;
            }

            class_1263 craftMatrix = grid.getCraftingMatrix(player, menu);
            if(craftMatrix != null) {
                boolean emptyBiggestSlot;
                do {
                    class_1799 biggestSlotStack = null;
                    int biggestSlotStackSlot = 0;
                    int biggestSlotSize = 1;
                    int start = grid.getGridStartSlot(player, menu);
                    int size = grid.getGridSize(player, menu);

                    for(int i = start; i < start + size; ++i) {
                        int slotIndex = menu.field_7761.get(i).method_34266();
                        class_1799 itemStack = craftMatrix.method_5438(slotIndex);
                        if(!itemStack.method_7960() && itemStack.method_7947() > biggestSlotSize) {
                            biggestSlotStack = itemStack;
                            biggestSlotStackSlot = slotIndex;
                            biggestSlotSize = itemStack.method_7947();
                        }
                    }

                    if(biggestSlotStack == null) {
                        return;
                    }

                    emptyBiggestSlot = false;

                    for(int i = start; i < start + size; ++i) {
                        int slotIndex = menu.field_7761.get(i).method_34266();
                        class_1799 itemStack = craftMatrix.method_5438(slotIndex);
                        if(itemStack.method_7960()) {
                            if(biggestSlotStack.method_7947() > 1) {
                                class_1799 splitted = biggestSlotStack.method_7971(1);
                                craftMatrix.method_5447(biggestSlotStackSlot, biggestSlotStack);
                                craftMatrix.method_5447(slotIndex, splitted);
                            } else {
                                emptyBiggestSlot = true;
                            }
                        }
                    }
                } while(emptyBiggestSlot);

                this.balanceGrid(grid, player, menu);
            }
        }
    }

    public static class BackpackTransferGridHandler implements GridTransferHandler<class_1703> {
        @Override
        public class_1799 putIntoGrid(CraftingGrid grid, class_1657 player, class_1703 menu, int slotId, class_1799 itemStack) {
            class_1263 craftMatrix = grid.getCraftingMatrix(player, menu);
            if(craftMatrix == null) {
                return itemStack;
            } else {
                class_1799 craftStack = craftMatrix.method_5438(slotId).method_7972();
                if(!craftStack.method_7960()) {
                    if(class_1799.method_31577(craftStack, itemStack)) {
                        int spaceLeft = Math.min(craftMatrix.method_5444(), craftStack.method_7914()) - craftStack.method_7947();
                        if(spaceLeft > 0) {
                            class_1799 splitStack = itemStack.method_7971(Math.min(spaceLeft, itemStack.method_7947()));
                            craftStack.method_7933(splitStack.method_7947());
                            craftMatrix.method_5447(slotId, craftStack);
                            if(itemStack.method_7947() <= 0) {
                                return class_1799.field_8037;
                            }
                        }
                    }
                } else {
                    class_1799 transferStack = itemStack.method_7971(Math.min(itemStack.method_7947(), craftMatrix.method_5444()));
                    craftMatrix.method_5447(slotId, transferStack);
                }

                return itemStack.method_7947() <= 0 ? class_1799.field_8037 : itemStack;
            }
        }

        @Override
        public boolean transferIntoGrid(CraftingGrid grid, class_1657 player, class_1703 menu, class_1735 fromSlot) {
            class_1263 craftMatrix = grid.getCraftingMatrix(player, menu);
            if(craftMatrix == null) {
                return false;
            } else {
                int start = grid.getGridStartSlot(player, menu);
                int size = grid.getGridSize(player, menu);
                class_1799 itemStack = fromSlot.method_7677();
                if(itemStack.method_7960()) {
                    return false;
                } else {
                    int firstEmptySlot = -1;

                    for(int i = start; i < start + size; ++i) {
                        int slotIndex = menu.field_7761.get(i).method_34266();
                        class_1799 craftStack = craftMatrix.method_5438(slotIndex).method_7972();
                        if(!craftStack.method_7960()) {
                            if(class_1799.method_31577(craftStack, itemStack)) {
                                int spaceLeft = Math.min(craftMatrix.method_5444(), craftStack.method_7914()) - craftStack.method_7947();
                                if(spaceLeft > 0) {
                                    class_1799 splitStack = itemStack.method_7971(Math.min(spaceLeft, itemStack.method_7947()));
                                    craftStack.method_7933(splitStack.method_7947());
                                    craftMatrix.method_5447(slotIndex, craftStack);
                                    if(itemStack.method_7947() <= 0) {
                                        return true;
                                    }
                                }
                            }
                        } else if(firstEmptySlot == -1) {
                            firstEmptySlot = slotIndex;
                        }
                    }

                    if(itemStack.method_7947() > 0 && firstEmptySlot != -1) {
                        class_1799 transferStack = itemStack.method_7971(Math.min(itemStack.method_7947(), craftMatrix.method_5444()));
                        craftMatrix.method_5447(firstEmptySlot, transferStack);
                        return true;
                    } else {
                        return false;
                    }
                }
            }
        }

        @Override
        public boolean canTransferFrom(class_1657 player, class_1703 abstractContainerMenu, class_1735 slot, CraftingGrid craftingGrid) {
            if(abstractContainerMenu instanceof BackpackBaseMenu menu) {
                Optional<CraftingUpgrade> upgrade = menu.getWrapper().getUpgradeManager().getUpgrade(CraftingUpgrade.class);
                if(upgrade.isEmpty() || !upgrade.get().isTabOpened()) {
                    return false;
                }
                if(slot.method_7674(player)) {
                    return slot.field_7871 == player.method_31548() || slot.field_7874 < menu.BACKPACK_INV_END;
                }
            }
            return false;
        }
    }
}