package com.tiviacz.travelersbackpack.compat.craftingtweaks;

import com.tiviacz.travelersbackpack.client.screens.BackpackScreen;
import com.tiviacz.travelersbackpack.inventory.upgrades.crafting.CraftingWidget;
import net.blay09.mods.craftingtweaks.CraftingTweaksProviderManager;
import net.blay09.mods.craftingtweaks.api.CraftingTweaksClientAPI;
import net.blay09.mods.craftingtweaks.api.TweakType;
import net.minecraft.class_1735;
import net.minecraft.class_339;
import java.util.ArrayList;
import java.util.List;

public class BackpackCraftingGridAddition implements ICraftingTweaks {
    private BackpackScreen screen;
    private final List<class_339> widgets = new ArrayList<>();

    public static void registerCraftingTweaksAddition() {
        CraftingWidget.setCraftingTweaksAddition(new BackpackCraftingGridAddition());
    }

    private void addButton(class_339 widget) {
        widgets.add(widget);
        screen.addCompatWidget(widget);
    }

    @Override
    public void onCraftingSlotsHidden() {
        if(widgets.isEmpty()) {
            return;
        }
        widgets.forEach(screen::removeCompatWidget);
        widgets.clear();
    }

    @Override
    public void onCraftingSlotsDisplayed() {
        class_1735 thirdSlot = screen.method_17577().method_7611(screen.method_17577().CRAFTING_GRID_START + 2);
        CraftingTweaksProviderManager.getDefaultCraftingGrid(screen.method_17577()).ifPresent(craftingGrid -> {
            addButton(CraftingTweaksClientAPI.createTweakButtonRelative(craftingGrid, screen, getButtonX(thirdSlot), getButtonY(thirdSlot, 0), TweakType.Rotate));
            addButton(CraftingTweaksClientAPI.createTweakButtonRelative(craftingGrid, screen, getButtonX(thirdSlot), getButtonY(thirdSlot, 1), TweakType.Balance));
            addButton(CraftingTweaksClientAPI.createTweakButtonRelative(craftingGrid, screen, getButtonX(thirdSlot), getButtonY(thirdSlot, 2), TweakType.Clear));
        });
    }

    @Override
    public void setScreen(BackpackScreen screen) {
        this.screen = screen;
    }

    private int getButtonX(class_1735 thirdSlot) {
        return thirdSlot.field_7873 + 19;
    }

    private int getButtonY(class_1735 thirdSlot, int index) {
        return thirdSlot.field_7872 + 18 * index;
    }
}