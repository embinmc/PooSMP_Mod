package com.tiviacz.travelersbackpack.compat.pneumonogravestones;

import com.mojang.serialization.DataResult;
import com.mojang.serialization.DynamicOps;
import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.tiviacz.travelersbackpack.attachment.AttachmentUtils;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.pneumono.gravestones.api.GravestoneDataType;
import net.pneumono.gravestones.multiversion.VersionUtil;

import java.util.Optional;

public class BackpackDataType extends GravestoneDataType {
    private static final String KEY = "travelersbackpack";

    @Override
    public void writeData(class_2487 nbt, DynamicOps<class_2520> ops, class_1657 player) {
        if(TravelersBackpack.enableIntegration()) return;
        AttachmentUtils.getAttachment(player).ifPresent(component -> {
            if(component.hasBackpack()) {
                DataResult<class_2520> result = class_1799.field_49266.encodeStart(ops, component.getBackpack());
                nbt.method_10566(KEY, (class_2520)result.result().orElseThrow());
                component.remove(player);
            }
        });
    }

    @Override
    public void onBreak(class_2487 nbt, DynamicOps<class_2520> ops, class_1937 world, class_2338 pos, int decay) {
        Optional<class_1799> optional = VersionUtil.get(ops, nbt, KEY, class_1799.field_49266);
        optional.ifPresent(backpack -> this.dropStack(world, pos, backpack));
    }

    public void onCollect(class_2487 nbt, DynamicOps<class_2520> ops, class_1937 world, class_2338 pos, class_1657 player, int decay) {
        if(TravelersBackpack.enableIntegration()) return;
        Optional<class_1799> optional = VersionUtil.get(ops, nbt, KEY, class_1799.field_49266);

        optional.ifPresent(backpack -> {
            if(!AttachmentUtils.isWearingBackpack(player)) {
                AttachmentUtils.equipBackpack(player, backpack);
            } else {
                this.dropStack(player, backpack);
            }
        });
    }
}