package com.tiviacz.travelersbackpack.entity;

import com.tiviacz.travelersbackpack.config.TravelersBackpackConfig;
import net.minecraft.class_11978;
import net.minecraft.class_1299;
import net.minecraft.class_1542;
import net.minecraft.class_1927;
import net.minecraft.class_1937;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_3532;

public class BackpackItemEntity extends class_1542 {
    public boolean wasFloatingUp = false;
    public boolean isInvulnerable;

    public BackpackItemEntity(class_1299<? extends class_1542> entityType, class_1937 level) {
        super(entityType, level);
        this.field_7204 = Integer.MAX_VALUE;
        this.isInvulnerable = TravelersBackpackConfig.SERVER.backpackSettings.invulnerableBackpack.get();
    }

    @Override
    public void method_5773() {
        if(TravelersBackpackConfig.SERVER.backpackSettings.voidProtection.get()) {
            if(!this.method_73183().method_8608() && !method_5740() && wasFloatingUp && method_23318() < method_73183().method_31607()) {
                if(field_5974.method_43057() > 0.25F) {
                    float ab = field_5974.method_43057() * 2.0f;
                    float ag = field_5974.method_43057() * ((float)Math.PI * 2);
                    double n = class_3532.method_15362(ag) * ab;
                    double o = 0.01 + field_5974.method_43058() * 0.5;
                    double p = class_3532.method_15374(ag) * ab;
                    ((class_3218)method_73183()).method_65096(class_11978.method_74410(class_2398.field_11216, 1.0F), method_73189().method_10216() + n * 0.1, method_73189().method_10214() + 0.3, method_73189().method_10215() + p * 0.1, 0, n * 0.01F, o * 0.1F, p * 0.01F, 1.0F);
                }
            }
            if(!method_5740()) {
                if(method_5799() || method_5771()) {
                    method_5764(false);
                    wasFloatingUp = true;
                } else if(wasFloatingUp) {
                    method_5875(true);
                    method_18799(class_243.field_1353);
                }
            }
        }
        super.method_5773();
    }

    @Override
    public boolean method_5799() {
        if(TravelersBackpackConfig.SERVER.backpackSettings.voidProtection.get()) {
            return method_23318() < method_73183().method_31607() + 1 || super.method_5799();
        }
        return super.method_5799();
    }

    @Override
    public boolean method_5753() {
        return this.isInvulnerable;
    }

    @Override
    public boolean method_5659(class_1927 explosion) {
        return this.isInvulnerable;
    }

    @Override
    public boolean method_5655() {
        return this.isInvulnerable;
    }

    @Override
    protected void method_5825() {
        if(!TravelersBackpackConfig.SERVER.backpackSettings.voidProtection.get()) {
            this.method_31472();
        }
    }
}