package com.tiviacz.travelersbackpack;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import com.tiviacz.travelersbackpack.blockentity.BackpackBlockEntity;
import com.tiviacz.travelersbackpack.client.model.BackpackDynamicModel;
import com.tiviacz.travelersbackpack.client.model.BackpackItemModel;
import com.tiviacz.travelersbackpack.client.model.StarModelReloadListener;
import com.tiviacz.travelersbackpack.client.renderer.BackpackEntityLayer;
import com.tiviacz.travelersbackpack.client.renderer.BackpackLayer;
import com.tiviacz.travelersbackpack.client.renderer.HoseSpecialRenderer;
import com.tiviacz.travelersbackpack.client.screens.BackpackScreen;
import com.tiviacz.travelersbackpack.client.screens.BackpackSettingsScreen;
import com.tiviacz.travelersbackpack.client.screens.HudOverlay;
import com.tiviacz.travelersbackpack.client.screens.tooltip.BackpackTooltipComponent;
import com.tiviacz.travelersbackpack.client.screens.tooltip.ClientBackpackTooltipComponent;
import com.tiviacz.travelersbackpack.commands.BackpackIconCommands;
import com.tiviacz.travelersbackpack.compat.accessories.TravelersBackpackAccessory;
import com.tiviacz.travelersbackpack.compat.craftingtweaks.CraftingTweaksCompat;
import com.tiviacz.travelersbackpack.compat.polymorph.PolymorphCompat;
import com.tiviacz.travelersbackpack.compat.trashslot.TrashSlotCompat;
import com.tiviacz.travelersbackpack.compat.trinkets.TravelersBackpackTrinket;
import com.tiviacz.travelersbackpack.components.RenderInfo;
import com.tiviacz.travelersbackpack.config.TravelersBackpackConfig;
import com.tiviacz.travelersbackpack.fluids.potion.PotionFluidVariantAttributeHandler;
import com.tiviacz.travelersbackpack.fluids.potion.PotionFluidVariantRenderHandler;
import com.tiviacz.travelersbackpack.handlers.KeybindHandler;
import com.tiviacz.travelersbackpack.handlers.ScreenRenderHandler;
import com.tiviacz.travelersbackpack.init.*;
import com.tiviacz.travelersbackpack.item.TravelersBackpackItem;
import fuzs.forgeconfigapiport.fabric.api.v5.ConfigRegistry;
import fuzs.forgeconfigapiport.fabric.api.v5.client.ConfigScreenFactoryRegistry;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.model.loading.v1.*;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandlerRegistry;
import net.fabricmc.fabric.api.client.render.fluid.v1.SimpleFluidRenderHandler;
import net.fabricmc.fabric.api.client.rendering.v1.*;
import net.fabricmc.fabric.api.resource.ResourceManagerHelper;
import net.fabricmc.fabric.api.transfer.v1.client.fluid.FluidVariantRendering;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariantAttributes;
import net.minecraft.class_1007;
import net.minecraft.class_10401;
import net.minecraft.class_10402;
import net.minecraft.class_10443;
import net.minecraft.class_1087;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_3264;
import net.minecraft.class_3929;
import net.minecraft.class_5699;
import net.minecraft.class_572;
import net.minecraft.class_638;
import net.minecraft.class_916;
import net.minecraft.class_922;
import net.minecraft.class_9282;
import net.minecraft.class_9334;
import net.minecraft.class_9848;
import net.neoforged.fml.config.ModConfig;
import net.neoforged.neoforge.client.gui.ConfigurationScreen;
import org.jetbrains.annotations.Nullable;

@Environment(EnvType.CLIENT)
public class TravelersBackpackClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        //Register client config
        ConfigRegistry.INSTANCE.register(TravelersBackpack.MODID, ModConfig.Type.CLIENT, TravelersBackpackConfig.clientSpec);
        ConfigScreenFactoryRegistry.INSTANCE.register(TravelersBackpack.MODID, ConfigurationScreen::new);

        //Load render types
        BackpackDynamicModel.Loader.loadVanillaRenderTypes();

        //Handled Screens
        class_3929.method_17542(ModScreenHandlerTypes.BACKPACK_MENU, BackpackScreen::new);
        class_3929.method_17542(ModScreenHandlerTypes.BACKPACK_BLOCK_MENU, BackpackScreen::new);
        class_3929.method_17542(ModScreenHandlerTypes.BACKPACK_SETTINGS_MENU, BackpackSettingsScreen::new);

        //Feature renderers
        registerFeatureRenderers();

        //Builtin Item Renderer
        registerSpecialRenderers();

        //Hud Overlay
        registerHudOverlay();

        //Backpack Tooltip
        registerTooltipComponent();

        //Keybindings
        KeybindHandler.initKeybinds();
        KeybindHandler.registerListener();

        //Client Network
        ModNetwork.initClient();

        //Fluids Rendering
        setupFluidRendering();

        //Backpack Item Entity
        registerBackpackItemEntityRenderer();

        //Client Commands
        registerClientCommands();

        //Polymorph Integration
        if(TravelersBackpack.polymorphLoaded) PolymorphCompat.registerWidget();
        if(TravelersBackpack.trashSlotLoaded) TrashSlotCompat.register();

        //Backpack Model Deserializer
        UnbakedModelDeserializer.register(class_2960.method_60655(TravelersBackpack.MODID, "backpack"), BackpackDynamicModel.Loader.INSTANCE);
        CustomUnbakedBlockStateModel.register(BackpackDynamicModel.UnbakedBlockStateModel.ID, BackpackDynamicModel.UnbakedBlockStateModel.CODEC);
        registerCustomModels();

        //Register Color Providers
        registerBlockColorProvider();
        registerItemColorProvider();

        //Load Supporter Star Model
        ResourceManagerHelper.get(class_3264.field_14188).registerReloadListener(StarModelReloadListener.INSTANCE);

        //Screen Handlers
        ScreenRenderHandler.registerScreenEvents();

        //Crafting Tweaks Integration
        if(TravelersBackpack.craftingTweaksLoaded) CraftingTweaksCompat.registerCraftingTweaksAdditionClient();
        if(TravelersBackpack.accessoriesLoaded) TravelersBackpackAccessory.initClient();
        if(TravelersBackpack.trinketsLoaded && !TravelersBackpack.accessoriesLoaded)
            TravelersBackpackTrinket.initClient();
    }

    public static final class_2960 STAR_MODEL = class_2960.method_60655(TravelersBackpack.MODID, "block/supporter_star");
    public static final ExtraModelKey<class_1087> STAR_MODEL_KEY = ExtraModelKey.create(STAR_MODEL::toString);

    public static final class_2960 BACKPACK_BASE = class_2960.method_60655(TravelersBackpack.MODID, "block/backpack_base");
    public static final ExtraModelKey<class_1087> BACKPACK_BASE_KEY = ExtraModelKey.create(BACKPACK_BASE::toString);
    public static final class_2960 BACKPACK_BASE_DYED = class_2960.method_60655(TravelersBackpack.MODID, "block/backpack_base_dyed");
    public static final ExtraModelKey<class_1087> BACKPACK_BASE_DYED_KEY = ExtraModelKey.create(BACKPACK_BASE_DYED::toString);
    public static final class_2960 BACKPACK_EXTRAS = class_2960.method_60655(TravelersBackpack.MODID, "block/backpack_extras");
    public static final ExtraModelKey<class_1087> BACKPACK_EXTRAS_KEY = ExtraModelKey.create(BACKPACK_EXTRAS::toString);
    public static final class_2960 BACKPACK_FOX_NOSE = class_2960.method_60655(TravelersBackpack.MODID, "block/backpack_fox_nose");
    public static final ExtraModelKey<class_1087> BACKPACK_FOX_NOSE_KEY = ExtraModelKey.create(BACKPACK_FOX_NOSE::toString);
    public static final class_2960 BACKPACK_OCELOT_NOSE = class_2960.method_60655(TravelersBackpack.MODID, "block/backpack_ocelot_nose");
    public static final ExtraModelKey<class_1087> BACKPACK_OCELOT_NOSE_KEY = ExtraModelKey.create(BACKPACK_OCELOT_NOSE::toString);
    public static final class_2960 BACKPACK_PIG_NOSE = class_2960.method_60655(TravelersBackpack.MODID, "block/backpack_pig_nose");
    public static final ExtraModelKey<class_1087> BACKPACK_PIG_NOSE_KEY = ExtraModelKey.create(BACKPACK_PIG_NOSE::toString);
    public static final class_2960 BACKPACK_SLEEPING_BAG = class_2960.method_60655(TravelersBackpack.MODID, "block/backpack_sleeping_bag");
    public static final ExtraModelKey<class_1087> BACKPACK_SLEEPING_BAG_KEY = ExtraModelKey.create(BACKPACK_SLEEPING_BAG::toString);
    public static final class_2960 BACKPACK_SLEEPING_BAG_EXTRAS = class_2960.method_60655(TravelersBackpack.MODID, "block/backpack_sleeping_bag_extras");
    public static final ExtraModelKey<class_1087> BACKPACK_SLEEPING_BAG_EXTRAS_KEY = ExtraModelKey.create(BACKPACK_SLEEPING_BAG_EXTRAS::toString);
    public static final class_2960 BACKPACK_TANKS = class_2960.method_60655(TravelersBackpack.MODID, "block/backpack_tanks");
    public static final ExtraModelKey<class_1087> BACKPACK_TANKS_KEY = ExtraModelKey.create(BACKPACK_TANKS::toString);
    public static final class_2960 BACKPACK_VILLAGER_NOSE = class_2960.method_60655(TravelersBackpack.MODID, "block/backpack_villager_nose");
    public static final ExtraModelKey<class_1087> BACKPACK_VILLAGER_NOSE_KEY = ExtraModelKey.create(BACKPACK_VILLAGER_NOSE::toString);
    public static final class_2960 BACKPACK_WARDEN_HORNS = class_2960.method_60655(TravelersBackpack.MODID, "block/backpack_warden_horns");
    public static final ExtraModelKey<class_1087> BACKPACK_WARDEN_HORNS_KEY = ExtraModelKey.create(BACKPACK_WARDEN_HORNS::toString);
    public static final class_2960 BACKPACK_WOLF_NOSE = class_2960.method_60655(TravelersBackpack.MODID, "block/backpack_wolf_nose");
    public static final ExtraModelKey<class_1087> BACKPACK_WOLF_NOSE_KEY = ExtraModelKey.create(BACKPACK_WOLF_NOSE::toString);

    public static void registerCustomModels() {
        ModelLoadingPlugin.register(pluginContext -> {
            pluginContext.addModel(STAR_MODEL_KEY, SimpleUnbakedExtraModel.blockStateModel(STAR_MODEL));

            pluginContext.addModel(BACKPACK_BASE_KEY, SimpleUnbakedExtraModel.blockStateModel(BACKPACK_BASE));
            pluginContext.addModel(BACKPACK_BASE_DYED_KEY, SimpleUnbakedExtraModel.blockStateModel(BACKPACK_BASE_DYED));
            pluginContext.addModel(BACKPACK_EXTRAS_KEY, SimpleUnbakedExtraModel.blockStateModel(BACKPACK_EXTRAS));
            pluginContext.addModel(BACKPACK_FOX_NOSE_KEY, SimpleUnbakedExtraModel.blockStateModel(BACKPACK_FOX_NOSE));
            pluginContext.addModel(BACKPACK_OCELOT_NOSE_KEY, SimpleUnbakedExtraModel.blockStateModel(BACKPACK_OCELOT_NOSE));
            pluginContext.addModel(BACKPACK_PIG_NOSE_KEY, SimpleUnbakedExtraModel.blockStateModel(BACKPACK_PIG_NOSE));
            pluginContext.addModel(BACKPACK_SLEEPING_BAG_KEY, SimpleUnbakedExtraModel.blockStateModel(BACKPACK_SLEEPING_BAG));
            pluginContext.addModel(BACKPACK_SLEEPING_BAG_EXTRAS_KEY, SimpleUnbakedExtraModel.blockStateModel(BACKPACK_SLEEPING_BAG_EXTRAS));
            pluginContext.addModel(BACKPACK_TANKS_KEY, SimpleUnbakedExtraModel.blockStateModel(BACKPACK_TANKS));
            pluginContext.addModel(BACKPACK_VILLAGER_NOSE_KEY, SimpleUnbakedExtraModel.blockStateModel(BACKPACK_VILLAGER_NOSE));
            pluginContext.addModel(BACKPACK_WARDEN_HORNS_KEY, SimpleUnbakedExtraModel.blockStateModel(BACKPACK_WARDEN_HORNS));
            pluginContext.addModel(BACKPACK_WOLF_NOSE_KEY, SimpleUnbakedExtraModel.blockStateModel(BACKPACK_WOLF_NOSE));
        });

        class_10443.field_55336.method_65325(class_2960.method_60655(TravelersBackpack.MODID, "backpack"), BackpackItemModel.Unbaked.MAP_CODEC);
    }

    public static void registerBlockColorProvider() {
        ColorProviderRegistry.BLOCK.register((state, level, pos, tintIndex) -> {
            if(pos == null) {
                return -1;
            }
            if(level.method_8321(pos) instanceof BackpackBlockEntity backpack) {
                if(tintIndex == 0) {
                    RenderInfo info = backpack.getWrapper().getRenderInfo();
                    return FluidVariantRendering.getColor(info.getLeftFluidStack().fluidVariant()) | -16777216;
                }
                if(tintIndex == 1) {
                    RenderInfo info = backpack.getWrapper().getRenderInfo();
                    return FluidVariantRendering.getColor(info.getRightFluidStack().fluidVariant()) | -16777216;
                }
                if(tintIndex == 2 && backpack.getWrapper().getBackpackStack().method_57826(class_9334.field_49644)) {
                    return class_9848.method_61334(backpack.getWrapper().getBackpackStack().method_58694(class_9334.field_49644).comp_2384());
                }
            }
            return -1;
        }, ModBlocks.STANDARD_TRAVELERS_BACKPACK);

        ColorProviderRegistry.BLOCK.register((state, level, pos, tintIndex) -> {
            if(pos == null) {
                return -1;
            }
            if(level.method_8321(pos) instanceof BackpackBlockEntity backpack) {
                if(tintIndex == 0) {
                    RenderInfo info = backpack.getWrapper().getRenderInfo();
                    return FluidVariantRendering.getColor(info.getLeftFluidStack().fluidVariant()) | -16777216;
                }
                if(tintIndex == 1) {
                    RenderInfo info = backpack.getWrapper().getRenderInfo();
                    return FluidVariantRendering.getColor(info.getRightFluidStack().fluidVariant()) | -16777216;
                }
            }
            return -1;
        }, ModBlocks.NETHERITE_TRAVELERS_BACKPACK,
                ModBlocks.DIAMOND_TRAVELERS_BACKPACK,
                ModBlocks.GOLD_TRAVELERS_BACKPACK,
                ModBlocks.EMERALD_TRAVELERS_BACKPACK,
                ModBlocks.IRON_TRAVELERS_BACKPACK,
                ModBlocks.LAPIS_TRAVELERS_BACKPACK,
                ModBlocks.REDSTONE_TRAVELERS_BACKPACK,
                ModBlocks.COAL_TRAVELERS_BACKPACK,

                ModBlocks.QUARTZ_TRAVELERS_BACKPACK,
                ModBlocks.BOOKSHELF_TRAVELERS_BACKPACK,
                ModBlocks.END_TRAVELERS_BACKPACK,
                ModBlocks.NETHER_TRAVELERS_BACKPACK,
                ModBlocks.SANDSTONE_TRAVELERS_BACKPACK,
                ModBlocks.SNOW_TRAVELERS_BACKPACK,
                ModBlocks.SPONGE_TRAVELERS_BACKPACK,

                ModBlocks.CAKE_TRAVELERS_BACKPACK,

                ModBlocks.CACTUS_TRAVELERS_BACKPACK,
                ModBlocks.HAY_TRAVELERS_BACKPACK,
                ModBlocks.MELON_TRAVELERS_BACKPACK,
                ModBlocks.PUMPKIN_TRAVELERS_BACKPACK,

                ModBlocks.CREEPER_TRAVELERS_BACKPACK,
                ModBlocks.DRAGON_TRAVELERS_BACKPACK,
                ModBlocks.ENDERMAN_TRAVELERS_BACKPACK,
                ModBlocks.BLAZE_TRAVELERS_BACKPACK,
                ModBlocks.GHAST_TRAVELERS_BACKPACK,
                ModBlocks.MAGMA_CUBE_TRAVELERS_BACKPACK,
                ModBlocks.SKELETON_TRAVELERS_BACKPACK,
                ModBlocks.SPIDER_TRAVELERS_BACKPACK,
                ModBlocks.WITHER_TRAVELERS_BACKPACK,
                ModBlocks.WARDEN_TRAVELERS_BACKPACK,

                ModBlocks.BAT_TRAVELERS_BACKPACK,
                ModBlocks.BEE_TRAVELERS_BACKPACK,
                ModBlocks.WOLF_TRAVELERS_BACKPACK,
                ModBlocks.FOX_TRAVELERS_BACKPACK,
                ModBlocks.OCELOT_TRAVELERS_BACKPACK,
                ModBlocks.HORSE_TRAVELERS_BACKPACK,
                ModBlocks.COW_TRAVELERS_BACKPACK,
                ModBlocks.PIG_TRAVELERS_BACKPACK,
                ModBlocks.SHEEP_TRAVELERS_BACKPACK,
                ModBlocks.CHICKEN_TRAVELERS_BACKPACK,
                ModBlocks.SQUID_TRAVELERS_BACKPACK,
                ModBlocks.VILLAGER_TRAVELERS_BACKPACK,
                ModBlocks.IRON_GOLEM_TRAVELERS_BACKPACK);
    }

    public static void registerItemColorProvider() {
        class_10402.field_55235.method_65325(class_2960.method_60655(TravelersBackpack.MODID, "backpack_dye"), BackpackTintSource.MAP_CODEC);
        class_10402.field_55235.method_65325(class_2960.method_60655(TravelersBackpack.MODID, "left_fluid"), LeftFluidTintSource.MAP_CODEC);
        class_10402.field_55235.method_65325(class_2960.method_60655(TravelersBackpack.MODID, "right_fluid"), RightFluidTintSource.MAP_CODEC);
    }

    public static void registerBackpackItemEntityRenderer() {
        EntityRendererRegistry.register(ModItems.BACKPACK_ITEM_ENTITY, class_916::new);
    }

    public static void registerSpecialRenderers() {
        HoseSpecialRenderer.register();
    }

    public static void registerFeatureRenderers() {
        LivingEntityFeatureRendererRegistrationCallback.EVENT.register((entityType, entityRenderer, registrationHelper, context) ->
        {
            if(entityRenderer instanceof class_1007 renderer) {
                registrationHelper.register(new BackpackLayer(renderer));
            }
            if(entityRenderer.method_4038() instanceof class_572 && entityRenderer instanceof class_922 livingEntityRenderer) {
                if(entityRenderer instanceof class_1007) return;
                registrationHelper.register(new BackpackEntityLayer(livingEntityRenderer));
            }
        });
    }

    public static void registerHudOverlay() {
        HudRenderCallback.EVENT.register(HudOverlay::renderOverlay);
    }

    public static void setupFluidRendering() {
        FluidRenderHandlerRegistry.INSTANCE.register(ModFluids.POTION_STILL, ModFluids.POTION_FLOWING, new SimpleFluidRenderHandler(
                class_2960.method_60655(TravelersBackpack.MODID, "block/potion_still"),
                class_2960.method_60655(TravelersBackpack.MODID, "block/potion_flow"),
                13458603
        ));

        FluidVariantAttributes.register(ModFluids.POTION_STILL, new PotionFluidVariantAttributeHandler());
        FluidVariantAttributes.register(ModFluids.POTION_FLOWING, new PotionFluidVariantAttributeHandler());
        FluidVariantRendering.register(ModFluids.POTION_STILL, new PotionFluidVariantRenderHandler());
        FluidVariantRendering.register(ModFluids.POTION_FLOWING, new PotionFluidVariantRenderHandler());
    }

    public static void registerTooltipComponent() {
        TooltipComponentCallback.EVENT.register((data ->
        {
            if(data instanceof BackpackTooltipComponent) {
                return new ClientBackpackTooltipComponent((BackpackTooltipComponent)data);
            }
            return null;
        }));
    }

    public static void registerClientCommands() {
        ClientCommandRegistrationCallback.EVENT.register(BackpackIconCommands::new);
    }

    public record BackpackTintSource(int defaultColor) implements class_10401 {
        public static final MapCodec<BackpackTintSource> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
                class_5699.field_51365.fieldOf("default").forGetter(BackpackTintSource::defaultColor)
        ).apply(instance, BackpackTintSource::new));

        @Override
        public int method_65389(class_1799 itemStack, @Nullable class_638 clientLevel, @Nullable class_1309 livingEntity) {
            class_9282 color = itemStack.method_58694(class_9334.field_49644);
            if(itemStack.method_7909() == ModItems.STANDARD_TRAVELERS_BACKPACK && color != null) {
                return class_9848.method_61334(color.comp_2384());
            }
            return defaultColor;
        }

        @Override
        public MapCodec<? extends class_10401> method_65387() {
            return MAP_CODEC;
        }
    }

    public record LeftFluidTintSource(int defaultColor) implements class_10401 {
        public static final MapCodec<LeftFluidTintSource> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
                class_5699.field_51365.fieldOf("default").forGetter(LeftFluidTintSource::defaultColor)
        ).apply(instance, LeftFluidTintSource::new));

        @Override
        public int method_65389(class_1799 itemStack, @Nullable class_638 clientLevel, @Nullable class_1309 livingEntity) {
            if(itemStack.method_7909() instanceof TravelersBackpackItem) {
                RenderInfo info = itemStack.method_58695(ModDataComponents.RENDER_INFO, RenderInfo.EMPTY);
                return FluidVariantRendering.getColor(info.getLeftFluidStack().fluidVariant()) | -16777216;
            }
            return defaultColor;
        }

        @Override
        public MapCodec<? extends class_10401> method_65387() {
            return MAP_CODEC;
        }
    }

    public record RightFluidTintSource(int defaultColor) implements class_10401 {
        public static final MapCodec<RightFluidTintSource> MAP_CODEC = RecordCodecBuilder.mapCodec(instance -> instance.group(
                class_5699.field_51365.fieldOf("default").forGetter(RightFluidTintSource::defaultColor)
        ).apply(instance, RightFluidTintSource::new));

        @Override
        public int method_65389(class_1799 itemStack, @Nullable class_638 clientLevel, @Nullable class_1309 livingEntity) {
            if(itemStack.method_7909() instanceof TravelersBackpackItem) {
                RenderInfo info = itemStack.method_58695(ModDataComponents.RENDER_INFO, RenderInfo.EMPTY);
                return FluidVariantRendering.getColor(info.getRightFluidStack().fluidVariant()) | -16777216;
            }
            return defaultColor;
        }

        @Override
        public MapCodec<? extends class_10401> method_65387() {
            return MAP_CODEC;
        }
    }
}