package com.tiviacz.travelersbackpack.config;

import com.google.common.collect.Multimap;
import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.tiviacz.travelersbackpack.init.ModItems;
import com.tiviacz.travelersbackpack.inventory.menu.slot.BackpackSlotItemHandler;
import com.tiviacz.travelersbackpack.inventory.menu.slot.ToolSlotItemHandler;
import com.tiviacz.travelersbackpack.util.Reference;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.neoforged.neoforge.common.ModConfigSpec;
import org.apache.commons.lang3.tuple.Pair;

import java.util.*;

public class TravelersBackpackConfig {
    public static class Server {
        private static final String REGISTRY_NAME_MATCHER = "([a-z0-9_.-]+:[a-z0-9_/.-]+)";

        public final BackpackSettings backpackSettings;
        public final BackpackUpgrades backpackUpgrades;
        public final World world;
        public final BackpackAbilities backpackAbilities;
        public final SlownessDebuff slownessDebuff;

        Server(ModConfigSpec.Builder builder) {
            builder.comment("Server config settings")
                    .push("server");

            //Backpack Settings
            backpackSettings = new BackpackSettings(builder, "backpackSettings");

            //Backpack Upgrades
            backpackUpgrades = new BackpackUpgrades(builder, "backpackUpgrades");

            //World
            world = new World(builder, "world");

            //Abilities
            backpackAbilities = new BackpackAbilities(builder, "backpackAbilities");

            //Slowness Debuff
            slownessDebuff = new SlownessDebuff(builder, "slownessDebuff");

            builder.pop();
        }

        public static class BackpackUpgrades {
            public final ModConfigSpec.BooleanValue enableTanksUpgrade;
            public final ModConfigSpec.BooleanValue enableCraftingUpgrade;
            public final ModConfigSpec.BooleanValue enableFurnaceUpgrade;
            public final ModConfigSpec.BooleanValue enableSmokerUpgrade;
            public final ModConfigSpec.BooleanValue enableBlastFurnaceUpgrade;
            public final FilterUpgradeSettings pickupUpgradeSettings;
            public final ModConfigSpec.BooleanValue enableJukeboxUpgrade;
            public final MagnetUpgradeSettings magnetUpgradeSettings;
            public final FeedingUpgradeSettings feedingUpgradeSettings;
            public final RefillUpgradeSettings refillUpgradeSettings;
            public final FilterUpgradeSettings voidUpgradeSettings;

            public BackpackUpgrades(ModConfigSpec.Builder builder, String path) {
                builder.push(path);

                enableTanksUpgrade = builder
                        .define("enableTanksUpgrade", true);

                enableCraftingUpgrade = builder
                        .define("enableCraftingUpgrade", true);

                enableFurnaceUpgrade = builder
                        .define("enableFurnaceUpgrade", true);

                enableSmokerUpgrade = builder
                        .define("enableSmokerUpgrade", true);

                enableBlastFurnaceUpgrade = builder
                        .define("enableBlastFurnaceUpgrade", true);

                pickupUpgradeSettings = new FilterUpgradeSettings(builder, "pickupUpgradeSettings", "PickupUpgrade");

                enableJukeboxUpgrade = builder
                        .define("enableJukeboxUpgrade", true);

                magnetUpgradeSettings = new MagnetUpgradeSettings(builder, "magnetUpgradeSettings");

                feedingUpgradeSettings = new FeedingUpgradeSettings(builder, "feedingUpgradeSettings");

                refillUpgradeSettings = new RefillUpgradeSettings(builder, "refillUpgradeSettings");

                voidUpgradeSettings = new FilterUpgradeSettings(builder, "voidUpgradeSettings", "VoidUpgrade");

                builder.pop();
            }

            public static class FilterUpgradeSettings {
                public final ModConfigSpec.BooleanValue enableUpgrade;
                public final ModConfigSpec.IntValue filterSlotCount;
                public final ModConfigSpec.IntValue slotsInRow;

                public FilterUpgradeSettings(ModConfigSpec.Builder builder, String path, String upgradeName) {
                    builder.push(path);

                    enableUpgrade = builder
                            .define("enable" + upgradeName, true);

                    filterSlotCount = builder
                            .defineInRange("filterSlotCount", 9, 1, 20);

                    slotsInRow = builder
                            .defineInRange("slotsInRow", 3, 1, 5);

                    builder.pop();
                }
            }

            public static class FeedingUpgradeSettings {
                public final ModConfigSpec.BooleanValue enableFeedingUpgrade;
                public final ModConfigSpec.IntValue filterSlotCount;
                public final ModConfigSpec.IntValue slotsInRow;
                public final ModConfigSpec.IntValue tickRate;

                public FeedingUpgradeSettings(ModConfigSpec.Builder builder, String path) {
                    builder.push(path);

                    enableFeedingUpgrade = builder
                            .define("enableFeedingUpgrade", true);

                    filterSlotCount = builder
                            .defineInRange("filterSlotCount", 9, 1, 20);

                    slotsInRow = builder
                            .defineInRange("slotsInRow", 3, 1, 5);

                    tickRate = builder
                            .defineInRange("tickRate", 100, 1, 1000);

                    builder.pop();
                }
            }

            public static class MagnetUpgradeSettings {
                public final ModConfigSpec.BooleanValue enableMagnetUpgrade;
                public final ModConfigSpec.IntValue filterSlotCount;
                public final ModConfigSpec.IntValue slotsInRow;
                public final ModConfigSpec.IntValue pullRange;
                public final ModConfigSpec.IntValue tickRate;

                public MagnetUpgradeSettings(ModConfigSpec.Builder builder, String path) {
                    builder.push(path);

                    enableMagnetUpgrade = builder
                            .define("enableMagnetUpgrade", true);

                    filterSlotCount = builder
                            .defineInRange("filterSlotCount", 9, 1, 20);

                    slotsInRow = builder
                            .defineInRange("slotsInRow", 3, 1, 5);

                    pullRange = builder
                            .defineInRange("pullRange", 5, 1, 20);

                    tickRate = builder
                            .defineInRange("tickRate", 10, 1, 1000);

                    builder.pop();
                }
            }

            public static class RefillUpgradeSettings {
                public final ModConfigSpec.BooleanValue enableRefillUpgrade;
                public final ModConfigSpec.IntValue filterSlotCount;
                public final ModConfigSpec.IntValue slotsInRow;
                public final ModConfigSpec.IntValue tickRate;

                public RefillUpgradeSettings(ModConfigSpec.Builder builder, String path) {
                    builder.push(path);

                    enableRefillUpgrade = builder
                            .define("enableRefillUpgrade", true);

                    filterSlotCount = builder
                            .defineInRange("filterSlotCount", 9, 1, 20);

                    slotsInRow = builder
                            .defineInRange("slotsInRow", 3, 1, 5);

                    tickRate = builder
                            .defineInRange("tickRate", 5, 1, 1000);

                    builder.pop();
                }
            }
        }

        public static class BackpackSettings {
            public final TierConfig leather;
            public final TierConfig iron;
            public final TierConfig gold;
            public final TierConfig diamond;
            public final TierConfig netherite;
            public final ModConfigSpec.BooleanValue rightClickEquip;
            public final ModConfigSpec.BooleanValue rightClickUnequip;
            public final ModConfigSpec.BooleanValue allowOnlyEquippedBackpack;
            public final ModConfigSpec.BooleanValue allowOpeningFromSlot;
            public final ModConfigSpec.BooleanValue preventMultiplePlayersAccess;
            public final ModConfigSpec.BooleanValue invulnerableBackpack;
            public final ModConfigSpec.BooleanValue allowToolSwapping;
            public final ModConfigSpec.BooleanValue toolSlotsAcceptEverything;
            public final ModConfigSpec.ConfigValue<List<? extends String>> toolSlotsAcceptableItems;
            public final ModConfigSpec.ConfigValue<List<? extends String>> blacklistedItems;
            public final ModConfigSpec.BooleanValue allowShulkerBoxes;
            public final ModConfigSpec.BooleanValue voidProtection;
            public final ModConfigSpec.BooleanValue backpackDeathPlace;
            public final ModConfigSpec.BooleanValue backpackForceDeathPlace;
            public final ModConfigSpec.BooleanValue quickSleepingBag;
            public final ModConfigSpec.BooleanValue enableSleepingBagSpawnPoint;
            public final ModConfigSpec.BooleanValue backSlotIntegration;

            BackpackSettings(ModConfigSpec.Builder builder, String path) {
                builder.push(path);

                //Backpack Settings
                leather = new TierConfig(builder, "Leather", 27, 2, 2, (int)FluidConstants.BUCKET);
                iron = new TierConfig(builder, "Iron", 45, 3, 3, (int)FluidConstants.BUCKET);
                gold = new TierConfig(builder, "Gold", 63, 4, 4, (int)FluidConstants.BUCKET);
                diamond = new TierConfig(builder, "Diamond", 81, 5, 5, (int)FluidConstants.BUCKET);
                netherite = new TierConfig(builder, "Netherite", 99, 6, 6, (int)FluidConstants.BUCKET);

                rightClickEquip = builder
                        .comment("Enables equipping the backpack on right-click from the ground")
                        .define("rightClickEquip", true);

                rightClickUnequip = builder
                        .comment("Enables unequipping the backpack on right-click on the ground with empty hand")
                        .define("rightClickUnequip", false);

                allowOnlyEquippedBackpack = builder
                        .comment("Allows to use only equipped backpack")
                        .define("allowOnlyEquippedBackpack", false);

                allowOpeningFromSlot = builder
                        .comment("Allows opening the backpack by pressing a keybind while hovering over the slot with backpack in the player's inventory")
                        .define("allowOpeningFromSlot", false);

                preventMultiplePlayersAccess = builder
                        .comment("Prevents more than one player from accessing the backpack at the same time when it's placed on the ground")
                        .define("preventMultiplePlayersAccess", false);

                invulnerableBackpack = builder
                        .comment("Backpack immune to any damage source (lava, fire), can't be destroyed, never disappears as floating item")
                        .define("invulnerableBackpack", true);

                allowToolSwapping = builder
                        .comment("Allows swapping tools between tool slots and the player’s inventory via a quick-swap menu")
                        .define("allowToolSwapping", true);

                toolSlotsAcceptEverything = builder
                        .comment("Tool slots accept any item")
                        .define("toolSlotsAcceptEverything", false);

                toolSlotsAcceptableItems = builder
                        .comment("List of items that can be put in tool slots (Use registry names, for example: \"minecraft:apple\", \"minecraft:flint\")")
                        .defineList("toolSlotsAcceptableItems", Collections.emptyList(), () -> "", mapping -> ((String)mapping).matches(REGISTRY_NAME_MATCHER));

                blacklistedItems = builder
                        .comment("List of items that can't be put in backpack inventory (Use registry names, for example: \"minecraft:apple\", \"minecraft:flint\")")
                        .defineList("blacklistedItems", Collections.emptyList(), () -> "", mapping -> ((String)mapping).matches(REGISTRY_NAME_MATCHER));

                allowShulkerBoxes = builder
                        .comment("Allows putting shulker boxes and other items with inventory in backpack")
                        .define("allowShulkerBoxes", false);

                voidProtection = builder
                        .comment("Prevents backpack disappearing in void, spawns floating backpack above minimum Y when player dies in void")
                        .define("voidProtection", true);

                backpackDeathPlace = builder
                        .comment("Places backpack at place where player died")
                        .define("backpackDeathPlace", true);

                backpackForceDeathPlace = builder
                        .comment("Places backpack at place where player died, replacing all blocks that are breakable and do not have inventory (backpackDeathPlace must be true in order to work)")
                        .define("backpackForceDeathPlace", false);

                quickSleepingBag = builder
                        .comment("Allows sleeping in a sleeping bag without the need to unequip and place the backpack on the ground")
                        .define("quickSleepingBag", true);

                enableSleepingBagSpawnPoint = builder
                        .define("enableSleepingBagSpawnPoint", false);

                backSlotIntegration = builder
                        .comment("Backpacks can only be equipped in the Curios/Accessories 'Back' slot, provided those mods are installed. If set to false, backpacks can only be equipped by clicking the button in the Backpack GUI. " +
                                "This setting can be changed without unequipping the backpack. An already equipped backpack will not disappear and can be retrieved from the player's inventory.")
                        .define("backSlotIntegration", true);

                builder.pop();
            }

            public static class TierConfig {
                public final ModConfigSpec.IntValue inventorySlotCount;
                public final ModConfigSpec.IntValue upgradeSlotCount;
                public final ModConfigSpec.IntValue toolSlotCount;
                public final ModConfigSpec.IntValue tankCapacityPerRow;

                public TierConfig(ModConfigSpec.Builder builder, String tier, int inventorySlotCountDefault, int upgradeSlotCountDefault, int toolSlotCountDefault, int tankCapacityPerRowDefault) {
                    builder.comment(tier + " Tier Backpack Settings").push(tier.toLowerCase(Locale.ENGLISH) + "TierBackpack");

                    inventorySlotCount =
                            builder.comment("Number of inventory slots for the tier")
                                    .defineInRange("inventorySlotCount", inventorySlotCountDefault, 1, 154);

                    upgradeSlotCount =
                            builder.comment("Number of upgrade slots for the tier")
                                    .defineInRange("upgradeSlotCount", upgradeSlotCountDefault, 0, 10);

                    toolSlotCount =
                            builder.comment("Number of tool slots for the tier")
                                    .defineInRange("toolSlotCount", toolSlotCountDefault, 0, 8);

                    tankCapacityPerRow =
                            builder.comment("Tank capacity per row of backpack storage, 1000 equals 1 Bucket (Leather backpack 3 rows of 9 slots = 3 * 1000")
                                    .defineInRange("tankCapacity", tankCapacityPerRowDefault, 1, 100000);

                    builder.pop();
                }
            }

            public record Tier(int inventorySlotCount, int toolSlotCount, int tankCapacity) {
            }
        }

        public static class World {
            public final ModConfigSpec.BooleanValue spawnEntitiesWithBackpack;
            public final ModConfigSpec.DoubleValue chance;
            public final ModConfigSpec.ConfigValue<List<? extends String>> possibleOverworldEntityTypes;
            public final ModConfigSpec.ConfigValue<List<? extends String>> possibleNetherEntityTypes;
            public final ModConfigSpec.ConfigValue<List<? extends String>> overworldBackpacks;
            public final ModConfigSpec.ConfigValue<List<? extends String>> netherBackpacks;

            World(ModConfigSpec.Builder builder, String path) {
                builder.push(path);

                spawnEntitiesWithBackpack = builder
                        .comment("Enables chance to spawn Zombie, Skeleton, Wither Skeleton, Piglin or Enderman with random backpack equipped")
                        .define("spawnEntitiesWithBackpack", true);

                chance = builder
                        .comment("Defines spawn chance of entity with a backpack")
                        .defineInRange("chance", 0.005, 0, 1);

                possibleOverworldEntityTypes = builder
                        .comment("List of overworld entity types that can spawn with equipped backpack. DO NOT ADD anything to this list, because the game will crash, remove entries if mob should not spawn with backpack")
                        .defineList("possibleOverworldEntityTypes", this::getPossibleOverworldEntityTypes, () -> "", mapping -> ((String)mapping).matches(REGISTRY_NAME_MATCHER));

                possibleNetherEntityTypes = builder
                        .comment("List of nether entity types that can spawn with equipped backpack. DO NOT ADD anything to this list, because the game will crash, remove entries if mob should not spawn with backpack")
                        .defineList("possibleNetherEntityTypes", this::getPossibleNetherEntityTypes, () -> "", mapping -> ((String)mapping).matches(REGISTRY_NAME_MATCHER));

                overworldBackpacks = builder
                        .comment("List of backpacks that can spawn on overworld mobs")
                        .defineList("overworldBackpacks", this::getOverworldBackpacksList, () -> "", mapping -> ((String)mapping).matches(REGISTRY_NAME_MATCHER));

                netherBackpacks = builder
                        .comment("List of backpacks that can spawn on nether mobs")
                        .defineList("netherBackpacks", this::getNetherBackpacksList, () -> "", mapping -> ((String)mapping).matches(REGISTRY_NAME_MATCHER));

                builder.pop();
            }

            private List<String> getPossibleOverworldEntityTypes() {
                List<String> ret = new ArrayList<>();
                ret.add("minecraft:zombie");
                ret.add("minecraft:skeleton");
                ret.add("minecraft:enderman");
                return ret;
            }

            private List<String> getPossibleNetherEntityTypes() {
                List<String> ret = new ArrayList<>();
                ret.add("minecraft:wither_skeleton");
                ret.add("minecraft:piglin");
                return ret;
            }


            private List<String> getOverworldBackpacksList() {
                List<String> ret = new ArrayList<>();
                ret.add("travelersbackpack:standard");
                ret.add("travelersbackpack:diamond");
                ret.add("travelersbackpack:gold");
                ret.add("travelersbackpack:emerald");
                ret.add("travelersbackpack:iron");
                ret.add("travelersbackpack:lapis");
                ret.add("travelersbackpack:redstone");
                ret.add("travelersbackpack:coal");
                ret.add("travelersbackpack:bookshelf");
                ret.add("travelersbackpack:sandstone");
                ret.add("travelersbackpack:snow");
                ret.add("travelersbackpack:sponge");
                ret.add("travelersbackpack:cake");
                ret.add("travelersbackpack:cactus");
                ret.add("travelersbackpack:hay");
                ret.add("travelersbackpack:melon");
                ret.add("travelersbackpack:pumpkin");
                ret.add("travelersbackpack:creeper");
                ret.add("travelersbackpack:enderman");
                ret.add("travelersbackpack:skeleton");
                ret.add("travelersbackpack:spider");
                ret.add("travelersbackpack:bee");
                ret.add("travelersbackpack:wolf");
                ret.add("travelersbackpack:fox");
                ret.add("travelersbackpack:ocelot");
                ret.add("travelersbackpack:horse");
                ret.add("travelersbackpack:cow");
                ret.add("travelersbackpack:pig");
                ret.add("travelersbackpack:sheep");
                ret.add("travelersbackpack:chicken");
                ret.add("travelersbackpack:squid");
                return ret;
            }

            private List<String> getNetherBackpacksList() {
                List<String> ret = new ArrayList<>();
                ret.add("travelersbackpack:quartz");
                ret.add("travelersbackpack:nether");
                ret.add("travelersbackpack:blaze");
                ret.add("travelersbackpack:ghast");
                ret.add("travelersbackpack:magma_cube");
                ret.add("travelersbackpack:wither");
                return ret;
            }
        }

        public static class BackpackAbilities {
            private static final String REGISTRY_NAME_MATCHER = "([a-z0-9_.-]+:[a-z0-9_/.-]+)";
            private static final String EFFECT_ABILITY_MATCHER = "([a-z0-9_.-]+:[a-z0-9_/.-]+),\\s*([a-z0-9_.-]+:[a-z0-9_/.-]+),\\s*(\\d+),\\s*(\\d+),\\s*(\\d+)";
            private static final String COOLDOWNS_MATCHER = "([a-z0-9_.-]+:[a-z0-9_/.-]+),\\s*(\\d+),\\s*(\\d+)";

            public final ModConfigSpec.BooleanValue enableBackpackAbilities;
            public final ModConfigSpec.BooleanValue forceAbilityEnabled;
            public final ModConfigSpec.ConfigValue<List<? extends String>> allowedAbilities;
            public final ModConfigSpec.ConfigValue<List<? extends String>> backpackEffects;
            public final ModConfigSpec.ConfigValue<List<? extends String>> cooldowns;

            BackpackAbilities(ModConfigSpec.Builder builder, String path) {
                builder.push(path);

                enableBackpackAbilities = builder
                        .define("enableBackpackAbilities", true);

                forceAbilityEnabled = builder
                        .comment("Newly crafted backpacks will have ability enabled by default")
                        .define("forceAbilityEnabled", true);

                allowedAbilities = builder
                        .comment("List of backpacks that are allowed to have an ability. DO NOT ADD anything to this list, because the game will crash, remove entries if backpack should not have ability")
                        .defineList("allowedAbilities", this::getAllowedAbilities, () -> "", mapping -> ((String)mapping).matches(REGISTRY_NAME_MATCHER));

                backpackEffects = builder
                        .comment("List of effect abilities associated with backpacks, you can modify this list as you wish. Different effects can be added to different backpacks. \n Formatting: \"<backpack_registry_name>, <status_effect_registry_name>, <min_duration_ticks>, <max_duration_ticks>, <amplifier>\"")
                        .defineList("backpackEffects", this::getBackpackEffects, () -> "", mapping -> ((String)mapping).matches(EFFECT_ABILITY_MATCHER));

                cooldowns = builder
                        .comment("List of cooldowns that are being applied after ability usage, the backpacks on the list are all that currently have cooldowns, adding additional backpack will not give it cooldown. \n Formatting: \"<backpack_registry_name>, <min_possible_cooldown_seconds>, <max_possible_cooldown_seconds>\"")
                        .defineList("cooldowns", this::getCooldowns, () -> "", mapping -> ((String)mapping).matches(COOLDOWNS_MATCHER));

                builder.pop();
            }

            private List<String> getAllowedAbilities() {
                List<String> ret = new ArrayList<>();
                ret.add("travelersbackpack:netherite");
                ret.add("travelersbackpack:diamond");
                ret.add("travelersbackpack:gold");
                ret.add("travelersbackpack:emerald");
                ret.add("travelersbackpack:iron");
                ret.add("travelersbackpack:lapis");
                ret.add("travelersbackpack:redstone");
                ret.add("travelersbackpack:bookshelf");
                ret.add("travelersbackpack:sponge");
                ret.add("travelersbackpack:cake");
                ret.add("travelersbackpack:cactus");
                ret.add("travelersbackpack:melon");
                ret.add("travelersbackpack:pumpkin");
                ret.add("travelersbackpack:creeper");
                ret.add("travelersbackpack:dragon");
                ret.add("travelersbackpack:enderman");
                ret.add("travelersbackpack:blaze");
                ret.add("travelersbackpack:ghast");
                ret.add("travelersbackpack:magma_cube");
                ret.add("travelersbackpack:spider");
                ret.add("travelersbackpack:wither");
                ret.add("travelersbackpack:warden");
                ret.add("travelersbackpack:bat");
                ret.add("travelersbackpack:bee");
                ret.add("travelersbackpack:ocelot");
                ret.add("travelersbackpack:cow");
                ret.add("travelersbackpack:chicken");
                ret.add("travelersbackpack:squid");
                ret.add("travelersbackpack:hay");
                ret.add("travelersbackpack:fox");
                return ret;
            }

            private List<String> getCooldowns() {
                List<String> ret = new ArrayList<>();
                ret.add("travelersbackpack:creeper, 1200, 1800");
                ret.add("travelersbackpack:cow, 480, 540");
                ret.add("travelersbackpack:chicken, 360, 600");
                ret.add("travelersbackpack:cake, 360, 480");
                ret.add("travelersbackpack:melon, 120, 480");
                return ret;
            }

            private List<String> getBackpackEffects() {
                List<String> ret = new ArrayList<>();
                ret.add("travelersbackpack:bat, minecraft:night_vision, 260, 300, 0");
                ret.add("travelersbackpack:magma_cube, minecraft:fire_resistance, 260, 300, 0");
                ret.add("travelersbackpack:squid, minecraft:water_breathing, 260, 300, 0");
                ret.add("travelersbackpack:squid, minecraft:night_vision, 260, 300, 0");
                ret.add("travelersbackpack:dragon, minecraft:regeneration, 260, 300, 0");
                ret.add("travelersbackpack:dragon, minecraft:strength, 250, 290, 0");
                ret.add("travelersbackpack:quartz, minecraft:haste, 260, 300, 0");
                ret.add("travelersbackpack:fox, minecraft:jump_boost, 260, 300, 0");
                return ret;
            }
        }

        public static class SlownessDebuff {
            public final ModConfigSpec.BooleanValue tooManyBackpacksSlowness;
            public final ModConfigSpec.IntValue maxNumberOfBackpacks;
            public final ModConfigSpec.DoubleValue slownessPerExcessedBackpack;

            SlownessDebuff(ModConfigSpec.Builder builder, String path) {
                builder.push(path);

                tooManyBackpacksSlowness = builder
                        .comment("Player gets slowness effect, if carries too many backpacks in inventory")
                        .define("tooManyBackpacksSlowness", false);

                maxNumberOfBackpacks = builder
                        .comment("Maximum number of backpacks, which can be carried in inventory, without slowness effect")
                        .defineInRange("maxNumberOfBackpacks", 3, 1, 37);

                slownessPerExcessedBackpack = builder
                        .defineInRange("slownessPerExcessedBackpack", 1, 0.1, 5);

                builder.pop();
            }
        }

        public void loadItemsFromConfig(List<? extends String> configList, List<class_1792> targetList) {
            targetList.clear();
            for(String registryName : configList) {
                class_2960 res = class_2960.method_12829(registryName);

                if(class_7923.field_41178.method_10250(res)) {
                    targetList.add(class_7923.field_41178.method_63535(res));
                }
            }
        }

        public void loadEntityTypesFromConfig(List<? extends String> configList, List<class_1299> targetList) {
            targetList.clear();
            for(String registryName : configList) {
                class_2960 res = class_2960.method_12829(registryName);

                if(class_7923.field_41177.method_10250(res)) {
                    targetList.add(class_7923.field_41177.method_63535(res));
                }
            }
        }

        public void loadBackpackEffectsFromConfig(List<? extends String> configList, Multimap<class_1792, BackpackEffect> backpackEffects) {
            backpackEffects.clear();
            try {
                for(String entry : configList) {
                    String[] parts = entry.replace(" ", "").split(",");
                    if(parts.length == 5) {
                        class_2960 backpackRes = class_2960.method_12829(parts[0]);
                        class_2960 effectRes = class_2960.method_12829(parts[1]);

                        if(class_7923.field_41178.method_10250(backpackRes) && class_7923.field_41174.method_10223(effectRes).isPresent() && class_7923.field_41178.method_10223(backpackRes).isPresent()) {
                            class_1792 backpack = class_7923.field_41178.method_10223(backpackRes).get().comp_349();
                            int minDuration = Integer.parseInt(parts[2]);
                            int maxDuration = Integer.parseInt(parts[3]);
                            int amplifier = Integer.parseInt(parts[4]);

                            if(minDuration < 0 || maxDuration < 0 || amplifier < 0) {
                                TravelersBackpack.LOGGER.error("Backpack Effects: duration and amplifier must be positive integers!");
                            }

                            if(minDuration > maxDuration) {
                                TravelersBackpack.LOGGER.error("Backpack Effects: minDuration must be less than or equal to maxDuration!");
                            }

                            backpackEffects.put(backpack, new BackpackEffect(class_7923.field_41174.method_10223(effectRes).get(), minDuration, maxDuration, amplifier));
                        }
                    }
                }
            } catch(Exception e) {
                TravelersBackpack.LOGGER.error("Could not load Backpack Effect from Config! Check your config if entries are correct!");
            }
        }

        public void loadCooldownsFromConfig(List<? extends String> config, Map<class_1792, Cooldown> cooldownConfigs) {
            cooldownConfigs.clear();
            try {
                for(String entry : config) {
                    String[] parts = entry.replace(" ", "").split(",");
                    if(parts.length == 3) {
                        class_2960 backpackRes = class_2960.method_12829(parts[0]);
                        if(class_7923.field_41178.method_10223(backpackRes).isEmpty()) {
                            continue;
                        }
                        class_1792 backpack = class_7923.field_41178.method_10223(backpackRes).get().comp_349();
                        int minCooldown = Integer.parseInt(parts[1]);
                        int maxCooldown = Integer.parseInt(parts[2]);

                        if(minCooldown < 0 || maxCooldown < 0) {
                            TravelersBackpack.LOGGER.error("Cooldowns: cooldowns must be positive integers!");
                        }

                        if(minCooldown > maxCooldown) {
                            TravelersBackpack.LOGGER.error("Cooldowns: minCooldown must be less than or equal to maxCooldown!");
                        }

                        cooldownConfigs.put(backpack, new Cooldown(minCooldown, maxCooldown));
                    }
                }
            } catch(Exception e) {
                TravelersBackpack.LOGGER.error("Could not load Cooldowns from Config! Check your config if entries are correct!");
            }
        }

        public void reload() {
            if(!serverSpec.isLoaded()) {
                return;
            }

            //Container
            loadItemsFromConfig(TravelersBackpackConfig.SERVER.backpackSettings.toolSlotsAcceptableItems.get(), ToolSlotItemHandler.TOOL_SLOTS_ACCEPTABLE_ITEMS);
            loadItemsFromConfig(TravelersBackpackConfig.SERVER.backpackSettings.blacklistedItems.get(), BackpackSlotItemHandler.BLACKLISTED_ITEMS);

            //Spawns
            loadItemsFromConfig(TravelersBackpackConfig.SERVER.world.overworldBackpacks.get(), ModItems.COMPATIBLE_OVERWORLD_BACKPACK_ENTRIES);
            loadItemsFromConfig(TravelersBackpackConfig.SERVER.world.netherBackpacks.get(), ModItems.COMPATIBLE_NETHER_BACKPACK_ENTRIES);

            //Abilities
            loadItemsFromConfig(TravelersBackpackConfig.SERVER.backpackAbilities.allowedAbilities.get(), com.tiviacz.travelersbackpack.common.BackpackAbilities.ALLOWED_ABILITIES);

            //Entities
            loadEntityTypesFromConfig(TravelersBackpackConfig.SERVER.world.possibleOverworldEntityTypes.get(), Reference.ALLOWED_TYPE_ENTRIES);
            loadEntityTypesFromConfig(TravelersBackpackConfig.SERVER.world.possibleNetherEntityTypes.get(), Reference.ALLOWED_TYPE_ENTRIES);

            //Backpack Effects
            loadBackpackEffectsFromConfig(TravelersBackpackConfig.SERVER.backpackAbilities.backpackEffects.get(), com.tiviacz.travelersbackpack.common.BackpackAbilities.BACKPACK_EFFECTS);

            //Update allowed abilities if added effect
            com.tiviacz.travelersbackpack.common.BackpackAbilities.getBackpackEffects().entries().stream().forEach(entry -> {
                if(!com.tiviacz.travelersbackpack.common.BackpackAbilities.ALLOWED_ABILITIES.contains(entry.getKey())) {
                    com.tiviacz.travelersbackpack.common.BackpackAbilities.ALLOWED_ABILITIES.add(entry.getKey());
                }
                if(!com.tiviacz.travelersbackpack.common.BackpackAbilities.ITEM_ABILITIES_LIST.contains(entry.getKey())) {
                    com.tiviacz.travelersbackpack.common.BackpackAbilities.ITEM_ABILITIES_LIST.add(entry.getKey());
                }
            });

            //Cooldowns
            loadCooldownsFromConfig(TravelersBackpackConfig.SERVER.backpackAbilities.cooldowns.get(), com.tiviacz.travelersbackpack.common.BackpackAbilities.COOLDOWNS);
        }
    }

    public static class Common {
        public final ModConfigSpec.BooleanValue enableLoot;
        public final ModConfigSpec.BooleanValue enableVillagerTrade;

        Common(ModConfigSpec.Builder builder) {
            builder.comment("Common config settings")
                    .push("common");

            enableLoot = builder
                    .comment("Enables backpacks spawning in loot chests")
                    .define("enableLoot", true);

            enableVillagerTrade = builder
                    .comment("Enables trade for Villager Backpack in Librarian villager trades")
                    .define("enableVillagerTrade", true);

            builder.pop();
        }
    }

    public static class Client {
        public final ModConfigSpec.BooleanValue showBackpackIconInInventory;
        public final ModConfigSpec.BooleanValue sendBackpackCoordinatesMessage;
        public final ModConfigSpec.BooleanValue obtainTips;
        public final ModConfigSpec.BooleanValue renderTools;
        public final ModConfigSpec.BooleanValue showSupporterBadge;
        public final ToolsOverlay toolsOverlay;
        public final Overlay overlay;

        Client(ModConfigSpec.Builder builder) {
            builder.comment("Client-only settings")
                    .push("client");

            showBackpackIconInInventory = builder
                    .comment("Whether the backpack icon should be visible in player's inventory")
                    .define("showBackpackIconInInventory", true);

            sendBackpackCoordinatesMessage = builder
                    .comment("Sends a message to the player on death with backpack coordinates")
                    .define("sendBackpackCoordinatesMessage", true);

            obtainTips = builder
                    .comment("Enables tip, how to obtain a backpack, if there's no crafting recipe for it")
                    .define("obtainTips", true);

            renderTools = builder
                    .comment("Render tools in tool slots on the backpack, while worn")
                    .define("renderTools", true);

            showSupporterBadge = builder
                    .comment("Only for supporters, option to show/hide the Supporter Star Badge. If you want to receive the Supporter Star Badge, visit my Ko-fi page :)! - https://ko-fi.com/tiviacz1337")
                    .define("showSupporterBadge", true);

            toolsOverlay = new ToolsOverlay(builder, "The position of the Tools Overlay on the screen", "toolsOverlay");

            overlay = new Overlay(
                    builder,
                    "The position of the Overlay on the screen",
                    "overlay",
                    true, 20, 30
            );

            builder.pop();
        }

        public static class ToolsOverlay {
            public final ModConfigSpec.BooleanValue swapOnClose;
            public final ModConfigSpec.BooleanValue showTooltip;
            public final ModConfigSpec.BooleanValue renderBackpackIconInCenter;
            public final ModConfigSpec.DoubleValue opacity;
            public final ModConfigSpec.IntValue offsetX;
            public final ModConfigSpec.IntValue offsetY;

            ToolsOverlay(ModConfigSpec.Builder builder, String comment, String path) {
                builder.comment(comment)
                        .push(path);
                swapOnClose = builder
                        .comment("If true, the currently held item will be swapped with the selected tool belt slot when closing the tool belt GUI")
                        .define("swapOnClose", true);

                showTooltip = builder
                        .comment("Displays the full tooltip when hovering over an item in the tool belt. If false, only the item name is shown")
                        .define("showTooltip", false);

                renderBackpackIconInCenter = builder
                        .comment("Render backpack icon in the center of the tools overlay")
                        .define("renderBackpackIconInCenter", true);

                opacity = builder
                        .comment("Overlay opacity")
                        .defineInRange("opacity", 0.75, 0, 1);

                offsetX = builder
                        .comment("X offset")
                        .defineInRange("offsetX", 0, Integer.MIN_VALUE, Integer.MAX_VALUE);

                offsetY = builder
                        .comment("Y offset")
                        .defineInRange("offsetY", 0, Integer.MIN_VALUE, Integer.MAX_VALUE);

                builder.pop();
            }
        }

        public static class Overlay {
            public final ModConfigSpec.BooleanValue enableOverlay;
            public final ModConfigSpec.IntValue offsetX;
            public final ModConfigSpec.IntValue offsetY;

            Overlay(ModConfigSpec.Builder builder, String comment, String path, boolean defaultOverlay, int defaultX, int defaultY) {
                builder.comment(comment)
                        .push(path);

                enableOverlay = builder
                        .comment("Enables tanks and tool slots overlay, while backpack is worn")
                        .define("enableOverlay", defaultOverlay);

                offsetX = builder
                        .comment("Offsets to left side")
                        .defineInRange("offsetX", defaultX, Integer.MIN_VALUE, Integer.MAX_VALUE);

                offsetY = builder
                        .comment("Offsets to up")
                        .defineInRange("offsetY", defaultY, Integer.MIN_VALUE, Integer.MAX_VALUE);

                builder.pop();
            }
        }
    }

    //Server
    public static final ModConfigSpec serverSpec;
    public static final Server SERVER;
    //Common
    public static final ModConfigSpec commonSpec;
    public static final Common COMMON;
    //Client
    public static final ModConfigSpec clientSpec;
    public static final Client CLIENT;

    static {
        Pair<Server, ModConfigSpec> serverSpecPair = new ModConfigSpec.Builder().configure(Server::new);
        serverSpec = serverSpecPair.getRight();
        SERVER = serverSpecPair.getLeft();
        Pair<Common, ModConfigSpec> commonSpecPair = new ModConfigSpec.Builder().configure(Common::new);
        commonSpec = commonSpecPair.getRight();
        COMMON = commonSpecPair.getLeft();
        Pair<Client, ModConfigSpec> clientSpecPair = new ModConfigSpec.Builder().configure(Client::new);
        clientSpec = clientSpecPair.getRight();
        CLIENT = clientSpecPair.getLeft();
    }
}