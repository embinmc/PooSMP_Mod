package com.tiviacz.travelersbackpack.config;

import net.minecraft.class_1291;
import net.minecraft.class_6880;

public record BackpackEffect(class_6880<class_1291> effect, int minDuration, int maxDuration, int amplifier) {
}
