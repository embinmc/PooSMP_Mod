package com.tiviacz.travelersbackpack.network;

import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.tiviacz.travelersbackpack.util.PacketDistributor;
import com.tiviacz.travelersbackpack.util.Supporters;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1657;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public class SupporterBadgePacket {
    public record Serverbound(boolean isEnabledForPlayer) implements class_8710 {
        public static final class_9154<Serverbound> TYPE = new class_9154<>(class_2960.method_60655(TravelersBackpack.MODID, "supporter_badge_serverbound"));
        public static final class_9139<class_2540, Serverbound> STREAM_CODEC = class_9139.method_56434(
                class_9135.field_48547, Serverbound::isEnabledForPlayer,
                Serverbound::new
        );

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return TYPE;
        }

        public static void handle(final Serverbound message, ServerPlayNetworking.Context ctx) {
            ctx.server().execute(() -> {
                class_1657 player = ctx.player();
                if(message.isEnabledForPlayer && !Supporters.SUPPORTERS.contains(player.method_7334().name())) {
                    if(Supporters.SUPPORTERS_REFERENCE.contains(player.method_7334().name())) {
                        Supporters.SUPPORTERS.add(player.method_7334().name());
                        PacketDistributor.sendToAllPlayers(new Clientbound(true, player.method_7334().name()), ctx.server());
                    }
                } else if(!message.isEnabledForPlayer) {
                    Supporters.SUPPORTERS.remove(player.method_7334().name());
                    PacketDistributor.sendToAllPlayers(new Clientbound(false, player.method_7334().name()), ctx.server());
                }
            });
        }
    }

    public record Clientbound(boolean isEnabledForPlayer, String playerName) implements class_8710 {
        public static final class_9154<Clientbound> TYPE = new class_9154<>(class_2960.method_60655(TravelersBackpack.MODID, "supporter_badge_clientbound"));
        public static final class_9139<class_2540, Clientbound> STREAM_CODEC = class_9139.method_56435(
                class_9135.field_48547, Clientbound::isEnabledForPlayer,
                class_9135.field_48554, Clientbound::playerName,
                Clientbound::new
        );

        @Override
        public class_9154<? extends class_8710> method_56479() {
            return TYPE;
        }

        public static void handle(Clientbound message, ClientPlayNetworking.Context ctx) {
            ctx.client().execute(() -> {
                if(message.isEnabledForPlayer && !Supporters.SUPPORTERS.contains(message.playerName)) {
                    if(Supporters.SUPPORTERS_REFERENCE.contains(message.playerName)) {
                        Supporters.SUPPORTERS.add(message.playerName);
                    }
                } else if(!message.isEnabledForPlayer) {
                    Supporters.SUPPORTERS.remove(message.playerName);
                }
            });
        }
    }
}