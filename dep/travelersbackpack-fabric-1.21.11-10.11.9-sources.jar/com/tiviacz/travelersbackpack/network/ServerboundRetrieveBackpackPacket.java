package com.tiviacz.travelersbackpack.network;

import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.tiviacz.travelersbackpack.common.BackpackManager;
import com.tiviacz.travelersbackpack.attachment.AttachmentUtils;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1723;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record ServerboundRetrieveBackpackPacket(class_1799 backpackHolder) implements class_8710 {
    public static final class_9154<ServerboundRetrieveBackpackPacket> TYPE = new class_9154<>(class_2960.method_60655(TravelersBackpack.MODID, "retrieve_backpack"));

    public static final class_9139<class_9129, ServerboundRetrieveBackpackPacket> STREAM_CODEC = class_9139.method_56434(
            class_1799.field_49268, ServerboundRetrieveBackpackPacket::backpackHolder,
            ServerboundRetrieveBackpackPacket::new
    );

    public static void handle(ServerboundRetrieveBackpackPacket message, ServerPlayNetworking.Context ctx) {
        ctx.server().execute(() -> {
            if(ctx.player().field_7512 instanceof class_1723 menu && menu.method_34255().method_7960()) {
                if(AttachmentUtils.getAttachment(ctx.player()).get().hasBackpack()) {
                    class_1799 backpack = AttachmentUtils.getAttachment(ctx.player()).get().getBackpack().method_7972();
                    AttachmentUtils.getAttachment(ctx.player()).ifPresent(attachment -> {
                        BackpackManager.addBackpack(ctx.player(), backpack);
                        attachment.equipBackpack(new class_1799(class_1802.field_8162, 0), ctx.player());
                        attachment.synchronise(ctx.player());
                    });
                    menu.method_34254(backpack);
                }
            }
        });
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}