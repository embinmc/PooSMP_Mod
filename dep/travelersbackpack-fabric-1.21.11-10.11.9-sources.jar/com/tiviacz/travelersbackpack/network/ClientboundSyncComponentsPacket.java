package com.tiviacz.travelersbackpack.network;

import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.tiviacz.travelersbackpack.attachment.AttachmentUtils;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1657;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.class_9323;

public record ClientboundSyncComponentsPacket(int entityID, class_9323 map) implements class_8710 {
    public static final class_2960 ID = class_2960.method_60655(TravelersBackpack.MODID, "sync_components");
    public static final class_9154<ClientboundSyncComponentsPacket> TYPE = new class_9154<>(ID);

    public static final class_9139<class_9129, ClientboundSyncComponentsPacket> STREAM_CODEC = class_9139.method_56435(
            class_9135.field_49675, ClientboundSyncComponentsPacket::entityID,
            class_9135.method_56896(class_9323.field_50234), ClientboundSyncComponentsPacket::map,
            ClientboundSyncComponentsPacket::new
    );

    public static void handle(ClientboundSyncComponentsPacket message, ClientPlayNetworking.Context ctx) {
        ctx.client().execute(() -> {
            class_1657 player = (class_1657)class_310.method_1551().field_1724.method_73183().method_8469(message.entityID);
            AttachmentUtils.getAttachment(player).ifPresent(attachment -> {
                attachment.applyComponents(message.map());
            });
        });
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}