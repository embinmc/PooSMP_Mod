package com.tiviacz.travelersbackpack.network;

import com.mojang.datafixers.util.Pair;
import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.tiviacz.travelersbackpack.attachment.AttachmentUtils;
import com.tiviacz.travelersbackpack.components.Slots;
import com.tiviacz.travelersbackpack.init.ModDataComponents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import java.util.ArrayList;
import java.util.List;

public record ClientboundSyncAttachmentPacket(int entityID, class_1799 backpack,
                                              boolean removeData) implements class_8710 {
    public static final class_2960 ID = class_2960.method_60655(TravelersBackpack.MODID, "sync_attachment");
    public static final class_9154<ClientboundSyncAttachmentPacket> TYPE = new class_9154<>(ID);

    public static final class_9139<class_9129, ClientboundSyncAttachmentPacket> STREAM_CODEC = class_9139.method_56436(
            class_9135.field_49675, ClientboundSyncAttachmentPacket::entityID,
            class_1799.field_49268, ClientboundSyncAttachmentPacket::backpack,
            class_9135.field_48547, ClientboundSyncAttachmentPacket::removeData,
            ClientboundSyncAttachmentPacket::new
    );

    public ClientboundSyncAttachmentPacket(int entityID, class_1799 serverBackpack) {
        this(entityID, serverBackpack, false);
    }

    public ClientboundSyncAttachmentPacket(int entityID, class_1799 backpack, boolean removeData) {
        this.entityID = entityID;
        //Remove heavy data that is not needed anyways
        class_1799 backpackCopy = backpack.method_7972();
        if(backpackCopy.method_57826(ModDataComponents.BACKPACK_CONTAINER)) {
            backpackCopy.method_57381(ModDataComponents.BACKPACK_CONTAINER);
        }
        //Client needs only visual representation, no need to send the whole data
        if(backpackCopy.method_57826(ModDataComponents.SLOTS)) {
            Slots slots = backpackCopy.method_58694(ModDataComponents.SLOTS);
            List<Pair<Integer, Pair<class_1799, Boolean>>> memorizedStacksHeavy = slots.memory();
            List<Pair<Integer, Pair<class_1799, Boolean>>> reduced = new ArrayList<>();

            for(Pair<Integer, Pair<class_1799, Boolean>> outerPair : memorizedStacksHeavy) {
                int index = outerPair.getFirst();
                class_1799 innerStack = outerPair.getSecond().getFirst().method_7972();
                boolean matchComponents = outerPair.getSecond().getSecond();
                if(matchComponents) {
                    innerStack = new class_1799(innerStack.method_7909(), innerStack.method_7947());
                }
                if(innerStack.method_7960()) {
                    continue;
                }
                reduced.add(Pair.of(index, Pair.of(innerStack, matchComponents)));
            }
            backpackCopy.method_57379(ModDataComponents.SLOTS, new Slots(slots.unsortables(), reduced));
        }
        this.backpack = backpackCopy;
        this.removeData = removeData;
    }

    public static void handle(ClientboundSyncAttachmentPacket message, ClientPlayNetworking.Context ctx) {
        ctx.client().execute(() -> {
            class_1657 player = (class_1657)class_310.method_1551().field_1687.method_8469(message.entityID());
            AttachmentUtils.getAttachment(player).ifPresent(attachment -> {
                if(message.removeData()) {
                    attachment.remove(player);
                } else {
                    attachment.updateBackpack(message.backpack, player);
                }
            });
        });
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}