package com.tiviacz.travelersbackpack.network;

import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.tiviacz.travelersbackpack.config.TravelersBackpackConfig;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record ClientboundSendMessagePacket(boolean drop, class_2338 pos) implements class_8710 {
    public static final class_2960 ID = class_2960.method_60655(TravelersBackpack.MODID, "send_message");
    public static final class_9154<ClientboundSendMessagePacket> TYPE = new class_9154<>(ID);

    public static final class_9139<class_9129, ClientboundSendMessagePacket> STREAM_CODEC = class_9139.method_56435(
            class_9135.field_48547, ClientboundSendMessagePacket::drop,
            class_2338.field_48404, ClientboundSendMessagePacket::pos,
            ClientboundSendMessagePacket::new
    );

    public static void handle(final ClientboundSendMessagePacket message, ClientPlayNetworking.Context ctx) {
        ctx.client().execute(() -> {
            if(TravelersBackpackConfig.CLIENT.sendBackpackCoordinatesMessage.get()) {
                if(class_310.method_1551().field_1724 != null) {
                    class_310.method_1551().field_1705.method_1743().method_1812(class_2561.method_43469(message.drop ? "information.travelersbackpack.backpack_drop" : "information.travelersbackpack.backpack_coords", message.pos().method_10263(), message.pos().method_10264(), message.pos().method_10260()));
                }
            }
        });
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}