package com.tiviacz.travelersbackpack.network;

import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.tiviacz.travelersbackpack.client.screens.BackpackScreen;
import com.tiviacz.travelersbackpack.inventory.upgrades.crafting.CraftingUpgrade;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public record ClientboundUpdateRecipePacket(class_1799 output) implements class_8710 {
    public static final class_2960 ID = class_2960.method_60655(TravelersBackpack.MODID, "update_recipe");
    public static final class_9154<ClientboundUpdateRecipePacket> TYPE = new class_9154<>(ID);

    public static final class_9139<class_9129, ClientboundUpdateRecipePacket> STREAM_CODEC = class_9139.method_56434(
            //Identifier.STREAM_CODEC, ClientboundUpdateRecipePacket::id,
            class_1799.field_49268, ClientboundUpdateRecipePacket::output,
            ClientboundUpdateRecipePacket::new
    );

    // public static final Identifier NULL = Identifier.fromNamespaceAndPath("null", "null");

    // public ClientboundUpdateRecipePacket(@Nullable RecipeHolder<CraftingRecipe> recipe, ItemStack output) {
    //    this(recipe == null ? NULL : recipe.id(), output);
    //  }

    public static void handle(final ClientboundUpdateRecipePacket message, ClientPlayNetworking.Context ctx) {
        ctx.client().execute(() -> {
            //ecipeHolder<CraftingRecipe> recipe = (RecipeHolder<CraftingRecipe>)Minecraft.getInstance().level.getRecipeManager().byKey(message.id()).orElse(null);
            if(class_310.method_1551().field_1755 instanceof BackpackScreen screen) {
                screen.method_17577().getWrapper().getUpgradeManager().getUpgrade(CraftingUpgrade.class).ifPresent(upgrade -> {
                    //screen.getMenu().getWrapper().getUpgradeManager().craftingUpgrade.get().resultSlots.setRecipeUsed(recipe);
                    screen.method_17577().getWrapper().getUpgradeManager().getUpgrade(CraftingUpgrade.class).get().resultSlots.method_5447(0, message.output());
                });
            }
        });
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}