package com.tiviacz.travelersbackpack.network;

import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.tiviacz.travelersbackpack.common.ServerActions;
import com.tiviacz.travelersbackpack.attachment.AttachmentUtils;
import com.tiviacz.travelersbackpack.inventory.BackpackContainer;
import com.tiviacz.travelersbackpack.inventory.upgrades.tanks.TankActions;
import com.tiviacz.travelersbackpack.util.PacketDistributor;
import com.tiviacz.travelersbackpack.util.Reference;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;

public record ServerboundActionTagPacket(class_2487 actionTag) implements class_8710 {
    public static final class_9154<ServerboundActionTagPacket> TYPE = new class_9154<>(class_2960.method_60655(TravelersBackpack.MODID, "action_tag"));
    public static final class_9139<class_9129, ServerboundActionTagPacket> STREAM_CODEC = class_9139.method_56434(
            class_9135.field_48556, ServerboundActionTagPacket::actionTag,
            ServerboundActionTagPacket::new
    );

    public static final int UPGRADE_TAB = 0;
    public static final int OPEN_SCREEN = 1;
    public static final int OPEN_BACKPACK = 2;
    public static final int SORTER = 3;
    public static final int SLEEPING_BAG = 4;
    public static final int FILL_TANK = 5;
    public static final int SWAP_TOOL = 6;
    public static final int TOGGLE_BUTTONS_VISIBILITY = 7;
    public static final int SHOW_TOOL_SLOTS = 8;
    public static final int REMOVE_UPGRADE = 9;
    public static final int OPEN_SETTINGS = 10;
    public static final int SWITCH_HOSE_MODE = 11;
    public static final int SWITCH_HOSE_TANK = 12;
    public static final int TOGGLE_VISIBILITY = 13;
    public static final int ABILITY_SLIDER = 14;
    public static final int EQUIP_BACKPACK = 15;
    public static final int SET_STACK = 16;

    public static void handle(ServerboundActionTagPacket message, ServerPlayNetworking.Context ctx) {
        ctx.server().execute(() -> {
            class_3222 player = ctx.player();
            class_2487 actionTag = message.actionTag();
            int actionType = actionTag.method_68083("ActionType", -1);
            switch(actionType) {
                case UPGRADE_TAB -> {
                    int slot = actionTag.method_68083("Arg0", -1);
                    boolean open = actionTag.method_68566("Arg1", false);
                    int packetType = actionTag.method_68083("Arg2", -1);
                    boolean fromMenu = actionTag.method_68566("Arg3", true);
                    ServerActions.modifyUpgradeTab(player, slot, open, packetType, fromMenu);
                }
                case OPEN_SCREEN -> {
                    if(AttachmentUtils.isWearingBackpack(player)) {
                        BackpackContainer.openBackpack(player, AttachmentUtils.getWearingBackpack(player), Reference.WEARABLE_SCREEN_ID);
                    }
                }
                case OPEN_BACKPACK -> {
                    int index = actionTag.method_68083("Arg0", -1);
                    boolean fromSlot = actionTag.method_68566("Arg1", false);
                    ServerActions.openBackpackFromSlot(player, index, fromSlot);
                }
                case SORTER -> {
                    int button = actionTag.method_68083("Arg0", -1);
                    boolean shiftPressed = actionTag.method_68566("Arg1", false);
                    ServerActions.sortBackpack(player, button, shiftPressed);
                }
                case SLEEPING_BAG -> {
                    class_2338 pos = class_2338.field_25064.parse(class_2509.field_11560, actionTag.method_10580("Arg0")).getOrThrow();
                    boolean isEquipped = actionTag.method_68566("Arg1", false);
                    ServerActions.toggleSleepingBag(player, pos, isEquipped);
                }
                case FILL_TANK -> {
                    boolean leftTank = actionTag.method_68566("Arg0", false);
                    TankActions.fillTank(player, leftTank);
                }
                case SWAP_TOOL -> {
                    int slot = actionTag.method_68083("Arg0", -1);
                    int button = actionTag.method_68083("Arg1", 0);
                    ServerActions.swapTool(player, slot, button);
                }
                case TOGGLE_BUTTONS_VISIBILITY -> ServerActions.toggleButtonsVisibility(player);
                case SHOW_TOOL_SLOTS -> {
                    boolean show = actionTag.method_68566("Arg0", false);
                    ServerActions.showToolSlots(player, show);
                }
                case REMOVE_UPGRADE -> {
                    int slot = actionTag.method_68083("Arg0", -1);
                    ServerActions.removeBackpackUpgrade(player, slot);
                }
                case OPEN_SETTINGS -> {
                    int entityId = actionTag.method_68083("Arg0", -1);
                    boolean open = actionTag.method_68566("Arg1", false);
                    ServerActions.openBackpackSettings(player, entityId, open);
                }
                case SWITCH_HOSE_MODE -> {
                    int mode = actionTag.method_68083("Arg0", -1);
                    ServerActions.switchHoseMode(player, mode);
                }
                case SWITCH_HOSE_TANK -> {
                    int tank = actionTag.method_68083("Arg0", -1);
                    ServerActions.toggleHoseTank(player, tank);
                }
                case TOGGLE_VISIBILITY -> ServerActions.toggleVisibility(player);
                case ABILITY_SLIDER -> {
                    boolean sliderValue = actionTag.method_68566("Arg0", false);
                    ServerActions.switchAbilitySlider(player, sliderValue);
                }
                case EQUIP_BACKPACK -> {
                    boolean equip = actionTag.method_68566("Arg0", false);
                    ServerActions.equipBackpack(player, equip);
                }
                case SET_STACK -> {
                    int type = actionTag.method_68083("Arg0", 0);
                    class_1799 stack = class_1799.field_49266.parse(class_2509.field_11560, actionTag.method_68568("Arg1")).getOrThrow();
                    int slot = actionTag.method_68083("Arg2", -1);
                    ServerActions.setStack(player, type, stack, slot);
                }
            }
        });
    }

    public static void create(int type, Object... args) {
        PacketDistributor.sendToServer(new ServerboundActionTagPacket(createPacketTag(type, args)));
    }

    public static class_2487 createPacketTag(int type, Object... args) {
        class_2487 tag = new class_2487();
        tag.method_10569("ActionType", type);
        for(int i = 0; i < args.length; i++) {
            String argName = "Arg" + i;
            if(args[i] instanceof class_2338) {
                tag.method_10566(argName, class_2338.field_25064.encodeStart(class_2509.field_11560, (class_2338)args[i]).getOrThrow());
            } else if(args[i] instanceof Boolean) {
                tag.method_10556(argName, (boolean)args[i]);
            } else if(args[i] instanceof Byte) {
                tag.method_10567(argName, (byte)args[i]);
            } else if(args[i] instanceof Integer) {
                tag.method_10569(argName, (int)args[i]);
            } else if(args[i] instanceof Double) {
                tag.method_10549(argName, (double)args[i]);
            } else if(args[i] instanceof class_1799 itemstack) {
                tag.method_10566(argName, class_1799.field_49266.encodeStart(class_2509.field_11560, itemstack).getOrThrow());
            }
        }
        return tag;
    }

    @Override
    public class_9154<? extends class_8710> method_56479() {
        return TYPE;
    }
}