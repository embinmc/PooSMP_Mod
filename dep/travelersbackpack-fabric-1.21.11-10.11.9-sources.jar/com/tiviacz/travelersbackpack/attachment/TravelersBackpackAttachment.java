package com.tiviacz.travelersbackpack.attachment;

import com.mojang.serialization.Codec;
import com.tiviacz.travelersbackpack.inventory.BackpackWrapper;
import com.tiviacz.travelersbackpack.item.TravelersBackpackItem;
import com.tiviacz.travelersbackpack.network.ClientboundSyncAttachmentPacket;
import com.tiviacz.travelersbackpack.network.ClientboundSyncComponentsPacket;
import com.tiviacz.travelersbackpack.util.PacketDistributor;
import com.tiviacz.travelersbackpack.util.Reference;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.minecraft.class_9323;

public class TravelersBackpackAttachment {
    public static Codec<TravelersBackpackAttachment> CODEC = class_1799.field_49266.xmap(TravelersBackpackAttachment::new, TravelersBackpackAttachment::getBackpack);
    public static class_9139<class_9129, TravelersBackpackAttachment> STREAM_CODEC = class_1799.field_49268.method_56432(TravelersBackpackAttachment::new, TravelersBackpackAttachment::getBackpack);

    public BackpackWrapper backpackWrapper;
    public class_1799 backpack = new class_1799(class_1802.field_8162, 0);

    public TravelersBackpackAttachment(class_1799 backpack) {
        this.backpack = backpack;
    }

    public boolean hasBackpack() {
        return this.backpack.method_7909() instanceof TravelersBackpackItem;
    }

    public class_1799 getBackpack() {
        return this.backpack;
    }

    public void equipBackpack(class_1799 stack, class_1657 player) {
        this.remove(player);
        if(!(stack.method_7909() instanceof TravelersBackpackItem)) return;

        this.backpack = stack;
        this.backpackWrapper = new BackpackWrapper(this.backpack, Reference.WEARABLE_SCREEN_ID, player, player.method_73183());
        this.backpackWrapper.setBackpackOwner(player);

        //Update client
        synchronise(player);
    }

    public void updateBackpack(class_1799 stack, class_1657 player) {
        if(this.backpackWrapper != null) {
            this.backpack = stack;
            this.backpackWrapper.setBackpackStack(this.backpack);
        } else {
            equipBackpack(stack, player);
        }
    }

    public void applyComponents(class_9323 map) {
        if(this.backpackWrapper != null) {
            this.backpack.method_57365(map);
            this.backpackWrapper.setBackpackStack(this.backpack);
        }
    }

    public void removeWearable() {
        this.backpack = new class_1799(class_1802.field_8162, 0);
    }

    public void removeWrapper() {
        if(this.backpackWrapper != null) {
            this.backpackWrapper = null;
        }
    }

    public void remove(class_1657 player) {
        removeWearable();
        removeWrapper();

        //Update client to remove old backpack wrapper
        if(player.method_73183() != null && !player.method_73183().method_8608()) {
            PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, new ClientboundSyncAttachmentPacket(player.method_5628(), this.backpack, true));
        }
    }

    public BackpackWrapper getWrapper() {
        return this.backpackWrapper;
    }

    public void synchronise(class_1657 player) {
        if(player != null && !player.method_73183().method_8608()) {
            AttachmentUtils.getAttachment(player).ifPresent(cap -> PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, new ClientboundSyncAttachmentPacket(player.method_5628(), this.backpack)));
        }
    }

    public void synchronise(class_9323 map, class_1657 player) {
        if(player != null && !player.method_73183().method_8608()) {
            AttachmentUtils.getAttachment(player).ifPresent(cap -> PacketDistributor.sendToPlayersTrackingEntityAndSelf(player, new ClientboundSyncComponentsPacket(player.method_5628(), map)));
        }
    }
}