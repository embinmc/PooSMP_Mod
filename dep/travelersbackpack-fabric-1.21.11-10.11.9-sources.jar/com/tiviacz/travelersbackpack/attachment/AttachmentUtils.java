package com.tiviacz.travelersbackpack.attachment;

import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.tiviacz.travelersbackpack.init.ModAttachmentTypes;
import com.tiviacz.travelersbackpack.inventory.BackpackWrapper;
import com.tiviacz.travelersbackpack.item.TravelersBackpackItem;
import dev.emi.trinkets.api.TrinketsApi;
import io.wispforest.accessories.api.AccessoriesCapability;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;
import java.util.function.Supplier;

public class AttachmentUtils {
    public static Optional<TravelersBackpackAttachment> getAttachment(class_1657 player) {
        if(player == null) {
            return Optional.empty();
        }
        return Optional.of(player.getAttachedOrCreate(ModAttachmentTypes.TRAVELERS_BACKPACK));
    }

    public static void registerJoinEquip() {
        ServerPlayerEvents.JOIN.register((player) -> {
            AttachmentUtils.getAttachment(player).ifPresent(attachment -> {
                attachment.equipBackpack(attachment.getBackpack(), player);
            });
        });
    }

    public static void synchronise(class_1657 player) {
        AttachmentUtils.getAttachment(player).ifPresent(a -> a.synchronise(player));
    }

    public static boolean isWearingBackpack(class_1657 player) {
        if(TravelersBackpack.enableIntegration()) {
            if(TravelersBackpack.enableTrinkets()) {
                if(TrinketsApi.getTrinketComponent(player).isPresent()) {
                    return TrinketsApi.getTrinketComponent(player).get().isEquipped(t -> t.method_7909() instanceof TravelersBackpackItem);
                }
            } else {
                if(AccessoriesCapability.get(player) != null) {
                    return AccessoriesCapability.get(player).isEquipped(t -> t.method_7909() instanceof TravelersBackpackItem);
                }
            }
            return false;
        }
        if(getAttachment(player).isPresent()) {
            return getAttachment(player).get().hasBackpack() && getAttachment(player).get().getBackpack().method_7909() instanceof TravelersBackpackItem;
        }
        return false;
    }

    public static class_1799 getWearingBackpack(class_1657 player) {
        if(TravelersBackpack.enableIntegration()) {
            if(TravelersBackpack.enableTrinkets()) {
                return isWearingBackpack(player) ? TrinketsApi.getTrinketComponent(player).get().getEquipped(t -> t.method_7909() instanceof TravelersBackpackItem).getFirst().method_15441() : class_1799.field_8037;
            } else {
                if(isWearingBackpack(player)) {
                    if(AccessoriesCapability.get(player).getFirstEquipped(t -> t.method_7909() instanceof TravelersBackpackItem) != null) {
                        return AccessoriesCapability.get(player).getFirstEquipped(t -> t.method_7909() instanceof TravelersBackpackItem).stack();
                    }
                }
            }
            return class_1799.field_8037;
        }
        return isWearingBackpack(player) ? getAttachment(player).get().getBackpack() : class_1799.field_8037;
    }

    public static void equipBackpack(class_1657 player, class_1799 stack) {
        if(getAttachment(player).isPresent() && !isWearingBackpack(player)) {
            getAttachment(player).ifPresent(attachment -> attachment.equipBackpack(stack, player));
            player.method_73183().method_8396(null, player.method_24515(), class_3417.field_14581.comp_349(), class_3419.field_15248, 1.0F, (1.0F + (player.method_73183().field_9229.method_43057() - player.method_73183().field_9229.method_43057()) * 0.2F) * 0.7F);

            //Sync
            synchronise(player);
        }
    }

    @Nullable
    public static BackpackWrapper getBackpackWrapper(class_1657 player, class_1799 stack) {
        return getBackpackWrapper(player, stack, LOAD_ALL.get());
    }

    @Nullable
    public static BackpackWrapper getBackpackWrapper(class_1657 player, class_1799 stack, int[] dataLoad) {
        if(TravelersBackpack.enableIntegration()) {
            if(isWearingBackpack(player)) {
                return BackpackWrapper.getBackpackWrapper(player, stack, dataLoad);
            }
            return null;
        }
        if(isWearingBackpack(player)) {
            return AttachmentUtils.getAttachment(player).map(TravelersBackpackAttachment::getWrapper).orElse(null);
        }
        return null;
    }

    //Artificial wrapper for actions that do not require loading items
    @Nullable
    public static BackpackWrapper getBackpackWrapperArtificial(class_1657 player) {
        return getBackpackWrapper(player, NO_ITEMS.get());
    }

    //Fully loaded wrapper
    @Nullable
    public static BackpackWrapper getBackpackWrapper(class_1657 player) {
        return getBackpackWrapper(player, LOAD_ALL.get());
    }

    public static final Supplier<int[]> LOAD_ALL = () -> new int[]{1, 1, 1};
    public static final Supplier<int[]> NO_ITEMS = () -> new int[]{0, 0, 0};
    public static final Supplier<int[]> STORAGE_ONLY = () -> new int[]{1, 0, 0};
    public static final Supplier<int[]> UPGRADES_ONLY = () -> new int[]{0, 1, 0};
    public static final Supplier<int[]> TOOLS_ONLY = () -> new int[]{0, 0, 1};

    //Situational wrapper
    @Nullable
    public static BackpackWrapper getBackpackWrapper(class_1657 player, int[] dataLoad) {
        if(TravelersBackpack.enableIntegration()) {
            if(isWearingBackpack(player)) {
                return BackpackWrapper.getBackpackWrapper(player, getWearingBackpack(player), dataLoad);
            }
            return null;
        }
        if(isWearingBackpack(player)) {
            return AttachmentUtils.getAttachment(player).map(TravelersBackpackAttachment::getWrapper).orElse(null);
        }
        return null;
    }
}