package com.tiviacz.travelersbackpack.inventory.handler;

import com.tiviacz.travelersbackpack.util.InventoryHelper;
import net.minecraft.class_11343;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2371;


public class ItemStackHandler extends class_1277 implements IItemHandlerModifiable {
    public class_2371<class_1799> stacks;

    public ItemStackHandler() {
        this(1);
    }

    public ItemStackHandler(int size) {
        stacks = class_2371.method_10213(size, class_1799.field_8037);
    }

    public ItemStackHandler(class_2371<class_1799> stacks) {
        this.stacks = stacks;
    }

    public void setSize(int size) {
        stacks = class_2371.method_10213(size, class_1799.field_8037);
    }

    public void setStackInSlot(int slot, class_1799 stack) {
        validateSlotIndex(slot);
        this.stacks.set(slot, stack);
        onContentsChanged(slot);
    }

    public int getSlots() {
        return stacks.size();
    }

    public class_1799 getStackInSlot(int slot) {
        validateSlotIndex(slot);
        return this.stacks.get(slot);
    }

    public class_1799 insertItem(int slot, class_1799 stack, boolean simulate) {
        if(stack.method_7960())
            return class_1799.field_8037;

        if(!isItemValid(slot, stack))
            return stack;

        validateSlotIndex(slot);

        class_1799 existing = this.stacks.get(slot);

        int limit = getStackLimit(slot, stack);

        if(!existing.method_7960()) {
            if(!class_1799.method_31577(stack, existing))
                return stack;

            limit -= existing.method_7947();
        }

        if(limit <= 0)
            return stack;

        boolean reachedLimit = stack.method_7947() > limit;

        if(!simulate) {
            if(existing.method_7960()) {
                this.stacks.set(slot, reachedLimit ? stack.method_46651(limit) : stack);
            } else {
                existing.method_7933(reachedLimit ? limit : stack.method_7947());
            }
            onContentsChanged(slot);
        }

        return reachedLimit ? stack.method_46651(stack.method_7947() - limit) : class_1799.field_8037;
    }

    public class_1799 extractItem(int slot, int amount, boolean simulate) {
        if(amount == 0)
            return class_1799.field_8037;

        validateSlotIndex(slot);

        class_1799 existing = this.stacks.get(slot);

        if(existing.method_7960())
            return class_1799.field_8037;

        int toExtract = Math.min(amount, existing.method_7914());

        if(existing.method_7947() <= toExtract) {
            if(!simulate) {
                this.stacks.set(slot, class_1799.field_8037);
                onContentsChanged(slot);
                return existing;
            } else {
                return existing.method_7972();
            }
        } else {
            if(!simulate) {
                this.stacks.set(slot, existing.method_46651(existing.method_7947() - toExtract));
                onContentsChanged(slot);
            }

            return existing.method_46651(toExtract);
        }
    }

    public int getSlotLimit(int slot) {
        return 8192;
    }

    protected int getStackLimit(int slot, class_1799 stack) {
        return Math.min(getSlotLimit(slot), stack.method_7914());
    }

    public boolean isItemValid(int slot, class_1799 stack) {
        return true;
    }

    public void serialize(class_11372 output) {
        class_11372.class_11373<class_11343> itemList = output.method_71467("Items", class_11343.field_60354);
        for(int i = 0; i < stacks.size(); i++) {
            var stack = stacks.get(i);
            if(!stack.method_7960()) {
                itemList.method_71484(new class_11343(i, stack));
            }
        }
        output.method_71465("Size", stacks.size());
    }

    public void deserialize(class_11368 input) {
        setSize(input.method_71424("Size", stacks.size()));
        input.method_71437("Items", class_11343.field_60354).forEach(slot -> {
            if(slot.method_71368(stacks.size())) {
                stacks.set(slot.comp_4211(), slot.comp_4212());
            }
        });
    }

    protected void validateSlotIndex(int slot) {
        if(slot < 0 || slot >= stacks.size())
            throw new RuntimeException("Slot " + slot + " not in valid range - [0," + stacks.size() + ")");
    }

    protected void onLoad() {
    }

    protected void onContentsChanged(int slot) {
    }

    @Override
    public int method_5439() {
        return getSlots();
    }

    @Override
    public boolean method_5442() {
        return InventoryHelper.isEmpty(this);
    }

    @Override
    public class_1799 method_5438(int slot) {
        return getStackInSlot(slot);
    }

    @Override
    public class_1799 method_5434(int slot, int amount) {
        return extractItem(slot, amount, false);
    }

    @Override
    public class_1799 method_5441(int slot) {
        return extractItem(slot, getStackInSlot(slot).method_7947(), false);
    }

    @Override
    public void method_5447(int slot, class_1799 stack) {
        setStackInSlot(slot, stack);
    }

    @Override
    public void method_5431() {

    }

    @Override
    public boolean method_5443(class_1657 player) {
        return true;
    }

    @Override
    public void method_5448() {
        this.stacks.clear();
    }

    @Override
    public boolean method_5437(int slot, class_1799 stack) {
        return isItemValid(slot, stack);
    }
}