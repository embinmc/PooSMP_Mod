package com.tiviacz.travelersbackpack.inventory.handler;

import net.minecraft.class_1799;

public interface IItemHandlerModifiable {
    int getSlots();

    class_1799 getStackInSlot(int slot);

    class_1799 insertItem(int slot, class_1799 stack, boolean simulate);

    class_1799 extractItem(int slot, int amount, boolean simulate);

    int getSlotLimit(int slot);

    boolean isItemValid(int slot, class_1799 stack);

    void setStackInSlot(int slot, class_1799 stack);
}
