package com.tiviacz.travelersbackpack.inventory;

import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariantAttributes;
import net.minecraft.class_2561;

public class CommonFluid {
    public static FluidVariantWrapper empty() {
        return FluidVariantWrapper.blank();
    }

    public static class_2561 getFluidName(FluidVariantWrapper fluidStack) {
        return FluidVariantAttributes.getName(fluidStack.fluidVariant());
    }
}