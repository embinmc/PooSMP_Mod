package com.tiviacz.travelersbackpack.inventory.upgrades.crafting;

import com.tiviacz.travelersbackpack.client.screens.BackpackScreen;
import com.tiviacz.travelersbackpack.client.screens.widgets.UpgradeWidgetBase;
import com.tiviacz.travelersbackpack.client.screens.widgets.WidgetElement;
import com.tiviacz.travelersbackpack.compat.craftingtweaks.BackpackCraftingGridAddition;
import com.tiviacz.travelersbackpack.compat.craftingtweaks.ICraftingTweaks;
import com.tiviacz.travelersbackpack.inventory.upgrades.Point;
import com.tiviacz.travelersbackpack.inventory.upgrades.ResultArrowElement;
import net.minecraft.class_10799;
import net.minecraft.class_11909;
import net.minecraft.class_332;

public class CraftingWidget extends UpgradeWidgetBase<CraftingUpgrade> {
    private final ResultArrowElement resultArrowElement;
    public final WidgetElement arrowElement = new WidgetElement(new Point(8, 91), new Point(12, 12));
    private static ICraftingTweaks craftingTweaksAddition = ICraftingTweaks.EMPTY;

    public CraftingWidget(BackpackScreen screen, CraftingUpgrade upgrade, Point pos) {
        super(screen, upgrade, pos, new Point(51, 0), "screen.travelersbackpack.crafting_upgrade");
        this.resultArrowElement = new ResultArrowElement(screen, this, this.arrowElement);
        this.getCraftingTweaksAddition().setScreen(screen);
        if(isTabOpened()) {
            this.getCraftingTweaksAddition().onCraftingSlotsDisplayed();
        }
    }

    @Override
    public void renderBg(class_332 guiGraphics, int x, int y, int mouseX, int mouseY) {
        if(isTabOpened()) {
            if(isCraftingTweaksAdditionEnabled()) {
                guiGraphics.method_25290(class_10799.field_56883, BackpackScreen.TABS, pos.x(), pos.y(), tabUv.x(), tabUv.y(), width - 19, height, 256, 256);
                guiGraphics.method_25290(class_10799.field_56883, BackpackScreen.TABS, pos.x() + width - 20, pos.y(), tabUv.x() + 66, tabUv.y(), 20, height, 256, 256);
            } else {
                guiGraphics.method_25290(class_10799.field_56883, BackpackScreen.TABS, pos.x(), pos.y(), tabUv.x(), tabUv.y(), width, height, 256, 256);
            }
            guiGraphics.method_51427(screen.getWrapper().getUpgrades().getStackInSlot(this.dataHolderSlot), pos.x() + 4, pos.y() + 4);
        }
        this.resultArrowElement.renderBg(guiGraphics, x, y, mouseX, mouseY);
    }

    @Override
    public void renderTooltip(class_332 guiGraphics, int mouseX, int mouseY) {
        super.renderTooltip(guiGraphics, mouseX, mouseY);
        this.resultArrowElement.renderTooltip(guiGraphics, mouseX, mouseY);
    }

    @Override
    public boolean method_25402(class_11909 event, boolean bl) {
        if(this.resultArrowElement.mouseClicked(event)) {
            return true;
        }
        if(isMouseOverIcon(event)) {
            if(this.upgrade.isTabOpened()) {
                craftingTweaksAddition.onCraftingSlotsHidden();
            } else {
                craftingTweaksAddition.onCraftingSlotsDisplayed();
            }
        }
        return super.method_25402(event, bl);
    }

    public static void setCraftingTweaksAddition(ICraftingTweaks addition) {
        craftingTweaksAddition = addition;
    }

    public ICraftingTweaks getCraftingTweaksAddition() {
        return craftingTweaksAddition;
    }

    public boolean isCraftingTweaksAdditionEnabled() {
        return craftingTweaksAddition instanceof BackpackCraftingGridAddition;
    }
}