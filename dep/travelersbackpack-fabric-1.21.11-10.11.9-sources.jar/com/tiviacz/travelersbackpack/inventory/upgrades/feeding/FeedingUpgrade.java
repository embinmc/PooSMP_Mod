package com.tiviacz.travelersbackpack.inventory.upgrades.feeding;

import com.tiviacz.travelersbackpack.client.screens.BackpackScreen;
import com.tiviacz.travelersbackpack.client.screens.widgets.WidgetBase;
import com.tiviacz.travelersbackpack.config.TravelersBackpackConfig;
import com.tiviacz.travelersbackpack.init.ModDataComponents;
import com.tiviacz.travelersbackpack.inventory.BackpackWrapper;
import com.tiviacz.travelersbackpack.inventory.UpgradeManager;
import com.tiviacz.travelersbackpack.inventory.handler.ItemStackHandler;
import com.tiviacz.travelersbackpack.inventory.upgrades.*;
import com.tiviacz.travelersbackpack.inventory.upgrades.filter.FilterHandler;
import com.tiviacz.travelersbackpack.util.InventoryHelper;
import com.tiviacz.travelersbackpack.util.Reference;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_3218;
import net.minecraft.class_4174;
import net.minecraft.class_5819;
import net.minecraft.class_9334;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public class FeedingUpgrade extends FilterUpgradeBase<FeedingUpgrade, FeedingFilterSettings> implements IEnable, ITickableUpgrade {
    private static final int STILL_HUNGRY_COOLDOWN = 10;
    private static final double FEEDING_RANGE = 3.0D;

    public class_2338 particlePos = null;

    public FeedingUpgrade(UpgradeManager manager, int dataHolderSlot, class_2371<class_1799> filter) {
        super(manager, dataHolderSlot, new Point(66, 49),
                TravelersBackpackConfig.SERVER.backpackUpgrades.feedingUpgradeSettings.filterSlotCount.get(),
                TravelersBackpackConfig.SERVER.backpackUpgrades.feedingUpgradeSettings.slotsInRow.get(), filter, List.of());
    }

    @Override
    public boolean hasTagSelector() {
        return false;
    }

    @Override
    public List<Integer> getFilter() {
        return getDataHolderStack().method_58695(ModDataComponents.FILTER_SETTINGS, List.of(1, 1, 0));
    }

    @Override
    public FeedingFilterSettings createFilterSettings(UpgradeManager manager, class_2371<class_1799> filter, List<String> filterTags) {
        return new FeedingFilterSettings(manager.getWrapper().getStorage(), filter.stream().limit(getFilterSlotCount()).filter(stack -> !stack.method_7960()).toList(), getFilter());
    }

    public boolean canEat(class_1657 player, class_1799 stack) {
        return getFilterSettings().matchesFilter(player, stack) && !player.method_7357().method_7904(stack); //Cooldown patch for everlasting foods from Artifacts
    }

    @Override
    @Environment(EnvType.CLIENT)
    public WidgetBase<BackpackScreen> createWidget(BackpackScreen screen, int x, int y) {
        return new FeedingWidget(screen, this, new Point(screen.getGuiLeft() + x, screen.getGuiTop() + y));
    }

    @Override
    protected FilterHandler createFilter(class_2371<class_1799> stacks, int size) {
        return new FilterHandler(stacks, size) {
            @Override
            protected void onContentsChanged(int slot) {
                updateDataHolderUnchecked(ModDataComponents.BACKPACK_CONTAINER, InventoryHelper.itemsToList(size, filter));

                getFilterSettings().updateFilter(getDataHolderStack().method_58694(ModDataComponents.BACKPACK_CONTAINER).getItems());
            }

            @Override
            public boolean isItemValid(int slot, class_1799 stack) {
                return stack.method_57826(class_9334.field_50075);
            }
        };
    }

    @Override
    public int getTickRate() {
        return TravelersBackpackConfig.SERVER.backpackUpgrades.feedingUpgradeSettings.tickRate.get();
    }

    @Override
    public void tick(@Nullable class_1657 player, class_1937 level, class_2338 pos, int currentTick) {
        if(getCooldown() == 0) {
            return;
        }
        if(currentTick % getCooldown() != 0) {
            return;
        }

        if(level.method_8608()) {
            return;
        }

        boolean stillHungry = false;
        if(getUpgradeManager().getWrapper().getScreenID() == Reference.BLOCK_ENTITY_SCREEN_ID) {
            AtomicBoolean stillHungryPlayer = new AtomicBoolean(false);
            this.particlePos = pos;
            level.method_18023(class_1299.field_6097, new class_238(pos).method_1014(FEEDING_RANGE), p -> true).forEach(p -> stillHungryPlayer.set(stillHungryPlayer.get() || feedPlayerAndGetHungry(p, level)));
            stillHungry = stillHungryPlayer.get();
            this.particlePos = null;
        } else {
            if(feedPlayerAndGetHungry(player, level)) {
                stillHungry = true;
            }
        }

        if(stillHungry) {
            setCooldown(STILL_HUNGRY_COOLDOWN);
            return;
        }

        if(!hasCooldown() || getCooldown() != getTickRate()) {
            setCooldown(getTickRate());
        }
    }

    private boolean feedPlayerAndGetHungry(class_1657 player, class_1937 level) {
        int hungerLevel = 20 - player.method_7344().method_7586();
        if(hungerLevel == 0 || level.method_8608()) {
            return false;
        }
        //Load storage if not loaded in artificial wrapper
        getUpgradeManager().getWrapper().loadAdditionally(BackpackWrapper.STORAGE_ID);
        return tryFeedingFoodFromStorage(level, hungerLevel, player) && player.method_7344().method_7586() < 20;
    }

    private boolean tryFeedingFoodFromStorage(class_1937 level, int hungerLevel, class_1657 player) {
        ItemStackHandler storage = getUpgradeManager().getWrapper().getStorageForInputOutput();
        return InventoryHelper.iterate(storage, (slot, stack) -> tryFeedingStack(level, hungerLevel, player, slot, stack, storage));
    }

    private boolean tryFeedingStack(class_1937 level, int hungerLevel, class_1657 player, Integer slot, class_1799 stack, ItemStackHandler backpackStorage) {
        if(isEdible(stack, player) && canEat(player, stack)) {
            class_1799 mainHandItem = player.method_6047();
            player.method_31548().method_67533().set(player.method_31548().method_67532(), stack);

            class_1799 singleItemCopy = stack.method_7972();
            singleItemCopy.method_7939(1);

            if(singleItemCopy.method_7913(level, player, class_1268.field_5808) == class_1269.field_21466) {
                player.method_31548().method_67533().set(player.method_31548().method_67532(), mainHandItem);

                stack.method_7934(1);
                backpackStorage.setStackInSlot(slot, stack); //#TODO?

                class_1799 resultItem = singleItemCopy.method_7910(level, player); //EventHooks.onItemUseFinish(player, singleItemCopy, 0, singleItemCopy.getItem().finishUsingItem(singleItemCopy, level, player));
                if(!resultItem.method_7960()) {
                    class_1799 insertResult = InventoryHelper.addItemStackToHandler(backpackStorage, resultItem, false);
                    if(!insertResult.method_7960()) {
                        player.method_7328(insertResult, true);
                    }
                }
                if(this.particlePos != null) {
                    this.spawnHeartParticles(level, this.particlePos);
                }
                return true;
            }
            player.method_31548().method_67533().set(player.method_31548().method_67532(), mainHandItem);
        }
        return false;
    }

    private static boolean isEdible(class_1799 stack, class_1309 player) {
        if(!stack.method_57826(class_9334.field_50075)) {
            return false;
        }
        class_4174 foodProperties = stack.method_58694(class_9334.field_50075);
        return foodProperties != null && foodProperties.comp_2491() >= 1;
    }

    private void spawnHeartParticles(class_1937 level, class_2338 pos) {
        if(level instanceof class_3218 serverLevel) {
            class_5819 rand = level.method_8409();
            double centerX = pos.method_10263() + 0.5;
            double centerY = pos.method_10264() + 0.5;
            double centerZ = pos.method_10260() + 0.5;

            double radius = 0.5;
            double angle = rand.method_43058() * Math.PI * 2;
            double distance = rand.method_43058() * radius;
            double offsetX = Math.cos(angle) * distance;
            double offsetZ = Math.sin(angle) * distance;
            double offsetY = (rand.method_43058() - 0.5) * 0.6;

            serverLevel.method_65096(class_2398.field_11201, centerX + offsetX, centerY + offsetY, centerZ + offsetZ, 0, 0.0, 0.0, 0.0, 1.0);
        }
    }
}