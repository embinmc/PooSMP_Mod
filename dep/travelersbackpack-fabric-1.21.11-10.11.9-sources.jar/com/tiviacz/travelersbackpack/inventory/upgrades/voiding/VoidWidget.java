package com.tiviacz.travelersbackpack.inventory.upgrades.voiding;

import com.tiviacz.travelersbackpack.TravelersBackpack;
import com.tiviacz.travelersbackpack.client.screens.BackpackScreen;
import com.tiviacz.travelersbackpack.client.screens.BackpackSettingsScreen;
import com.tiviacz.travelersbackpack.client.screens.widgets.FilterUpgradeWidgetBase;
import com.tiviacz.travelersbackpack.client.screens.widgets.WidgetElement;
import com.tiviacz.travelersbackpack.common.ServerActions;
import com.tiviacz.travelersbackpack.config.TravelersBackpackConfig;
import com.tiviacz.travelersbackpack.inventory.menu.slot.DisabledSlot;
import com.tiviacz.travelersbackpack.inventory.upgrades.Point;
import com.tiviacz.travelersbackpack.inventory.upgrades.filter.ButtonStates;
import com.tiviacz.travelersbackpack.inventory.upgrades.filter.FilterButton;
import com.tiviacz.travelersbackpack.inventory.upgrades.tanks.TankWidget;
import com.tiviacz.travelersbackpack.inventory.upgrades.tanks.TanksUpgrade;
import com.tiviacz.travelersbackpack.network.ServerboundActionTagPacket;
import com.tiviacz.travelersbackpack.util.TextUtils;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import net.minecraft.class_10799;
import net.minecraft.class_11909;
import net.minecraft.class_124;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_7833;

public class VoidWidget extends FilterUpgradeWidgetBase<VoidWidget, VoidUpgrade> {
    private static final class_2960 TRASH_UPGRADE = class_2960.method_60655(TravelersBackpack.MODID, "textures/item/void_upgrade.png");
    private static final int RED_HIGHLIGHT_COLOR = 2143884822;
    private static final int RED_ARROW_COLOR = 0xBFAA0000;
    private static final int HIGHLIGHT_TANK_COLOR = -2130706433;
    private final WidgetElement trashBinSlot = new WidgetElement(new Point(25, 4), new Point(16, 16));
    public final List<Integer> selectedSlots = new ArrayList<>();
    public final List<Integer> selectedTanks = new ArrayList<>();

    private boolean tickAnimation = false;
    private float progress = 0.0F;
    private boolean hoveringTrashBin = false;

    public VoidWidget(BackpackScreen screen, VoidUpgrade upgrade, Point pos) {
        super(screen, upgrade, pos, new Point(137, 0), "screen.travelersbackpack.void_upgrade");

        FilterButton<VoidWidget> whitelistButton = new FilterButton<>(this, upgrade.getFilter().get(VoidFilterSettings.ALLOW_MODE), ButtonStates.ALLOW, new Point(pos.x() + 6, pos.y() + 22));
        FilterButton<VoidWidget> objectButton = new FilterButton<>(this, upgrade.getFilter().get(VoidFilterSettings.OBJECT_CATEGORY), ButtonStates.OBJECT_TYPE, new Point(pos.x() + 6 + 18, pos.y() + 22));
        FilterButton<VoidWidget> ignoreModeButton = new FilterButton<>(this, upgrade.getFilter().get(VoidFilterSettings.IGNORE_MODE), ButtonStates.IGNORE_MODE, new Point(pos.x() + 6 + 36, pos.y() + 22));

        this.addFilterButton(whitelistButton);
        this.addFilterButton(objectButton);
        this.addFilterButton(ignoreModeButton);
    }

    @Override
    public void renderBg(class_332 guiGraphics, int x, int y, int mouseX, int mouseY) {
        super.renderBg(guiGraphics, x, y, mouseX, mouseY);
        this.renderMatchContentsSlotOverlay(guiGraphics, upgrade.getFilter(), VoidFilterSettings.ALLOW_MODE, VoidFilterSettings.MATCH_CONTENTS, TravelersBackpackConfig.SERVER.backpackUpgrades.voidUpgradeSettings.filterSlotCount.get());

        if(isTabOpened()) {
            if(isHoveringWithTrashBin()) {
                renderTrashBin(guiGraphics, pos.x() + 31, pos.y() + 9, 0x80FFFFFF, (this.selectedSlots.isEmpty() && this.selectedTanks.isEmpty()) ? 0.0F : 3.0F);
                if(!this.selectedSlots.isEmpty() || !this.selectedTanks.isEmpty()) {
                    renderRedDownArrow(guiGraphics, pos.x() + 31 + 1, pos.y() + 5);
                }
            } else {
                renderTrashBinAnimation(guiGraphics, pos.x() + 31, pos.y() + 9, 0xFFFFFFFF);
            }
        }
    }

    @Override
    public void renderUnderTooltip(class_332 guiGraphics, int mouseX, int mouseY, float partialTicks) {
        super.renderUnderTooltip(guiGraphics, mouseX, mouseY, partialTicks);

        //Highlight slot under mouse
        class_1735 slot = screen.field_2787;
        if(isHoveringWithTrashBin() && slot != null && canSelectSlot(slot) && !this.selectedSlots.contains(slot.field_7874)) {
            drawRedHighlight(guiGraphics, slot);
        }

        //Highlight selected slots
        this.selectedSlots.forEach(index -> drawRedHighlight(guiGraphics, screen.method_17577().method_7611(index)));
    }

    @Override
    public void renderTooltip(class_332 guiGraphics, int mouseX, int mouseY) {
        super.renderTooltip(guiGraphics, mouseX, mouseY);

        if(isTabOpened()) {
            if(isWithinTrashBinSlot(mouseX, mouseY)) {
                if(isHoveringWithTrashBin() && (!this.selectedSlots.isEmpty() || !this.selectedTanks.isEmpty())) {
                    guiGraphics.method_51438(screen.method_64506(), class_2561.method_43471("screen.travelersbackpack.void_upgrade_trash_bin_drop").method_27692(class_124.field_1061), mouseX, mouseY);
                }
                if(this.selectedSlots.isEmpty() && this.selectedTanks.isEmpty()) {
                    List<class_2561> components = new ArrayList<>(TextUtils.getTranslatedSplittedText("screen.travelersbackpack.void_upgrade_trash_bin", null));
                    if(screen.getWrapper().getUpgradeManager().getUpgrade(TanksUpgrade.class).isEmpty()) {
                        components.remove(2);
                    }
                    guiGraphics.method_51434(screen.method_64506(), components, mouseX, mouseY);
                }
            }
            if(getFilterButton(ButtonStates.ALLOW).isMouseOver(mouseX, mouseY)) {
                guiGraphics.method_51438(screen.method_64506(), WHITELIST_TOOLTIPS.get(getFilterButton(ButtonStates.ALLOW).getCurrentState()), mouseX, mouseY);
            }
            if(getFilterButton(ButtonStates.OBJECT_TYPE).isMouseOver(mouseX, mouseY)) {
                guiGraphics.method_51438(screen.method_64506(), OBJECT_TOOLTIPS.get(getFilterButton(ButtonStates.OBJECT_TYPE).getCurrentState()), mouseX, mouseY);
            }
            if(getFilterButton(ButtonStates.IGNORE_MODE).isMouseOver(mouseX, mouseY)) {
                guiGraphics.method_51438(screen.method_64506(), IGNORE_MODE_TOOLTIPS.get(getFilterButton(ButtonStates.IGNORE_MODE).getCurrentState()), mouseX, mouseY);
            }
        }
    }

    @Override
    public void renderOnTop(class_332 guiGraphics, int mouseX, int mouseY, float partialTicks) {
        super.renderOnTop(guiGraphics, mouseX, mouseY, partialTicks);
        if(isTabOpened()) {
            this.tickAnimation = isHoveringWithTrashBin() || isWithinTrashBinSlot(mouseX, mouseY);
            if(isHoveringWithTrashBin()) {
                renderTrashBinAnimation(guiGraphics, mouseX - 1, mouseY - 1, 0xFFFFFFFF);
            }
        }
    }

    @Override
    public boolean method_25405(double pMouseX, double pMouseY) {
        if(isHoveringWithTrashBin()) {
            return true;
        }
        return super.method_25405(pMouseX, pMouseY);
    }

    public boolean isWithinTrashBinSlot(double mouseX, double mouseY) {
        return isWithinBounds(mouseX, mouseY, this.trashBinSlot);
    }

    @Override
    public boolean method_25403(class_11909 event, double dragX, double dragY) {
        //Selecting slots to void
        if(select(event)) {
            return true;
        }
        return super.method_25403(event, dragX, dragY);
    }

    @Override
    public boolean method_25402(class_11909 event, boolean doubleClick) {
        if(isTabOpened()) {
            if(isWithinTrashBinSlot(event.comp_4798(), event.comp_4799()) && screen.getWrapper().isOwner(screen.getScreenPlayer()) && screen.method_17577().method_34255().method_7960()) {
                this.hoveringTrashBin = !this.hoveringTrashBin;
                if(!isHoveringWithTrashBin()) {
                    this.selectedSlots.forEach(index -> ServerboundActionTagPacket.create(ServerboundActionTagPacket.SET_STACK, ServerActions.SLOT, class_1799.field_8037, index));
                    this.selectedSlots.clear();
                    this.selectedTanks.forEach(tank -> ServerboundActionTagPacket.create(ServerboundActionTagPacket.SET_STACK, ServerActions.TANK, class_1799.field_8037, tank));
                    this.selectedTanks.clear();
                }
            } else {
                if(select(event)) {
                    return true;
                }
            }
        }
        return super.method_25402(event, doubleClick);
    }

    public boolean isHoveringWithTrashBin() {
        return this.hoveringTrashBin;
    }

    public boolean select(class_11909 event) {
        if(isHoveringWithTrashBin()) {
            if(selectSlots(screen.field_2787, event.method_74245())) {
                return true;
            }
            if(screen.mappedWidgets.get(TanksUpgrade.class) instanceof TankWidget tankWidget) {
                if(selectTank(tankWidget, tankWidget.getUpgrade().getLeftTank().isEmpty(), tankWidget.leftTankElement, event, 0)) {
                    return true;
                }
                if(selectTank(tankWidget, tankWidget.getUpgrade().getRightTank().isEmpty(), tankWidget.rightTankElement, event, 1)) {
                    return true;
                }
            }
            if(!isWithinTrashBinSlot(event.comp_4798(), event.comp_4799())) {
                return true;
            }
        }
        return false;
    }

    public boolean selectTank(TankWidget tankWidget, boolean isEmpty, WidgetElement tankElement, class_11909 event, int tank) {
        if(tankWidget.inTank(tankElement, event.comp_4798(), event.comp_4799()) && !isEmpty) {
            if(event.method_74245() == 0 && !this.selectedTanks.contains(tank)) {
                this.selectedTanks.add(tank);
                return true;
            }

            if(event.method_74245() == 1 && this.selectedTanks.contains(tank)) {
                this.selectedTanks.remove((Object)tank);
                return true;
            }
        }
        return false;
    }

    public boolean canSelectSlot(class_1735 slot) {
        return (slot.field_7874 >= 0 && slot.field_7874 < screen.getWrapper().getStorage().getSlots()) || slot.field_7871 instanceof class_1661;
    }

    public boolean selectSlots(class_1735 slot, int button) {
        if(slot != null) {
            if(slot instanceof DisabledSlot || !slot.method_7681()) {
                return false;
            }
            if(canSelectSlot(slot)) {
                if(BackpackSettingsScreen.selectSlotsIndex(this.selectedSlots, this.hoveringTrashBin, slot, button)) {
                    return true;
                }
            }
        }
        return false;
    }

    public void drawRedTankHighlight(class_332 guiGraphics, int x, int y, boolean inTank, int height, int tankIndex) {
        //Render red highlight if hovering with trash bin
        if(isHoveringWithTrashBin()) {
            boolean flag = inTank;
            if(flag || selectedTanks.contains(tankIndex)) {
                if(flag) {
                    guiGraphics.method_25296(x, y, x + 16, y + height, HIGHLIGHT_TANK_COLOR, HIGHLIGHT_TANK_COLOR);
                }
                guiGraphics.method_25294(x, y, x + 16, y + height, RED_HIGHLIGHT_COLOR);
            }
        }
    }

    public void drawRedHighlight(class_332 guiGraphics, class_1735 slot) {
        guiGraphics.method_25294(screen.getGuiLeft() + slot.field_7873, screen.getGuiTop() + slot.field_7872, screen.getGuiLeft() + slot.field_7873 + 16, screen.getGuiTop() + slot.field_7872 + 16, RED_HIGHLIGHT_COLOR);
    }

    public void renderRedDownArrow(class_332 guiGraphics, int x, int y) {
        guiGraphics.method_25294(x, y + 2, x + 2, y + 5, RED_ARROW_COLOR);
        guiGraphics.method_25294(x - 2, y + 5, x + 4, y + 6, RED_ARROW_COLOR);
        guiGraphics.method_25294(x - 1, y + 6, x + 3, y + 7, RED_ARROW_COLOR);
        guiGraphics.method_25294(x, y + 7, x + 2, y + 8, RED_ARROW_COLOR);
    }

    public void renderTrashBinAnimation(class_332 guiGraphics, int x, int y, int color) {
        this.tickAnimation();
        float time = (float)(System.currentTimeMillis() % 2000) / 1000.0F;
        float f = (float) (Math.sin(time * Math.PI) * 1.0F + 1.0F);
        guiGraphics.method_51448().pushMatrix();
        if(isHoveringWithTrashBin()) {
            guiGraphics.method_51448().rotateAbout(class_7833.field_40718.rotationDegrees(-12.5F + (f * 12.5F)).angle(), x, y);
        }
        renderTrashBin(guiGraphics, x, y, color, progress);
        guiGraphics.method_51448().popMatrix();
    }

    public void renderTrashBin(class_332 guiGraphics, int x, int y, int color, float progress) {
        guiGraphics.method_51448().pushMatrix();
        guiGraphics.method_51448().rotateAbout(class_7833.field_40718.rotationDegrees(progress * 7.5F).angle(), x, y);
        guiGraphics.method_25291(class_10799.field_56883, TRASH_UPGRADE, x, y - (int)(1 * progress), 6, 4, 4, 1, 16, 16, color); //Top
        guiGraphics.method_25291(class_10799.field_56883, TRASH_UPGRADE, x - 2, y + 1 - (int)(1 * progress), 4, 5, 8, 1, 16, 16, color); //Middle
        guiGraphics.method_51448().popMatrix();
        guiGraphics.method_25291(class_10799.field_56883, TRASH_UPGRADE, x - 2, y + 2, 4, 6, 8, 1, 16, 16, color); //Middle
        guiGraphics.method_25291(class_10799.field_56883, TRASH_UPGRADE, x - 1, y + 3, 5, 7, 6, 5, 16, 16, color); //Bottom
    }

    public void tickAnimation() {
        if(tickAnimation) {
            if(progress < 3.0F) {
                progress += 0.2F;
            } else {
                progress = 3.0F;
            }
        } else {
            if(progress > 0.0F) {
                progress -= 0.2F;
            } else {
                progress = 0.0F;
            }
        }
    }

    private static final List<class_2561> WHITELIST_TOOLTIPS = List.of(
            class_2561.method_43471("screen.travelersbackpack.filter_allow_voiding"),
            class_2561.method_43471("screen.travelersbackpack.filter_block_voiding"),
            class_2561.method_43471("screen.travelersbackpack.filter_match_contents_voiding"));

    private static final List<class_2561> OBJECT_TOOLTIPS = List.of(
            class_2561.method_43471("screen.travelersbackpack.filter_item"),
            class_2561.method_43471("screen.travelersbackpack.filter_modid"),
            class_2561.method_43471("screen.travelersbackpack.filter_tag"));

    private static final List<class_2561> IGNORE_MODE_TOOLTIPS = List.of(
            class_2561.method_43471("screen.travelersbackpack.filter_match_components"),
            class_2561.method_43471("screen.travelersbackpack.filter_ignore_components"));
}