package com.tiviacz.travelersbackpack.inventory.upgrades.filter;

import com.tiviacz.travelersbackpack.inventory.handler.ItemStackHandler;
import net.minecraft.class_1799;
import net.minecraft.class_2371;

public class FilterHandler extends ItemStackHandler {
    public FilterHandler(class_2371<class_1799> stacks, int size) {
        super(size);
        for(int i = 0; i < this.stacks.size(); i++) {
            if(stacks.size() > i) {
                this.stacks.set(i, stacks.get(i));
            }
        }
    }

    @Override
    public boolean isItemValid(int slot, class_1799 stack) {
        return true;
    }

    @Override
    public int getSlotLimit(int slot) {
        return 1;
    }
}