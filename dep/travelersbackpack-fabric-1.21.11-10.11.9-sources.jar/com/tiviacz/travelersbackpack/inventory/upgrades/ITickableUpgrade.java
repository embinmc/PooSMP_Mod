package com.tiviacz.travelersbackpack.inventory.upgrades;

import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import org.jetbrains.annotations.Nullable;

public interface ITickableUpgrade {
    void tick(@Nullable class_1657 player, class_1937 level, class_2338 pos, int currentTick);

    int getTickRate();
}
