package com.tiviacz.travelersbackpack.inventory.upgrades;

import com.tiviacz.travelersbackpack.init.ModDataComponents;
import net.minecraft.class_1799;

public interface IMoveSelector {
    default boolean shiftClickToBackpack(class_1799 stack) {
        return stack.method_58695(ModDataComponents.SHIFT_CLICK_TO_BACKPACK, false);
    }
}