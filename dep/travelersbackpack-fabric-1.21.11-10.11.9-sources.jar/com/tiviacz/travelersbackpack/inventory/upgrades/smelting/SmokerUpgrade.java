package com.tiviacz.travelersbackpack.inventory.upgrades.smelting;

import com.tiviacz.travelersbackpack.inventory.UpgradeManager;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_3956;

public class SmokerUpgrade extends AbstractSmeltingUpgrade<SmokerUpgrade> {
    public SmokerUpgrade(UpgradeManager manager, int dataHolderSlot, class_2371<class_1799> furnaceContents) {
        super(manager, dataHolderSlot, furnaceContents, class_3956.field_17548, "smoker_upgrade");
    }
}