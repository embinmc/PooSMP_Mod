package com.tiviacz.travelersbackpack.inventory.upgrades.smelting;

import com.tiviacz.travelersbackpack.client.screens.BackpackScreen;
import com.tiviacz.travelersbackpack.client.screens.widgets.UpgradeWidgetBase;
import com.tiviacz.travelersbackpack.client.screens.widgets.WidgetElement;
import com.tiviacz.travelersbackpack.inventory.upgrades.Point;
import com.tiviacz.travelersbackpack.inventory.upgrades.ResultArrowElement;
import com.tiviacz.travelersbackpack.util.Reference;
import net.minecraft.class_10799;
import net.minecraft.class_11909;
import net.minecraft.class_332;

public class AbstractSmeltingWidget<T> extends UpgradeWidgetBase<AbstractSmeltingUpgrade<T>> {
    public final ResultArrowElement resultArrowElement;
    public final WidgetElement arrowElement = new WidgetElement(new Point(45, 61), new Point(12, 12));

    public AbstractSmeltingWidget(BackpackScreen screen, AbstractSmeltingUpgrade<T> upgrade, Point pos, String name) {
        super(screen, upgrade, pos, new Point(0, 118), name);
        this.resultArrowElement = new ResultArrowElement(screen, this, this.arrowElement);
    }

    @Override
    public void renderBg(class_332 guiGraphics, int x, int y, int mouseX, int mouseY) {
        super.renderBg(guiGraphics, x, y, mouseX, mouseY);
        this.resultArrowElement.renderBg(guiGraphics, x, y, mouseX, mouseY);
    }

    @Override
    public void method_25394(class_332 guiGraphics, int mouseX, int mouseY, float partialTicks) {
        super.method_25394(guiGraphics, mouseX, mouseY, partialTicks);

        if(isTabOpened() && screen.getWrapper().getScreenID() != Reference.ITEM_SCREEN_ID) {
            long gameTime = upgrade.getUpgradeManager().getWrapper().getLevel().method_75260();

            if(upgrade.isBurning()) {
                long burnTimeFinish = upgrade.getBurnFinishTime();
                long progress = burnTimeFinish - gameTime;
                float p = (float)progress / upgrade.getBurnTotalTime();
                int k = (int)Math.ceil(13 * p);
                guiGraphics.method_25290(class_10799.field_56883, BackpackScreen.TABS, pos.x() + 7, pos.y() + 55 - k, 0, 213 - k, 14, k + 1, 256, 256);
            }

            if(upgrade.isCooking()) {
                long cookTimeFinish = upgrade.getCookingFinishTime();
                long cookProgress = cookTimeFinish - gameTime;
                float cp = 1.0f - (float)cookProgress / upgrade.getCookingTotalTime();
                int l = (int)Math.ceil(10 * cp);
                guiGraphics.method_25290(class_10799.field_56883, BackpackScreen.TABS, pos.x() + 28, pos.y() + 42, 14, 200, l, 13, 256, 256);
            }
        }
    }

    @Override
    public void renderTooltip(class_332 guiGraphics, int mouseX, int mouseY) {
        super.renderTooltip(guiGraphics, mouseX, mouseY);
        this.resultArrowElement.renderTooltip(guiGraphics, mouseX, mouseY);
    }

    @Override
    public boolean method_25402(class_11909 event, boolean doubleClick) {
        if(this.resultArrowElement.mouseClicked(event)) {
            return true;
        }
        return super.method_25402(event, doubleClick);
    }
}