package com.tiviacz.travelersbackpack.inventory.upgrades.tanks;

import com.tiviacz.travelersbackpack.client.screens.BackpackScreen;
import com.tiviacz.travelersbackpack.client.screens.widgets.UpgradeWidgetBase;
import com.tiviacz.travelersbackpack.client.screens.widgets.WidgetElement;
import com.tiviacz.travelersbackpack.inventory.FluidTank;
import com.tiviacz.travelersbackpack.inventory.FluidVariantWrapper;
import com.tiviacz.travelersbackpack.inventory.upgrades.Point;
import com.tiviacz.travelersbackpack.inventory.upgrades.voiding.VoidUpgrade;
import com.tiviacz.travelersbackpack.inventory.upgrades.voiding.VoidWidget;
import com.tiviacz.travelersbackpack.network.ServerboundActionTagPacket;
import com.tiviacz.travelersbackpack.util.FluidTypeHelper;
import com.tiviacz.travelersbackpack.util.FluidUtil;
import com.tiviacz.travelersbackpack.util.RenderHelper;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1074;
import net.minecraft.class_10799;
import net.minecraft.class_11909;
import net.minecraft.class_1799;
import net.minecraft.class_1812;
import net.minecraft.class_1844;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_9334;
import java.util.ArrayList;
import java.util.List;

public class TankWidget extends UpgradeWidgetBase<TanksUpgrade> {
    public final WidgetElement leftTankElement;
    public final WidgetElement rightTankElement;
    public final int tankWidth = 18;
    public final int tankHeight;
    public final Point leftTankPos;
    public final Point rightTankPos;

    public TankWidget(BackpackScreen screen, TanksUpgrade upgrade, Point pos) {
        super(screen, upgrade, pos, new Point(0, 0), "screen.travelersbackpack.tanks_upgrade");
        this.tankHeight = 18 * screen.visibleRows;
        this.leftTankPos = new Point(screen.getGuiLeft() + 7, screen.getGuiTop() + 17);
        this.rightTankPos = new Point(screen.getGuiLeft() + 195 + (screen.getWrapper().isExtended() ? 36 : 0), screen.getGuiTop() + 17);
        this.leftTankElement = new WidgetElement(this.leftTankPos, new Point(this.tankWidth, this.tankHeight));
        this.rightTankElement = new WidgetElement(this.rightTankPos, new Point(this.tankWidth, this.tankHeight));
    }

    @Override
    public void renderTooltip(class_332 guiGraphics, int mouseX, int mouseY) {
        super.renderTooltip(guiGraphics, mouseX, mouseY);

        if(inTank(this.leftTankElement, mouseX, mouseY)) {
            guiGraphics.method_51434(screen.method_64506(), getTankTooltip(this.upgrade.leftTank), mouseX, mouseY);
        }

        if(inTank(this.rightTankElement, mouseX, mouseY)) {
            guiGraphics.method_51434(screen.method_64506(), getTankTooltip(this.upgrade.rightTank), mouseX, mouseY);
        }
    }

    @Override
    public void renderAboveBg(class_332 guiGraphics, int x, int y, int mouseX, int mouseY, float partialTicks) {
        int rows = upgrade.getUpgradeManager().getWrapper().getRows();
        RenderHelper.renderScreenTank(guiGraphics, this.upgrade.leftTank, this.leftTankPos.x() + 1, this.leftTankPos.y() + 1, 0, getTankHeight(rows), 16);
        renderTank(guiGraphics, this.leftTankElement, 0, mouseX, mouseY, rows, this.leftTankPos.x(), this.leftTankPos.y());
        RenderHelper.renderScreenTank(guiGraphics, this.upgrade.rightTank, this.rightTankPos.x() + 1, this.rightTankPos.y() + 1, 0, getTankHeight(rows), 16);
        renderTank(guiGraphics, this.rightTankElement, 1, mouseX, mouseY, rows, this.rightTankPos.x(), this.rightTankPos.y());
    }

    public int getTankHeight(int rows) {
        return (screen.isScrollable ? screen.visibleRows : rows) * 18 - 2;
    }

    @Override
    public boolean method_25402(class_11909 event, boolean doubleClick) {
        if(inTank(this.leftTankElement, event.comp_4798(), event.comp_4799())) {
            if(isValid(screen.method_17577().method_34255())) {
                ServerboundActionTagPacket.create(ServerboundActionTagPacket.FILL_TANK, true);
                return true;
            }
        }
        if(inTank(this.rightTankElement, event.comp_4798(), event.comp_4799())) {
            if(isValid(screen.method_17577().method_34255())) {
                ServerboundActionTagPacket.create(ServerboundActionTagPacket.FILL_TANK, false);
                return true;
            }
        }
        return super.method_25402(event, doubleClick);
    }

    @Override
    public boolean method_25405(double pMouseX, double pMouseY) {
        if(inTank(this.leftTankElement, pMouseX, pMouseY) || inTank(this.rightTankElement, pMouseX, pMouseY)) {
            if(!screen.method_17577().method_34255().method_7960()) {
                return true;
            }
        }
        return super.method_25405(pMouseX, pMouseY);
    }

    public boolean isValid(class_1799 stack) {
        return FluidUtil.hasFluidStorageConstant(stack) || stack.method_7909() instanceof class_1812;
        //return true;
        //return FluidUtil.getFluidHandler(stack).isPresent() || stack.getItem() instanceof PotionItem || stack.getItem() == Items.GLASS_BOTTLE;
    }

    public void renderTank(class_332 guiGraphics, WidgetElement tankElement, int tankIndex, int mouseX, int mouseY, int rows, int x, int y) {
        //Render red highlight if hovering with trash bin
        if(screen.mappedWidgets.get(VoidUpgrade.class) instanceof VoidWidget voidWidget) {
            voidWidget.drawRedTankHighlight(guiGraphics, x + 1, y + 1, inTank(tankElement, mouseX, mouseY), getTankHeight(rows), tankIndex);
        }

        //Top segment
        guiGraphics.method_25290(class_10799.field_56883, BackpackScreen.ICONS, x, y, 0, 95, 18, 18, 256, 256);

        //Middle segment
        for(int i = 1; i <= (screen.isScrollable ? screen.visibleRows : rows) - 2; i++) {
            guiGraphics.method_25290(class_10799.field_56883, BackpackScreen.ICONS, x, y + (18 * i), 0, 113, 18, 18, 256, 256);
        }

        //Bottom segment
        guiGraphics.method_25290(class_10799.field_56883, BackpackScreen.ICONS, x, y + (18 * ((screen.isScrollable ? screen.visibleRows : rows) - 1)), 0, 131, 18, 18, 256, 256);
    }

    @Environment(EnvType.CLIENT)
    public static List<class_2561> getTankTooltip(FluidTank tank) {
        FluidVariantWrapper fluidStack = tank.getFluid();
        List<class_2561> tankTips = new ArrayList<>();
        String fluidName = !fluidStack.isEmpty() ? FluidTypeHelper.getFluidVariantName(fluidStack.fluidVariant()).getString() : class_1074.method_4662("screen.travelersbackpack.none");
        String fluidAmount = !fluidStack.isEmpty() ? fluidStack.getViewAmount() + "/" + tank.getViewCapacity() : class_1074.method_4662("screen.travelersbackpack.empty");

        if(!fluidStack.isEmpty()) {
            if(fluidStack.fluidVariant().getComponents().method_57845(class_9334.field_49651) != null && fluidStack.fluidVariant().getComponents().method_57845(class_9334.field_49651).isPresent()) {
                float durationFactor = 1.0F;
                if(fluidStack.fluidVariant().getComponentMap().method_57832(class_9334.field_49628)) {
                    if(fluidStack.fluidVariant().getComponents().method_57845(class_9334.field_49628).get().method_57461().method_10545("PotionType")) {
                        int potionType = fluidStack.fluidVariant().getComponents().method_57845(class_9334.field_49628).get().method_57461().method_68083("PotionType", 0);
                        if(potionType == 1) {
                            tankTips.add(class_2561.method_43471("item.minecraft.splash_potion"));
                        }
                        if(potionType == 2) {
                            tankTips.add(class_2561.method_43471("item.minecraft.lingering_potion"));
                            durationFactor = 0.25F;
                        }

                    }
                }
                fluidName = null;
                class_1844 contents = fluidStack.fluidVariant().getComponents().method_57845(class_9334.field_49651).get();
                if(class_310.method_1551().field_1687 != null) {
                    class_1844.method_8065(contents.method_57397(), tankTips::add, durationFactor, class_310.method_1551().field_1687.method_54719().method_54748());
                }
            }
        }

        if(fluidName != null) tankTips.add(class_2561.method_43470(fluidName));
        tankTips.add(class_2561.method_43470(fluidAmount));

        return tankTips;
    }

    public boolean inTank(WidgetElement tankElement, double mouseX, double mouseY) {
        return mouseX >= tankElement.pos().x() && mouseX < tankElement.pos().x() + tankElement.size().x() && mouseY >= tankElement.pos().y() && mouseY < tankElement.pos().y() + tankElement.size().y();
    }
}