package com.tiviacz.travelersbackpack.inventory.menu;

import com.tiviacz.travelersbackpack.inventory.BackpackWrapper;
import com.tiviacz.travelersbackpack.inventory.menu.slot.BackpackSlotItemHandler;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_3917;

public abstract class AbstractBackpackMenu extends class_1703 {
    public final class_1657 player;
    protected final class_1661 inventory;
    protected final BackpackWrapper wrapper;
    public int disabledSlotIndex = -1;

    public int extendedScreenOffset = 0;

    public int BACKPACK_INV_START = 0, BACKPACK_INV_END;
    public int PLAYER_INV_START, PLAYER_HOT_END;

    protected AbstractBackpackMenu(class_3917<?> type, int windowID, class_1661 inventory, BackpackWrapper wrapper) {
        super(type, windowID);
        this.inventory = inventory;
        this.player = inventory.field_7546;
        this.wrapper = wrapper;
    }

    public BackpackWrapper getWrapper() {
        return this.wrapper;
    }

    public class_1661 getPlayerInventory() {
        return this.inventory;
    }

    public void addBackpackStorageSlots(BackpackWrapper wrapper) {
        int slot = 0;

        for(int i = 0; i < wrapper.getRows(); i++) {
            for(int j = 0; j < wrapper.getSlotsInRow(); j++) {
                if(slot >= wrapper.getStorage().getSlots()) break;
                this.method_7621(new BackpackSlotItemHandler(wrapper.getStorage(), slot, this.extendedScreenOffset + 8 + j * 18, 18 + i * 18));
                slot++;
            }
        }
    }
}