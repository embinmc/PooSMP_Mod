package com.tiviacz.travelersbackpack.inventory.menu.slot;

import com.tiviacz.travelersbackpack.inventory.BackpackWrapper;
import com.tiviacz.travelersbackpack.inventory.InventoryActions;
import com.tiviacz.travelersbackpack.inventory.handler.ItemStackHandler;
import com.tiviacz.travelersbackpack.inventory.upgrades.tanks.TanksUpgrade;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import org.jetbrains.annotations.NotNull;

public class FluidSlotItemHandler extends UpgradeSlotItemHandler<TanksUpgrade> {
    private final int index;
    public BackpackWrapper wrapper;
    public class_1657 player;
    public TanksUpgrade upgrade;

    public FluidSlotItemHandler(class_1657 player, TanksUpgrade upgrade, BackpackWrapper wrapper, ItemStackHandler handler, int index, int xPosition, int yPosition) {
        super(upgrade, handler, index, xPosition, yPosition);
        this.wrapper = wrapper;
        this.field_7874 = index;
        this.player = player;
        this.upgrade = upgrade;

        //0 - left in
        //1 - left out
        //2 - right in
        //3 - right out
    }

    //Fix for buckets bug
    @Override
    public void method_7673(@NotNull class_1799 stack) {
        super.method_7673(stack);
        if(field_7874 == 0 || field_7874 == 2) {
            InventoryActions.transferContainerTank(upgrade, field_7874 == 0 ? upgrade.getLeftTank() : upgrade.getRightTank(), field_7874);
        }
    }

    @Override
    public boolean method_7674(class_1657 playerIn) {
        if(upgrade.isTabOpened()) {
            if(field_7874 == 1 || field_7874 == 3) {
                return super.method_7674(playerIn) && this.method_7681();
            }
            return super.method_7674(playerIn);
        }
        return false;
    }
}