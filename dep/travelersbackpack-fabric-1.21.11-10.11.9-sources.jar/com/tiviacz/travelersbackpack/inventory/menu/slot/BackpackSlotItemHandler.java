package com.tiviacz.travelersbackpack.inventory.menu.slot;

import com.tiviacz.travelersbackpack.config.TravelersBackpackConfig;
import com.tiviacz.travelersbackpack.init.ModTags;
import com.tiviacz.travelersbackpack.inventory.handler.ItemStackHandler;
import com.tiviacz.travelersbackpack.item.TravelersBackpackItem;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;

public class BackpackSlotItemHandler extends SlotItemHandler {
    public static final List<class_1792> BLACKLISTED_ITEMS = new ArrayList<>();

    public BackpackSlotItemHandler(ItemStackHandler itemHandler, int index, int xPosition, int yPosition) {
        super(itemHandler, index, xPosition, yPosition);
    }

    public static boolean isItemValid(class_1799 stack) {
        if(BackpackSlotItemHandler.BLACKLISTED_ITEMS.contains(stack.method_7909())) return false;

        return !(stack.method_7909() instanceof TravelersBackpackItem) && !stack.method_31573(ModTags.BLACKLISTED_ITEMS) && (TravelersBackpackConfig.SERVER.backpackSettings.allowShulkerBoxes.get() || stack.method_7909().method_31568());
    }

   /* @Override
    public void setChanged() {
        if(!getItem().getItem().canFitInsideContainerItems() || getItem().getItem() instanceof BundleItem) {
            this.getItemHandler().setStackInSlot(getContainerSlot(), getItem()); //fix for EasyShulkerBoxes and BundleItem not calling onContentsChanged
        }
        super.setChanged();
    }*/

    @Override
    public void method_7667(class_1657 player, class_1799 stack) {
        method_7673(method_7677()); //Emi fix
        super.method_7667(player, stack);
    }

    //Fixes JEI
    @Override
    public boolean method_7680(class_1799 stack) {
        return getItemHandler().isItemValid(field_7874, stack);
    }

    @Override
    public boolean method_7674(class_1657 playerIn) {
        return true;
    }
}