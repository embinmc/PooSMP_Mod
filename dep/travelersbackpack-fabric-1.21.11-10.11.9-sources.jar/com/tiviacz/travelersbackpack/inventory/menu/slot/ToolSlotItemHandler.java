package com.tiviacz.travelersbackpack.inventory.menu.slot;

import com.tiviacz.travelersbackpack.config.TravelersBackpackConfig;
import com.tiviacz.travelersbackpack.init.ModTags;
import com.tiviacz.travelersbackpack.inventory.BackpackWrapper;
import com.tiviacz.travelersbackpack.item.HoseItem;
import net.minecraft.class_1657;
import net.minecraft.class_1786;
import net.minecraft.class_1787;
import net.minecraft.class_1792;
import net.minecraft.class_1794;
import net.minecraft.class_1799;
import net.minecraft.class_1811;
import net.minecraft.class_1819;
import net.minecraft.class_1820;
import net.minecraft.class_1835;
import net.minecraft.class_5538;
import net.minecraft.class_8162;
import net.minecraft.class_9334;
import net.minecraft.class_9362;
import net.minecraft.world.item.*;

import java.util.ArrayList;
import java.util.List;

public class ToolSlotItemHandler extends SlotItemHandler {
    private final BackpackWrapper wrapper;
    public static final List<class_1792> TOOL_SLOTS_ACCEPTABLE_ITEMS = new ArrayList<>();

    public ToolSlotItemHandler(BackpackWrapper wrapper, int index, int xPosition, int yPosition) {
        super(wrapper.getTools(), index, xPosition, yPosition);
        this.wrapper = wrapper;
    }

    @Override
    public boolean method_7682() {
        return this.wrapper.showToolSlots();
    }

    @Override
    public boolean method_7680(class_1799 stack) {
        return super.method_7680(stack) && method_7682();
    }

    @Override
    public boolean method_7674(class_1657 playerIn) {
        return super.method_7674(playerIn) && method_7682();
    }

    public static boolean isValid(class_1799 stack) {
        if(stack.method_7909() instanceof HoseItem) return false;

        if(TravelersBackpackConfig.SERVER.backpackSettings.toolSlotsAcceptEverything.get()) {
            return BackpackSlotItemHandler.isItemValid(stack);
        }

        //Datapacks :D
        if(stack.method_31573(ModTags.ACCEPTABLE_TOOLS)) return true;

        if(TOOL_SLOTS_ACCEPTABLE_ITEMS.contains(stack.method_7909())) return true;

        //Vanilla tools
        if(stack.method_7909() instanceof class_1794 ||
                stack.method_7909() instanceof class_1787 ||
                stack.method_7909() instanceof class_1820 ||
                stack.method_7909() instanceof class_1786 ||
                stack.method_7909() instanceof class_1811 ||
                stack.method_7909() instanceof class_8162 ||
                stack.method_7909() instanceof class_1835 ||
                stack.method_7909() instanceof class_9362 ||
                stack.method_7909() instanceof class_5538 ||
                stack.method_7909() instanceof class_1819) {
            return true;
        }
        return stack.method_57826(class_9334.field_50077) || stack.method_57826(class_9334.field_55878);
    }

    @Override
    public void method_7668() {
        super.method_7668();
    }
}