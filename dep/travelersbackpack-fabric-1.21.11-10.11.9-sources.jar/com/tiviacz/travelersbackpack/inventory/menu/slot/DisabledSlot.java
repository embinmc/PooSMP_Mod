package com.tiviacz.travelersbackpack.inventory.menu.slot;

import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1735;

public class DisabledSlot extends class_1735 {
    public DisabledSlot(class_1263 container, int index, int xPosition, int yPosition) {
        super(container, index, xPosition, yPosition);
    }

    @Override
    public boolean method_7674(class_1657 player) {
        return false;
    }
}