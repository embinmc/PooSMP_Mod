package com.tiviacz.travelersbackpack.inventory.menu.slot;

import com.tiviacz.travelersbackpack.init.ModDataComponents;
import com.tiviacz.travelersbackpack.inventory.handler.ItemStackHandler;
import com.tiviacz.travelersbackpack.inventory.upgrades.IMoveSelector;
import com.tiviacz.travelersbackpack.inventory.upgrades.UpgradeBase;

public class UpgradeSlotItemHandler<T extends UpgradeBase<?>> extends SlotItemHandler {
    private final T upgradeParent;

    public UpgradeSlotItemHandler(T upgradeParent, ItemStackHandler itemHandler, int index, int xPosition, int yPosition) {
        super(itemHandler, index, xPosition, yPosition);
        this.upgradeParent = upgradeParent;
    }

    public T getUpgradeParent() {
        return this.upgradeParent;
    }

    public boolean shiftClickToBackpack() {
        if(this.upgradeParent instanceof IMoveSelector) {
            return getUpgradeParent().getDataHolderStack().method_58695(ModDataComponents.SHIFT_CLICK_TO_BACKPACK, false);
        }
        return true;
    }
}