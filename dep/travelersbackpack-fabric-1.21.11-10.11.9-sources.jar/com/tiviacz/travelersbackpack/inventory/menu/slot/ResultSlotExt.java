package com.tiviacz.travelersbackpack.inventory.menu.slot;

import com.tiviacz.travelersbackpack.inventory.BackpackWrapper;
import com.tiviacz.travelersbackpack.inventory.upgrades.crafting.CraftingContainerImproved;
import java.util.Collections;
import net.minecraft.class_1657;
import net.minecraft.class_1731;
import net.minecraft.class_1734;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_3955;
import net.minecraft.class_8786;
import net.minecraft.class_9694;

public class ResultSlotExt extends class_1734 {
    protected final class_1731 inv;
    protected final BackpackWrapper wrapper;

    public ResultSlotExt(BackpackWrapper wrapper, class_1657 player, CraftingContainerImproved matrix, class_1731 inv, int slotIndex, int xPosition, int yPosition) {
        super(player, matrix, inv, slotIndex, xPosition, yPosition);
        this.inv = inv;
        this.wrapper = wrapper;
    }

    @Override
    public boolean method_7674(class_1657 player) {
        return true;
    }

    @Override
    public boolean method_7682() {
        return true;
    }

    @Override
    public class_1799 method_7671(int amount) {
        if(this.method_7681()) {
            this.field_7869 += Math.min(amount, this.method_7677().method_7947());
        }
        return this.method_7677().method_7972();
    }

    @Override
    protected void method_7672(int numItemsCrafted) {
        super.method_7672(numItemsCrafted);
        this.inv.method_5447(0, this.method_7677().method_7972()); // https://github.com/Shadows-of-Fire/FastWorkbench/issues/62 - Vanilla's SWAP action will leak this stack here.
    }

    @Override
    public void method_7673(class_1799 stack) {
    }

    @Override
    protected void method_7669(class_1799 stack) {
        if(this.field_7869 > 0) {
            stack.method_7982(this.field_7868, this.field_7869);
            //EventHooks.firePlayerCraftingEvent(this.player, stack, this.craftSlots);
        }
        this.field_7869 = 0;

        // Have to copy this code because vanilla nulls out the recipe, which shouldn't be done.
        class_8786<?> recipe = this.inv.method_7663();
        if(recipe != null) {
            this.field_7868.method_51283(this.inv.method_7663(), this.field_7870.method_51305());
            if(!recipe.comp_1933().method_8118()) {
                this.field_7868.method_7254(Collections.singleton(recipe));
            }
        }
    }

    @Override
    public void method_7667(class_1657 player, class_1799 stack) {
        this.method_7669(stack);
        class_9694.class_9765 pos = this.field_7870.method_60501();
        class_9694 input = pos.comp_2795();
        int left = pos.comp_2796();
        int top = pos.comp_2797();
        class_8786<class_3955> recipe = (class_8786<class_3955>)this.inv.method_7663();
        //CommonHooks.setCraftingPlayer(player);
        if(recipe != null && recipe.comp_1933().method_8115(input, player.method_73183())) {
            class_2371<class_1799> remaining = recipe.comp_1933().method_17704(input);

            for(int x = 0; x < input.method_59991(); x++) {
                for(int y = 0; y < input.method_59992(); y++) {
                    int realIdx = x + left + (y + top) * this.field_7870.method_17398();
                    class_1799 current = this.field_7870.method_5438(realIdx);
                    class_1799 remainder = remaining.get(x + y * input.method_59991());
                    if(!current.method_7960()) {
                        //Replaced method here #TODO find fix
                        ((CraftingContainerImproved)this.field_7870).removeItemShiftClick(realIdx, 1);
                        current = this.field_7870.method_5438(realIdx);
                    }
                    if(!remainder.method_7960()) {
                        if(current.method_7960()) {
                            this.field_7870.method_5447(realIdx, remainder);
                        } else if(class_1799.method_31577(current, remainder)) {
                            remainder.method_7933(current.method_7947());
                            this.field_7870.method_5447(realIdx, remainder);
                        } else if(!this.field_7868.method_31548().method_7394(remainder)) {
                            this.field_7868.method_7328(remainder, false);
                        }
                    }
                }
            }
        }
        //CommonHooks.setCraftingPlayer(null);
    }

    @Override
    public class_1799 method_7677() {
        if(field_7868.method_73183().method_8608()) return super.method_7677();
        // Crafting Tweaks fakes 64x right click operations to right-click craft a stack to the "held" item, so we need to verify the recipe here.
        class_8786<class_3955> recipe = (class_8786<class_3955>)this.inv.method_7663();
        if(recipe != null && recipe.comp_1933().method_8115(this.field_7870.method_59961(), field_7868.method_73183())) {
            return super.method_7677();
        }
        return class_1799.field_8037;
    }
}