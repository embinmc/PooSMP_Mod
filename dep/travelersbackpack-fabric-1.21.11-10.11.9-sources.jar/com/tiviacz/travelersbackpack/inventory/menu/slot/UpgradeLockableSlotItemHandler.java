package com.tiviacz.travelersbackpack.inventory.menu.slot;

import com.tiviacz.travelersbackpack.client.screens.BackpackScreen;
import com.tiviacz.travelersbackpack.inventory.handler.ItemStackHandler;
import com.tiviacz.travelersbackpack.inventory.menu.BackpackBaseMenu;
import com.tiviacz.travelersbackpack.item.upgrades.TanksUpgradeItem;
import com.tiviacz.travelersbackpack.item.upgrades.UpgradeItem;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_3417;

public class UpgradeLockableSlotItemHandler extends SlotItemHandler {
    public BackpackBaseMenu menu;
    public boolean isLocked = false;
    public boolean isHidden = false;

    public UpgradeLockableSlotItemHandler(BackpackBaseMenu menu, ItemStackHandler itemHandler, int index, int xPosition, int yPosition) {
        super(itemHandler, index, xPosition, yPosition);
        this.menu = menu;

        //If item in slot is not an Upgrade Item - do not lock
        if(itemHandler.getStackInSlot(index).method_7909() instanceof UpgradeItem && menu.getWrapper().getUpgradeManager().hasUpgradeInSlot(index)) {
            setLocked(true);
        }
    }

    public void setLocked(boolean locked) {
        this.isLocked = locked;
    }

    public void setHidden(boolean hidden) {
        this.isHidden = hidden;
    }

    @Override
    public boolean method_7680(class_1799 stack) {
        if(stack.method_7909() instanceof TanksUpgradeItem && !getItemHandler().isItemValid(field_7874, stack)) {
            if(!TanksUpgradeItem.canBePutInBackpack(menu.getWrapper().getBackpackTankCapacity(), stack)) {
                BackpackScreen.displayTanksUpgradeWarning(menu.player);
            }
        }
        return super.method_7680(stack);
    }

    @Override
    public boolean method_7674(class_1657 playerIn) {
        return super.method_7674(playerIn) && !isLocked && !isHidden;
    }

    @Override
    public boolean method_7682() {
        return super.method_7682() && !isLocked && !isHidden;
    }

    @Override
    public void method_48931(class_1799 pNewStack, class_1799 pOldStack) {
        if(menu.player.method_73183().method_8608()) {
            menu.player.method_5783(class_3417.field_15015.comp_349(), 1.0F, 1.0F);
        }
        super.method_48931(pNewStack, pOldStack);
    }

    @Override
    public void method_7668() {
        super.method_7668();
    }
}
