package com.tiviacz.travelersbackpack.inventory.menu.slot;

import net.minecraft.class_1263;
import net.minecraft.class_1735;

public class CraftingSlot extends class_1735 {
    public CraftingSlot(class_1263 container, int slot, int x, int y) {
        super(container, slot, x, y);
    }
}